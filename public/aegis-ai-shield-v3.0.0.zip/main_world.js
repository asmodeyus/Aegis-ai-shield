// AEGIS-AI Shield v3.0.0 — Bundled MAIN World Native Guard (esbuild)
(() => {
  // src/ext/shared/constants.js
  var TIMINGS = Object.freeze({
    DNR_DEBOUNCE_MS: 350,
    DNR_BATCH_SIZE: 150,
    DNR_FALLBACK_MAX_RULES: 5e3,
    TAB_HISTORY_TTL_MS: 2 * 60 * 60 * 1e3,
    TAB_HISTORY_CLEANUP_INTERVAL_MS: 15 * 60 * 1e3,
    LOG_FLUSH_DEBOUNCE_MS: 220,
    MAX_LOGS: 120,
    OBSERVER_DEBOUNCE_MS: 200,
    AUTO_SKIP_INTERVAL_MS: 1e3,
    BYPASS_TOAST_MS: 800,
    BYPASS_TOAST_MAX_WAIT_MS: 1100,
    SHORTLINK_CTA_GRACE_MS: 9e3,
    AUTH_GRACE_MS: 3e4,
    FIRST_PAGE_GRACE_MS: 6e3,
    REVERT_COOLDOWN_MS: 2200,
    LOOP_LOCK_MS: 15e3,
    USER_GESTURE_WINDOW_MS: 1800,
    AUTH_GESTURE_WINDOW_MS: 6e3,
    HISTORY_FLOOD_WINDOW_MS: 1500,
    HISTORY_FLOOD_MAX_CALLS: 6
  });
  var BRIDGE_EVENTS = Object.freeze({
    HANDSHAKE_INIT: "__AEGIS_HANDSHAKE_INIT__",
    REQUEST_RULES: "__AEGIS_REQUEST_RULES__",
    SYNC_RULES: "__AEGIS_SYNC_RULES__",
    CAPTCHA_SIGNAL: "__AEGIS_CAPTCHA_SIGNAL__",
    SHORTLINK_CTA_CLICK: "__AEGIS_SHORTLINK_CTA_CLICK__",
    AUTH_GESTURE: "__AEGIS_AUTH_GESTURE__",
    BLOCKED_EVENT: "__AEGIS_BLOCKED_EVENT__",
    VIDEO_DETECTED: "__AEGIS_VIDEO_DETECTED__",
    AUTO_SKIPPED: "__AEGIS_AUTO_SKIPPED__",
    LOG_EVENT: "__AEGIS_LOG_EVENT__"
  });
  var DEFAULT_GLOBAL_SETTINGS = Object.freeze({
    protectionMode: "balanced",
    // "balanced" | "strict"
    popupTheme: "dark",
    // "dark" | "light"
    sessionOnlyApiKey: false,
    debugInternalErrors: false,
    hudEnabled: true,
    hudDurationSec: 4.5,
    hudPosition: "top-center",
    hudOpacity: 0.95,
    hudScale: 1,
    hudShowTrust: true,
    hudShowGroup: true,
    hudShowOpen: true,
    hudShowBlock: true,
    hudShowUrlDetail: true,
    videoDockEnabled: true,
    videoDockDimSec: 2.5,
    videoDockExpandDir: "auto",
    videoPillScale: 1,
    videoPillOpacity: 0.95,
    videoPillShowPlayPause: true,
    videoPillShowList: true,
    videoPillShowDownload: true,
    videoPillShowPip: true,
    videoPillShowFullscreen: true,
    pipSize: "medium",
    pipOpacity: 0.95,
    adSkipSpeed: "16",
    smartUgcSense: true,
    shortlinkBypassEnabled: true,
    shortlinkAutoClick: true,
    loggingEnabled: true,
    removeTransparentOverlay: true,
    antiHistoryTrap: true,
    dnrEnabled: true,
    redirectWindowSec: 3.5
  });
  var DEFAULT_HUD_POSITIONS = Object.freeze({
    topHud: null,
    videoDock: null,
    miniPip: null
  });
  var DEFAULT_STATS = Object.freeze({
    blocked: 0,
    bypassed: 0,
    allowed: 0
  });
  var SUSPICIOUS_TLD = /\.(cfd|xyz|top|cyou|icu|buzz|click|link|monster|quest|rest|sbs|shop|site|tokyo|vip|wang|win|work|wtf|zone|live|asia|online|store|fun|pro|club|cam|cc|me|pw|tk|ml|ga|cf|gq)$/i;
  var GAMBLING_KEYWORDS = /(slot|gacor|maxwin|zeus|pragmatic|togel|judol|casino|betting|scatter|rtp|deposit|wd|bonus100|situsresmi|linkalternatif|sbobet|poker|judi|bandar|slot88|gacor88|pascol4d|dewadora|toto4d)/i;
  var COMMERCE_AFFILIATE_REGEX = /(shopee\.|shope\.ee|tokopedia\.|lazada\.|blibli\.|bukalapak\.|tiktok\.com\/t\/|invol\.co|accesstrade|admitad|ecotrack|go2cloud|onclickalgo|popads|popcash|propellerads|adsterra|hilltopads|exoclick|juicyads|trafficjunky|monetag|richads|wpadmngr|clickadu)/i;
  var RANDOM_SHORT_DOMAIN_REGEX = /^[a-z0-9]{2,4}[0-9][a-z0-9]{1,4}\.(com|net|org|co|id|io|info|biz)$/i;
  var SEARCH_ARBITRAGE_PARAMS = /(utm_source=.*ad|utm_medium=affiliate|af_siteid=|af_sub|clickid=|click_id=|subid=|sub_id=|aff_id=|zoneid=|bannerid=|popunder|redirect|gclid=|fbclid=.*ad)/i;
  var SAFE_MEDIA_HOST_REGEX = /(^|\.)(ibb\.co|ibb\.co\.com|imgur\.com|postimg\.cc|pixhost\.to|imgbox\.com|imagebam\.com|prnt\.sc|prntscr\.com|gyazo\.com|flickr\.com|staticflickr\.com|wikimedia\.org|tenor\.com|giphy\.com|redgifs\.com|catbox\.moe|bunkr\.(si|ru|is|la|sk|ax|ac|black|red|media|site)|cyberdrop\.(me|to|cc)|pixeldrain\.com|gofile\.io|mega\.nz|mediafire\.com|drive\.google\.com|docs\.google\.com|dropbox\.com)$/i;
  var KNOWN_AD_SHORTENER_REGEX = /(^|\.)(optional\.me|see\.optional\.me|rebrand\.ly|bit\.ly|t\.ly|tinyurl\.com|is\.gd|v\.gd|cutt\.ly|shorturl\.at|ouo\.io|shrinkme\.io|exe\.io|bc\.vc|adf\.ly|linkvertise\.com)$/i;
  var ANTI_ADBLOCK_PROBE_HOST_REGEX = /(^|\.)(wpadmngr\.com|googletagmanager\.com|googlesyndication\.com|doubleclick\.net|google-analytics\.com|adservice\.google\.com|adsterra\.com|propellerads\.com|onclickalgo\.com|clickadu\.com|popads\.net|popcash\.net)$/i;
  var AUTH_PATH_OR_PARAM_REGEX = /(\/(login|signin|sign-in|log-in|auth|oauth|oauth2|sso|saml|openid|oidc|authorize|callback|session|account|accounts|passport|idp|cas|connect\/authorize|v2\/auth|cdn-cgi\/challenge-platform)(\/|$)|[?&](client_id|redirect_uri|response_type|state|scope|openid|code_challenge|samlrequest|return_to|continue|_xfRedirect|__cf_chl_tk|__cf_chl_rt_tk|__cf_chl_f_tk)=)/i;
  var AUTH_SUBDOMAIN_REGEX = /^(accounts|auth|login|signin|sso|id|oauth|passport|idp|iam|auth0|okta)\./i;
  var AUTH_PROVIDER_HOST_REGEX = /(^|\.)(auth0\.com|okta\.com|onelogin\.com|cloudflareaccess\.com|login\.microsoftonline\.com|accounts\.google\.com|appleid\.apple\.com|github\.com)$/i;
  var AUTH_BUTTON_REGEX = /\b(log\s?in|sign\s?in|masuk|daftar|register|sign\s?up|sso|oauth|continue with|lanjutkan dengan|google|microsoft|apple|github|facebook|yandex|discord)\b/i;
  var CHALLENGE_HOST_REGEX = /(challenges\.cloudflare\.com|cloudflarecaptcha\.com|hcaptcha\.com|recaptcha\.net|gstatic\.com\/recaptcha|arkoselabs\.com|funcaptcha\.com|captcha-delivery\.com|datadome\.co|perimeterx\.net|dnstest\.dev)/i;
  var SAFE_ECOSYSTEM_GROUPS = [
    /(^|\.)(yandex\.(com|ru|kz|by|uz|ua|tr|net)|ya\.ru|yastatic\.net)$/i,
    /(^|\.)(google\.(com|co\.id|com\.sg|com\.my)|googleapis\.com|gstatic\.com|youtube\.com|youtu\.be)$/i,
    /(^|\.)(microsoft\.com|live\.com|bing\.com|msn\.com|microsoftonline\.com|login\.windows\.net)$/i,
    /(^|\.)(apple\.com|icloud\.com)$/i,
    /(^|\.)(github\.com|githubusercontent\.com)$/i,
    /(^|\.)(facebook\.com|fb\.com|instagram\.com)$/i,
    /(^|\.)(discord\.com|discordapp\.com)$/i
  ];
  var NON_VIDEO_ASSET_REGEX = /\.(jpg|jpeg|png|gif|webp|svg|ico|bmp|avif|css|js|json|woff2?|ttf|eot|vtt|srt)(\?|#|$)/i;
  var VIDEO_EXT_REGEX = /\.(mp4|m3u8|mkv|webm|mov|avi|flv|ts|mpd)(\?|#|$)/i;
  var VIDEO_STREAM_HINT_REGEX = /(\/pass_md5\/|\/hls\/|\/stream\/|\/get_video|mime=video|videoplayback|master\.txt|index\.txt|doodcdn|cloudcdn|vidcdn|\/token\/|\/delivery\/)/i;
  var VIDEO_MIME_REGEX = /^(video\/|application\/(vnd\.apple\.mpegurl|x-mpegurl|dash\+xml))/i;

  // src/ext/shared/captcha-guard.js
  var CAPTCHA_DOM_SELECTORS = [
    "iframe[src*='recaptcha']",
    "iframe[src*='hcaptcha']",
    "iframe[src*='challenges.cloudflare.com']",
    "iframe[src*='turnstile']",
    "iframe[src*='arkoselabs']",
    "iframe[src*='funcaptcha']",
    "iframe[src*='captcha-delivery.com']",
    "script[src*='/cdn-cgi/challenge-platform/']",
    ".g-recaptcha",
    ".h-captcha",
    ".cf-turnstile",
    "#cf-turnstile",
    "#px-captcha",
    "[data-sitekey]",
    "[data-hcaptcha-widget-id]",
    "[name='cf-turnstile-response']"
  ].join(", ");
  function isCaptchaChallengeUrl(urlStr) {
    if (!urlStr || typeof urlStr !== "string") return false;
    try {
      const u = new URL(urlStr);
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      const host = u.hostname.toLowerCase();
      if (CHALLENGE_HOST_REGEX.test(host)) return true;
      const pathAndQuery = u.pathname + u.search;
      if (pathAndQuery.includes("/cdn-cgi/challenge-platform/") || pathAndQuery.includes("__cf_chl_tk=") || pathAndQuery.includes("__cf_chl_rt_tk=") || pathAndQuery.includes("__cf_chl_f_tk=")) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  // src/ext/shared/debug.js
  var debugEnabled = false;
  var debugSink = null;
  function logInternalError(scope, err) {
    if (!debugEnabled || !debugSink) return;
    try {
      const message = err instanceof Error ? `${err.name}: ${err.message}` : String(err || "Unknown internal error");
      debugSink({
        scope: String(scope || "internal"),
        message: message.slice(0, 260)
      });
    } catch {
    }
  }
  function safeTry(scope, fn, fallback) {
    try {
      return fn();
    } catch (err) {
      logInternalError(scope, err);
      return (
        /** @type {T} */
        fallback
      );
    }
  }

  // src/ext/shared/domain-utils.js
  var SECOND_LEVEL_PUBLIC_SUFFIXES = /* @__PURE__ */ new Set([
    "co",
    "com",
    "net",
    "org",
    "ac",
    "go",
    "or",
    "web",
    "sch"
  ]);
  var VALID_DOMAIN_REGEX = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i;
  function getHostname(urlStr, baseHref) {
    if (!urlStr) return "";
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      return (u.hostname || "").toLowerCase();
    } catch {
      return "";
    }
  }
  function getBaseDomain(hostname) {
    const clean = String(hostname || "").trim().toLowerCase().replace(/^www\./, "");
    const parts = clean.split(".").filter(Boolean);
    if (parts.length <= 2) return clean;
    const sld = parts[parts.length - 2];
    if (SECOND_LEVEL_PUBLIC_SUFFIXES.has(sld) && parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  function normalizeDomainEntry(raw) {
    if (!raw) return "";
    let val = String(raw).trim().toLowerCase();
    if (!val) return "";
    try {
      if (val.includes("://")) {
        val = new URL(val).hostname.toLowerCase();
      } else {
        val = val.replace(/^\|\|/, "").replace(/\^.*$/, "").replace(/^\*\./, "").split("/")[0].split("?")[0].split("#")[0].split(":")[0];
      }
    } catch {
      val = val.split("/")[0].split("?")[0].split("#")[0];
    }
    val = val.replace(/^www\./, "").trim();
    if (!val || !VALID_DOMAIN_REGEX.test(val)) return "";
    return val;
  }
  function isDomainInList(urlStr, list, baseHref) {
    if (!urlStr || !Array.isArray(list) || list.length === 0) return false;
    const host = getHostname(urlStr, baseHref).replace(/^www\./, "");
    if (!host) return false;
    const base = getBaseDomain(host);
    for (const item of list) {
      const rule = normalizeDomainEntry(item);
      if (!rule) continue;
      const ruleBase = getBaseDomain(rule);
      if (host === rule || base === rule || host === ruleBase || base === ruleBase || host.endsWith("." + rule) || host.endsWith("." + ruleBase)) {
        return true;
      }
    }
    return false;
  }
  function isSameSafeEcosystem(hostA, hostB) {
    if (!hostA || !hostB) return false;
    return SAFE_ECOSYSTEM_GROUPS.some((rx) => rx.test(hostA) && rx.test(hostB));
  }

  // src/ext/shared/url-classifier.js
  function isAuthFlowUrl(urlStr) {
    if (!urlStr) return false;
    try {
      const u = new URL(urlStr);
      const host = u.hostname.toLowerCase();
      return AUTH_SUBDOMAIN_REGEX.test(host) || AUTH_PROVIDER_HOST_REGEX.test(host) || AUTH_PATH_OR_PARAM_REGEX.test(u.pathname + u.search);
    } catch {
      return false;
    }
  }
  function diagnoseDestinationBlock(urlStr, ctx) {
    if (!urlStr) return { block: true, reason: "empty_url" };
    const raw = String(urlStr).trim();
    if (/^(intent|shopeeid|tokopedia|lazada|market):/i.test(raw)) {
      return { block: true, reason: "deep_link_app" };
    }
    try {
      const dest = new URL(raw, ctx.currentHref);
      if (!dest.protocol.startsWith("http")) return { block: false, reason: "non_http" };
      const curObj = new URL(ctx.currentHref);
      const curHost = curObj.hostname.toLowerCase();
      const destHost = dest.hostname.toLowerCase();
      const destBase = getBaseDomain(destHost);
      const curBase = getBaseDomain(curHost);
      if (isDomainInList(dest.href, ctx.denied || [])) {
        return { block: true, reason: "denied_blacklist" };
      }
      if (ctx.tempAllowActive) {
        return { block: false, reason: "temporary_allow_active" };
      }
      if (ctx.captchaDetected || CHALLENGE_HOST_REGEX.test(destHost)) {
        return { block: false, reason: "captcha_challenge" };
      }
      if (destBase === curBase) return { block: false, reason: "same_base_domain" };
      if (isSameSafeEcosystem(curHost, destHost)) return { block: false, reason: "safe_ecosystem" };
      if (isDomainInList(dest.href, ctx.trusted || [])) {
        return { block: false, reason: "trusted_whitelist" };
      }
      const isSearchHijack = destHost.includes("google.") && dest.pathname === "/search";
      const isHardBadPattern = GAMBLING_KEYWORDS.test(dest.href) || COMMERCE_AFFILIATE_REGEX.test(dest.href) || RANDOM_SHORT_DOMAIN_REGEX.test(destBase) || SEARCH_ARBITRAGE_PARAMS.test(dest.href) || KNOWN_AD_SHORTENER_REGEX.test(destHost);
      if (isSearchHijack) return { block: true, reason: "search_hijack" };
      if (isHardBadPattern) return { block: true, reason: "hard_ad_or_gambling_pattern" };
      if (ctx.hasRecentUserGesture && SAFE_MEDIA_HOST_REGEX.test(destHost)) {
        return { block: false, reason: "safe_media_host" };
      }
      if (ctx.hasRecentShortlinkCta) {
        return { block: false, reason: "shortlink_cta_grace" };
      }
      if (SUSPICIOUS_TLD.test(destHost)) {
        return { block: true, reason: "suspicious_tld" };
      }
      if (ctx.hasRecentUserGesture && (isAuthFlowUrl(dest.href) || ctx.hasRecentAuthGesture)) {
        return { block: false, reason: "auth_flow" };
      }
      if (!ctx.hasRecentUserGesture) {
        return { block: true, reason: "no_recent_user_gesture" };
      }
      const isStrictMode = ctx.protectionMode === "strict" || ctx.protectionMode !== "balanced" && ctx.strictCrossOrigin !== false;
      if (isStrictMode) {
        return { block: true, reason: "strict_cross_origin" };
      }
      return { block: false, reason: "balanced_user_click_allowed" };
    } catch {
      return { block: false, reason: "parse_error" };
    }
  }

  // src/ext/main_world/index.js
  (() => {
    "use strict";
    const win = (
      /** @type {any} */
      window
    );
    if (win.__AEGIS_V3_LOCKED__) return;
    win.__AEGIS_V3_LOCKED__ = true;
    const isInitialChallengeOrOpaque = () => {
      try {
        const proto = location.protocol || "";
        const host = (location.hostname || "").toLowerCase();
        if (proto !== "http:" && proto !== "https:") return true;
        if (!host || window.origin === "null") return true;
        if (win._cf_chl_opt) return true;
        return isCaptchaChallengeUrl(location.href);
      } catch {
        return true;
      }
    };
    if (isInitialChallengeOrOpaque()) return;
    const initialHost = (location.hostname || "").toLowerCase();
    if (isSameSafeEcosystem(initialHost, initialHost)) return;
    let bridgeToken = "";
    let handshakeLocked = false;
    window.addEventListener(BRIDGE_EVENTS.HANDSHAKE_INIT, (ev) => {
      if (handshakeLocked) return;
      const incoming = ev && /** @type {CustomEvent} */
      ev.detail && /** @type {CustomEvent} */
      ev.detail.token;
      if (typeof incoming === "string" && incoming.length >= 16) {
        bridgeToken = incoming;
        handshakeLocked = true;
      }
    });
    const state = {
      trusted: (
        /** @type {string[]} */
        []
      ),
      denied: (
        /** @type {string[]} */
        []
      ),
      protectionMode: "balanced",
      strictCrossOrigin: false,
      autoSkipCountdown: true,
      antiHistoryTrap: true,
      loggingEnabled: true,
      tempAllowActive: false,
      captchaDetected: false,
      apisRestored: false,
      lastUserClick: 0,
      lastAuthClick: 0,
      lastShortlinkCta: 0
    };
    function isValidToken(ev) {
      return Boolean(handshakeLocked && bridgeToken && ev && ev.detail && ev.detail.token === bridgeToken);
    }
    function emitAegisLog(level, code, toUrl, detail) {
      if (!state.loggingEnabled) return;
      safeTry("main_world.emitLog", () => {
        window.dispatchEvent(
          new CustomEvent(BRIDGE_EVENTS.LOG_EVENT, {
            detail: {
              token: bridgeToken,
              level: level || "WARN",
              source: "main_world",
              code: code || "MAIN_WORLD_EVENT",
              fromUrl: location.href,
              toUrl: toUrl ? String(toUrl) : "",
              detail: detail ? String(detail) : ""
            }
          })
        );
      });
    }
    function emitBlocked(url, kind) {
      if (url && isDomainInList(url, state.denied, location.href)) return;
      safeTry("main_world.emitBlocked", () => {
        window.dispatchEvent(
          new CustomEvent(BRIDGE_EVENTS.BLOCKED_EVENT, {
            detail: { token: bridgeToken, url: String(url || ""), kind }
          })
        );
      });
    }
    function reportVideoCandidate(rawUrl, isConfirmedMime = false) {
      safeTry("main_world.reportVideo", () => {
        if (!rawUrl) return;
        const rawStr = String(rawUrl).trim();
        if (rawStr.startsWith("data:") || rawStr.startsWith("blob:") || rawStr.startsWith("javascript:")) {
          return;
        }
        const absUrl = new URL(rawStr, location.href).href;
        if (!absUrl.startsWith("http") || NON_VIDEO_ASSET_REGEX.test(absUrl)) return;
        if (isConfirmedMime || VIDEO_EXT_REGEX.test(absUrl) || VIDEO_STREAM_HINT_REGEX.test(absUrl)) {
          window.dispatchEvent(
            new CustomEvent(BRIDGE_EVENTS.VIDEO_DETECTED, {
              detail: { token: bridgeToken, url: absUrl, confirmed: isConfirmedMime }
            })
          );
        }
      });
    }
    function maskAsNative(wrapperFn, nativeFn) {
      safeTry("main_world.maskAsNative", () => {
        const nativeStr = Function.prototype.toString.call(nativeFn);
        Object.defineProperty(wrapperFn, "toString", {
          value: function() {
            return nativeStr;
          },
          writable: true,
          configurable: true
        });
      });
      return wrapperFn;
    }
    function recordUserGesture(ev) {
      const now = Date.now();
      state.lastUserClick = now;
      safeTry("main_world.recordGesture", () => {
        const target = ev && ev.target;
        if (!target || !target.closest) return;
        const clickable = target.closest(
          "button, a, [role='button'], input[type='submit'], input[type='button'], form, [data-xf-click]"
        );
        if (!clickable) return;
        const label = [
          clickable.innerText || clickable.value || clickable.getAttribute("aria-label") || clickable.getAttribute("title") || "",
          clickable.id || "",
          typeof clickable.className === "string" ? clickable.className : "",
          clickable.getAttribute("href") || clickable.getAttribute("action") || clickable.getAttribute("data-xf-click") || ""
        ].join(" ");
        const hasPasswordField = Boolean(document.querySelector("input[type='password']"));
        if (AUTH_BUTTON_REGEX.test(label) || hasPasswordField && clickable.matches("button, input[type='submit'], [role='button'], form")) {
          state.lastAuthClick = now;
          window.dispatchEvent(
            new CustomEvent(BRIDGE_EVENTS.AUTH_GESTURE, { detail: { token: bridgeToken } })
          );
        }
      });
    }
    document.addEventListener("pointerdown", recordUserGesture, true);
    document.addEventListener("click", recordUserGesture, true);
    document.addEventListener(
      "keydown",
      (ev) => {
        state.lastUserClick = Date.now();
        if (ev.key === "Enter" && document.querySelector("input[type='password']")) {
          state.lastAuthClick = Date.now();
          window.dispatchEvent(
            new CustomEvent(BRIDGE_EVENTS.AUTH_GESTURE, { detail: { token: bridgeToken } })
          );
        }
      },
      true
    );
    document.addEventListener(
      "submit",
      () => {
        const now = Date.now();
        state.lastUserClick = now;
        state.lastAuthClick = now;
        window.dispatchEvent(
          new CustomEvent(BRIDGE_EVENTS.AUTH_GESTURE, { detail: { token: bridgeToken } })
        );
      },
      true
    );
    const origFetch = window.fetch;
    const origXhrOpen = XMLHttpRequest.prototype.open;
    const origOpen = window.open;
    const origAnchorClick = HTMLAnchorElement.prototype.click;
    const origPushState = history.pushState;
    const origSetInterval = window.setInterval;
    const origSetTimeout = window.setTimeout;
    function restoreNativeApisForChallenge() {
      if (state.apisRestored) return;
      state.apisRestored = true;
      safeTry("main_world.restoreNativeApis", () => {
        window.setTimeout = origSetTimeout;
        window.setInterval = origSetInterval;
        window.fetch = origFetch;
        window.open = origOpen;
        history.pushState = origPushState;
        HTMLAnchorElement.prototype.click = origAnchorClick;
      });
    }
    window.addEventListener(BRIDGE_EVENTS.SYNC_RULES, (ev) => {
      if (!isValidToken(ev)) return;
      const d = (
        /** @type {CustomEvent} */
        ev.detail
      );
      state.trusted = Array.isArray(d.trusted) ? d.trusted : [];
      state.denied = Array.isArray(d.denied) ? d.denied : [];
      state.protectionMode = d.protectionMode === "strict" ? "strict" : "balanced";
      state.strictCrossOrigin = state.protectionMode === "strict" || Boolean(d.strictCrossOrigin);
      state.autoSkipCountdown = d.autoSkipCountdown !== false;
      state.tempAllowActive = Boolean(d.tempAllowActive);
      if (d.globalSettings) {
        state.antiHistoryTrap = d.globalSettings.antiHistoryTrap !== false;
        state.loggingEnabled = d.globalSettings.loggingEnabled !== false;
      }
    });
    window.addEventListener(BRIDGE_EVENTS.CAPTCHA_SIGNAL, (ev) => {
      if (!isValidToken(ev)) return;
      const detected = Boolean(
        /** @type {CustomEvent} */
        ev.detail.detected
      );
      if (detected && !state.captchaDetected) {
        state.captchaDetected = true;
        restoreNativeApisForChallenge();
        emitAegisLog(
          "ALLOW",
          "CAPTCHA_KILL_SWITCH",
          location.href,
          "CAPTCHA/Turnstile terdeteksi -> timer acceleration & native hooks dinonaktifkan otomatis"
        );
      }
    });
    window.addEventListener(BRIDGE_EVENTS.SHORTLINK_CTA_CLICK, (ev) => {
      if (!isValidToken(ev)) return;
      state.lastShortlinkCta = Date.now();
    });
    function diagnose(urlStr, isUserEvent = false) {
      const now = Date.now();
      return diagnoseDestinationBlock(urlStr, {
        currentHref: location.href,
        trusted: state.trusted,
        denied: state.denied,
        strictCrossOrigin: state.strictCrossOrigin,
        protectionMode: state.protectionMode,
        tempAllowActive: state.tempAllowActive,
        captchaDetected: state.captchaDetected || isCaptchaChallengeUrl(location.href),
        hasRecentUserGesture: isUserEvent || now - state.lastUserClick < TIMINGS.USER_GESTURE_WINDOW_MS,
        hasRecentAuthGesture: now - state.lastAuthClick < TIMINGS.AUTH_GESTURE_WINDOW_MS,
        hasRecentShortlinkCta: now - state.lastShortlinkCta < 7e3
      });
    }
    function isAntiAdblockFetchProbe(reqUrl, initObj) {
      if (!reqUrl || state.tempAllowActive || state.captchaDetected) return false;
      try {
        const u = new URL(reqUrl, location.href);
        const host = u.hostname.toLowerCase();
        if (!ANTI_ADBLOCK_PROBE_HOST_REGEX.test(host) && !isDomainInList(u.href, state.denied)) {
          return false;
        }
        const mode = initObj && typeof initObj === "object" ? String(initObj.mode || "").toLowerCase() : "";
        if (mode === "no-cors") return true;
        return ANTI_ADBLOCK_PROBE_HOST_REGEX.test(host) && (u.pathname === "/" || u.search.includes("t="));
      } catch {
        return false;
      }
    }
    window.fetch = maskAsNative(function(input, init) {
      const reqUrl = typeof input === "string" ? input : input && input.url ? input.url : "";
      reportVideoCandidate(reqUrl, false);
      const isAdblockProbe = isAntiAdblockFetchProbe(reqUrl, init);
      const p = origFetch.apply(this, arguments);
      if (p && typeof p.then === "function") {
        const handled = p.then((res) => {
          safeTry("main_world.fetchMime", () => {
            if (res && res.headers) {
              const ct = res.headers.get("content-type") || "";
              if (VIDEO_MIME_REGEX.test(ct)) reportVideoCandidate(res.url || reqUrl, true);
            }
          });
          return res;
        });
        if (isAdblockProbe) {
          return handled.catch(() => {
            emitAegisLog(
              "BYPASS",
              "BYPASS_ANTI_ADBLOCK_FETCH",
              reqUrl,
              "Probe anti-adblock fetch(no-cors) dinetralkan -> respons 200 OK palsu"
            );
            try {
              return new Response("", { status: 200, statusText: "OK" });
            } catch {
              return { ok: true, status: 200, type: "opaque", text: async () => "" };
            }
          });
        }
        return handled;
      }
      return p;
    }, origFetch);
    XMLHttpRequest.prototype.open = function(method, url) {
      safeTry("main_world.xhrOpen", () => {
        this.__aegisXhrUrl = url ? String(url) : "";
        reportVideoCandidate(this.__aegisXhrUrl, false);
        this.addEventListener("readystatechange", function() {
          safeTry("main_world.xhrMime", () => {
            if (this.readyState >= 2) {
              const ct = this.getResponseHeader("content-type") || "";
              if (VIDEO_MIME_REGEX.test(ct)) {
                reportVideoCandidate(this.responseURL || this.__aegisXhrUrl, true);
              }
            }
          });
        });
      });
      return origXhrOpen.apply(this, arguments);
    };
    if (win.navigation) {
      win.navigation.addEventListener("navigate", (event) => {
        safeTry("main_world.navigation", () => {
          if (state.captchaDetected || state.tempAllowActive) return;
          const destUrl = event.destination.url;
          const recentGesture = Boolean(event.userInitiated) || Date.now() - state.lastUserClick < TIMINGS.USER_GESTURE_WINDOW_MS;
          const diag = diagnose(destUrl, recentGesture);
          if (diag.block && event.cancelable) {
            event.preventDefault();
            emitAegisLog(
              "BLOCK",
              "BLOCK_MAIN_NAVIGATE",
              destUrl,
              `window.navigation.navigate ditahan | mode=${state.protectionMode} | reason=${diag.reason} | userGesture=${recentGesture}`
            );
            if (!isDomainInList(destUrl, state.denied, location.href)) {
              emitBlocked(destUrl, "redirect");
            }
          }
        });
      });
    }
    window.open = maskAsNative(function(url) {
      if (state.captchaDetected || state.tempAllowActive) {
        return origOpen.apply(this, arguments);
      }
      const resolved = url ? safeTry("main_world.openResolve", () => new URL(url, location.href).href, "") : "";
      const now = Date.now();
      const recentGesture = now - state.lastUserClick < TIMINGS.USER_GESTURE_WINDOW_MS;
      const recentAuth = now - state.lastAuthClick < TIMINGS.AUTH_GESTURE_WINDOW_MS;
      if (resolved && isDomainInList(resolved, state.denied, location.href)) {
        emitAegisLog("BLOCK", "BLOCK_WINDOW_OPEN_BLACKLIST", resolved, "window.open diblokir senyap (Blacklist)");
        return null;
      }
      if (resolved) {
        const curHost = location.hostname.toLowerCase();
        const destHost = getHostname(resolved);
        if (isDomainInList(resolved, state.trusted) || isSameSafeEcosystem(curHost, destHost)) {
          return origOpen.apply(this, arguments);
        }
        if (recentGesture && (isAuthFlowUrl(resolved) || recentAuth) && !diagnose(resolved, true).block) {
          return origOpen.apply(this, arguments);
        }
      } else if (recentGesture && recentAuth) {
        return origOpen.apply(this, arguments);
      }
      const diag = diagnose(resolved, recentGesture);
      if (!resolved || diag.block) {
        emitAegisLog(
          "BLOCK",
          "BLOCK_WINDOW_OPEN",
          resolved || location.href,
          `window.open ditahan | mode=${state.protectionMode} | reason=${diag.reason} | userGesture=${recentGesture}`
        );
        if (!resolved || !isDomainInList(resolved, state.denied, location.href)) {
          emitBlocked(resolved || location.href, "popup");
        }
        return null;
      }
      return origOpen.apply(this, arguments);
    }, origOpen);
    HTMLAnchorElement.prototype.click = function() {
      if (!state.captchaDetected && !state.tempAllowActive) {
        const blocked = safeTry("main_world.anchorClick", () => {
          const href = this.getAttribute("href") || this.href || "";
          if (!href) return false;
          const recentGesture = Date.now() - state.lastUserClick < TIMINGS.USER_GESTURE_WINDOW_MS;
          const diag = diagnose(href, recentGesture);
          if (diag.block) {
            const abs = new URL(href, location.href).href;
            emitAegisLog(
              "BLOCK",
              "BLOCK_ANCHOR_JS_CLICK",
              abs,
              `HTMLAnchorElement.click() ditahan | reason=${diag.reason} | userGesture=${recentGesture}`
            );
            if (!isDomainInList(abs, state.denied, location.href)) {
              emitBlocked(abs, this.target === "_blank" ? "popup" : "redirect");
            }
            return true;
          }
          return false;
        }, false);
        if (blocked) return;
      }
      return origAnchorClick.apply(this, arguments);
    };
    const pushStateTimestamps = [];
    history.pushState = maskAsNative(function(st, title, url) {
      if (!state.antiHistoryTrap || state.tempAllowActive || state.captchaDetected) {
        return origPushState.apply(this, arguments);
      }
      const shouldDrop = safeTry("main_world.pushState", () => {
        if (isDomainInList(location.href, state.trusted)) return false;
        const now = Date.now();
        if (now - state.lastAuthClick < TIMINGS.AUTH_GESTURE_WINDOW_MS) return false;
        const hasRecentUserInput = now - state.lastUserClick < 1500;
        if (hasRecentUserInput) return false;
        while (pushStateTimestamps.length > 0 && now - pushStateTimestamps[0] > TIMINGS.HISTORY_FLOOD_WINDOW_MS) {
          pushStateTimestamps.shift();
        }
        pushStateTimestamps.push(now);
        if (pushStateTimestamps.length > TIMINGS.HISTORY_FLOOD_MAX_CALLS) {
          return true;
        }
        return false;
      }, false);
      if (shouldDrop) return;
      return origPushState.apply(this, arguments);
    }, origPushState);
    safeTry("main_world.hookMediaSrc", () => {
      const mediaDesc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, "src");
      if (mediaDesc && mediaDesc.set) {
        Object.defineProperty(HTMLMediaElement.prototype, "src", {
          configurable: true,
          enumerable: true,
          get: mediaDesc.get,
          set: function(val) {
            safeTry("main_world.mediaSrcSet", () => {
              if (!val) return;
              const s = String(val);
              if (s.startsWith("blob:")) {
                window.dispatchEvent(
                  new CustomEvent(BRIDGE_EVENTS.VIDEO_DETECTED, {
                    detail: { token: bridgeToken, url: location.href, confirmed: true }
                  })
                );
              } else {
                reportVideoCandidate(s, false);
              }
            });
            return mediaDesc.set.call(this, val);
          }
        });
      }
    });
    safeTry("main_world.hookMediaSource", () => {
      if (window.MediaSource && MediaSource.prototype.addSourceBuffer) {
        const origAddSB = MediaSource.prototype.addSourceBuffer;
        MediaSource.prototype.addSourceBuffer = function(mimeType) {
          safeTry("main_world.addSourceBuffer", () => {
            if (mimeType && String(mimeType).toLowerCase().includes("video")) {
              window.dispatchEvent(
                new CustomEvent(BRIDGE_EVENTS.VIDEO_DETECTED, {
                  detail: { token: bridgeToken, url: location.href, confirmed: true }
                })
              );
            }
          });
          return origAddSB.apply(this, arguments);
        };
      }
    });
    function isProtectedFrameworkCallback(fn) {
      if (typeof fn !== "function") return true;
      try {
        const src = Function.prototype.toString.call(fn);
        return /(hls|dash|mediaSource|sourceBuffer|fragment|segment|bitrate|bandwidth|plyr|videojs|jwplayer|artplayer|dplayer|levelLoaded|fragLoaded|abort|xhr|ajax|overlay|xenforo|xf\.|fetch|timeout|reject|server|respond|turnstile|recaptcha|hcaptcha|arkose)/i.test(
          src
        );
      } catch {
        return true;
      }
    }
    function isServerTokenShortlinkPage() {
      return safeTry("main_world.isServerTokenPage", () => {
        if (document.querySelector("video")) return false;
        if (document.querySelector(
          "a[href*='download='], a[href*='&t='], a[href*='?t='], a[href*='token='], a[href*='hash='], a#babay, a.btn-download"
        )) {
          return true;
        }
        const bodyText = document.body ? (document.body.innerText || "").slice(0, 500) : "";
        return /(redirect\s*ready|go\s*to\s*link|link\s*ready|please\s*wait\s*a\s*moment)/i.test(bodyText);
      }, false);
    }
    function has5to30CountdownOnPage() {
      if (state.captchaDetected || state.tempAllowActive || isServerTokenShortlinkPage()) return false;
      return safeTry("main_world.countdownScan", () => {
        const nodes = document.querySelectorAll(
          "[id*='count'], [class*='count'], [id*='timer'], [class*='timer'], [id*='wait'], [class*='wait'], [class*='skip'], [id*='skip'], [class*='ad-text'], [class*='preroll']"
        );
        for (const el of nodes) {
          if (
            /** @type {HTMLElement} */
            el.offsetParent === null
          ) continue;
          const txt = (
            /** @type {HTMLElement} */
            (el.innerText || "").trim()
          );
          if (!txt || txt.length > 80) continue;
          if (/\b([5-9]|[12][0-9]|30)\b/.test(txt) && /(detik|sec|second|wait|tunggu|skip|lewati|iklan|ad|link|siap|ready|please|harap|^([5-9]|[12][0-9]|30)s?$)/i.test(
            txt
          )) {
            return true;
          }
        }
        return false;
      }, false);
    }
    function canAccelerateTimer(fn) {
      if (!state.autoSkipCountdown || state.captchaDetected || state.tempAllowActive || win._cf_chl_opt || isCaptchaChallengeUrl(location.href) || isDomainInList(location.href, state.trusted) || isProtectedFrameworkCallback(fn)) {
        return false;
      }
      return has5to30CountdownOnPage();
    }
    window.setInterval = maskAsNative(function(fn, delay) {
      let d = Number(delay);
      if (Number.isFinite(d) && d >= 800 && d <= 1250 && canAccelerateTimer(fn)) {
        d = 40;
      }
      return origSetInterval.call(this, fn, d);
    }, origSetInterval);
    window.setTimeout = maskAsNative(function(fn, delay) {
      let d = Number(delay);
      if (Number.isFinite(d) && canAccelerateTimer(fn)) {
        if (d >= 5e3 && d <= 30500) d = 300;
        else if (d >= 800 && d <= 1250) d = 40;
      }
      return origSetTimeout.call(this, fn, d);
    }, origSetTimeout);
    window.dispatchEvent(new CustomEvent(BRIDGE_EVENTS.REQUEST_RULES));
  })();
})();
