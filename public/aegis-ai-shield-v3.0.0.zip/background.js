// AEGIS-AI Shield v3.0.0 — Bundled MV3 Background Service Worker (esbuild)
(() => {
  // src/ext/shared/constants.js
  var GEMINI_MODEL = "gemini-2.5-flash";
  var DEFAULT_TRUSTED_DOMAINS = [
    "semprot.com",
    "kaskus.co.id",
    "reddit.com"
  ];
  var TIMINGS = Object.freeze({
    DNR_DEBOUNCE_MS: 350,
    DNR_BATCH_SIZE: 150,
    DNR_FALLBACK_MAX_RULES: 5e3,
    TAB_HISTORY_TTL_MS: 2 * 60 * 60 * 1e3,
    TAB_HISTORY_CLEANUP_INTERVAL_MS: 15 * 60 * 1e3,
    LOG_FLUSH_DEBOUNCE_MS: 220,
    MAX_LOGS: 120,
    OBSERVER_DEBOUNCE_MS: 200,
    AUTO_SKIP_INTERVAL_MS: 1e3,
    BYPASS_TOAST_MS: 800,
    BYPASS_TOAST_MAX_WAIT_MS: 1100,
    SHORTLINK_CTA_GRACE_MS: 9e3,
    AUTH_GRACE_MS: 3e4,
    FIRST_PAGE_GRACE_MS: 6e3,
    REVERT_COOLDOWN_MS: 2200,
    LOOP_LOCK_MS: 15e3,
    USER_GESTURE_WINDOW_MS: 1800,
    AUTH_GESTURE_WINDOW_MS: 6e3,
    HISTORY_FLOOD_WINDOW_MS: 1500,
    HISTORY_FLOOD_MAX_CALLS: 6
  });
  var BRIDGE_EVENTS = Object.freeze({
    HANDSHAKE_INIT: "__AEGIS_HANDSHAKE_INIT__",
    REQUEST_RULES: "__AEGIS_REQUEST_RULES__",
    SYNC_RULES: "__AEGIS_SYNC_RULES__",
    CAPTCHA_SIGNAL: "__AEGIS_CAPTCHA_SIGNAL__",
    SHORTLINK_CTA_CLICK: "__AEGIS_SHORTLINK_CTA_CLICK__",
    AUTH_GESTURE: "__AEGIS_AUTH_GESTURE__",
    BLOCKED_EVENT: "__AEGIS_BLOCKED_EVENT__",
    VIDEO_DETECTED: "__AEGIS_VIDEO_DETECTED__",
    AUTO_SKIPPED: "__AEGIS_AUTO_SKIPPED__",
    LOG_EVENT: "__AEGIS_LOG_EVENT__"
  });
  var DEFAULT_GLOBAL_SETTINGS = Object.freeze({
    protectionMode: "balanced",
    // "balanced" | "strict"
    popupTheme: "dark",
    // "dark" | "light"
    sessionOnlyApiKey: false,
    debugInternalErrors: false,
    hudEnabled: true,
    hudDurationSec: 4.5,
    hudPosition: "top-center",
    hudOpacity: 0.95,
    hudScale: 1,
    hudShowTrust: true,
    hudShowGroup: true,
    hudShowOpen: true,
    hudShowBlock: true,
    hudShowUrlDetail: true,
    videoDockEnabled: true,
    videoDockDimSec: 2.5,
    videoDockExpandDir: "auto",
    videoPillScale: 1,
    videoPillOpacity: 0.95,
    videoPillShowPlayPause: true,
    videoPillShowList: true,
    videoPillShowDownload: true,
    videoPillShowPip: true,
    videoPillShowFullscreen: true,
    pipSize: "medium",
    pipOpacity: 0.95,
    adSkipSpeed: "16",
    smartUgcSense: true,
    shortlinkBypassEnabled: true,
    shortlinkAutoClick: true,
    loggingEnabled: true,
    removeTransparentOverlay: true,
    antiHistoryTrap: true,
    dnrEnabled: true,
    redirectWindowSec: 3.5
  });
  var DEFAULT_HUD_POSITIONS = Object.freeze({
    topHud: null,
    videoDock: null,
    miniPip: null
  });
  var DEFAULT_STATS = Object.freeze({
    blocked: 0,
    bypassed: 0,
    allowed: 0
  });
  var SUSPICIOUS_TLD = /\.(cfd|xyz|top|cyou|icu|buzz|click|link|monster|quest|rest|sbs|shop|site|tokyo|vip|wang|win|work|wtf|zone|live|asia|online|store|fun|pro|club|cam|cc|me|pw|tk|ml|ga|cf|gq)$/i;
  var GAMBLING_KEYWORDS = /(slot|gacor|maxwin|zeus|pragmatic|togel|judol|casino|betting|scatter|rtp|deposit|wd|bonus100|situsresmi|linkalternatif|sbobet|poker|judi|bandar|slot88|gacor88|pascol4d|dewadora|toto4d)/i;
  var COMMERCE_AFFILIATE_REGEX = /(shopee\.|shope\.ee|tokopedia\.|lazada\.|blibli\.|bukalapak\.|tiktok\.com\/t\/|invol\.co|accesstrade|admitad|ecotrack|go2cloud|onclickalgo|popads|popcash|propellerads|adsterra|hilltopads|exoclick|juicyads|trafficjunky|monetag|richads|wpadmngr|clickadu)/i;
  var RANDOM_SHORT_DOMAIN_REGEX = /^[a-z0-9]{2,4}[0-9][a-z0-9]{1,4}\.(com|net|org|co|id|io|info|biz)$/i;
  var SEARCH_ARBITRAGE_PARAMS = /(utm_source=.*ad|utm_medium=affiliate|af_siteid=|af_sub|clickid=|click_id=|subid=|sub_id=|aff_id=|zoneid=|bannerid=|popunder|redirect|gclid=|fbclid=.*ad)/i;
  var SAFE_MEDIA_HOST_REGEX = /(^|\.)(ibb\.co|ibb\.co\.com|imgur\.com|postimg\.cc|pixhost\.to|imgbox\.com|imagebam\.com|prnt\.sc|prntscr\.com|gyazo\.com|flickr\.com|staticflickr\.com|wikimedia\.org|tenor\.com|giphy\.com|redgifs\.com|catbox\.moe|bunkr\.(si|ru|is|la|sk|ax|ac|black|red|media|site)|cyberdrop\.(me|to|cc)|pixeldrain\.com|gofile\.io|mega\.nz|mediafire\.com|drive\.google\.com|docs\.google\.com|dropbox\.com)$/i;
  var KNOWN_AD_SHORTENER_REGEX = /(^|\.)(optional\.me|see\.optional\.me|rebrand\.ly|bit\.ly|t\.ly|tinyurl\.com|is\.gd|v\.gd|cutt\.ly|shorturl\.at|ouo\.io|shrinkme\.io|exe\.io|bc\.vc|adf\.ly|linkvertise\.com)$/i;
  var SEARCH_ENGINE_HOST_REGEX = /(^|\.)(google\.[a-z.]+|bing\.com|duckduckgo\.com|search\.yahoo\.com|yandex\.[a-z.]+|ya\.ru|search\.brave\.com|ecosia\.org|startpage\.com|baidu\.com)$/i;
  var MESSENGER_OR_SOCIAL_ENTRY_REGEX = /(^|\.)(t\.me|telegram\.me|telegram\.org|telegra\.ph|wa\.me|whatsapp\.com|l\.wl\.co|l\.facebook\.com|lm\.facebook\.com|l\.instagram\.com|t\.co|redd\.it|out\.reddit\.com|discord\.com|discordapp\.com|line\.me)$/i;
  var AUTH_PATH_OR_PARAM_REGEX = /(\/(login|signin|sign-in|log-in|auth|oauth|oauth2|sso|saml|openid|oidc|authorize|callback|session|account|accounts|passport|idp|cas|connect\/authorize|v2\/auth|cdn-cgi\/challenge-platform)(\/|$)|[?&](client_id|redirect_uri|response_type|state|scope|openid|code_challenge|samlrequest|return_to|continue|_xfRedirect|__cf_chl_tk|__cf_chl_rt_tk|__cf_chl_f_tk)=)/i;
  var AUTH_SUBDOMAIN_REGEX = /^(accounts|auth|login|signin|sso|id|oauth|passport|idp|iam|auth0|okta)\./i;
  var AUTH_PROVIDER_HOST_REGEX = /(^|\.)(auth0\.com|okta\.com|onelogin\.com|cloudflareaccess\.com|login\.microsoftonline\.com|accounts\.google\.com|appleid\.apple\.com|github\.com)$/i;
  var CHALLENGE_HOST_REGEX = /(challenges\.cloudflare\.com|cloudflarecaptcha\.com|hcaptcha\.com|recaptcha\.net|gstatic\.com\/recaptcha|arkoselabs\.com|funcaptcha\.com|captcha-delivery\.com|datadome\.co|perimeterx\.net|dnstest\.dev)/i;
  var SAFE_ECOSYSTEM_GROUPS = [
    /(^|\.)(yandex\.(com|ru|kz|by|uz|ua|tr|net)|ya\.ru|yastatic\.net)$/i,
    /(^|\.)(google\.(com|co\.id|com\.sg|com\.my)|googleapis\.com|gstatic\.com|youtube\.com|youtu\.be)$/i,
    /(^|\.)(microsoft\.com|live\.com|bing\.com|msn\.com|microsoftonline\.com|login\.windows\.net)$/i,
    /(^|\.)(apple\.com|icloud\.com)$/i,
    /(^|\.)(github\.com|githubusercontent\.com)$/i,
    /(^|\.)(facebook\.com|fb\.com|instagram\.com)$/i,
    /(^|\.)(discord\.com|discordapp\.com)$/i
  ];

  // src/ext/shared/debug.js
  var debugEnabled = false;
  var debugSink = null;
  function setDebugEnabled(enabled) {
    debugEnabled = Boolean(enabled);
  }
  function setDebugSink(sinkFn) {
    debugSink = typeof sinkFn === "function" ? sinkFn : null;
  }
  function logInternalError(scope, err) {
    if (!debugEnabled || !debugSink) return;
    try {
      const message = err instanceof Error ? `${err.name}: ${err.message}` : String(err || "Unknown internal error");
      debugSink({
        scope: String(scope || "internal"),
        message: message.slice(0, 260)
      });
    } catch {
    }
  }
  function safeTry(scope, fn, fallback) {
    try {
      return fn();
    } catch (err) {
      logInternalError(scope, err);
      return (
        /** @type {T} */
        fallback
      );
    }
  }

  // src/ext/shared/domain-utils.js
  var SECOND_LEVEL_PUBLIC_SUFFIXES = /* @__PURE__ */ new Set([
    "co",
    "com",
    "net",
    "org",
    "ac",
    "go",
    "or",
    "web",
    "sch"
  ]);
  var VALID_DOMAIN_REGEX = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i;
  function getHostname(urlStr, baseHref) {
    if (!urlStr) return "";
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      return (u.hostname || "").toLowerCase();
    } catch {
      return "";
    }
  }
  function getBaseDomain(hostname) {
    const clean = String(hostname || "").trim().toLowerCase().replace(/^www\./, "");
    const parts = clean.split(".").filter(Boolean);
    if (parts.length <= 2) return clean;
    const sld = parts[parts.length - 2];
    if (SECOND_LEVEL_PUBLIC_SUFFIXES.has(sld) && parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  function normalizeDomainEntry(raw) {
    if (!raw) return "";
    let val = String(raw).trim().toLowerCase();
    if (!val) return "";
    try {
      if (val.includes("://")) {
        val = new URL(val).hostname.toLowerCase();
      } else {
        val = val.replace(/^\|\|/, "").replace(/\^.*$/, "").replace(/^\*\./, "").split("/")[0].split("?")[0].split("#")[0].split(":")[0];
      }
    } catch {
      val = val.split("/")[0].split("?")[0].split("#")[0];
    }
    val = val.replace(/^www\./, "").trim();
    if (!val || !VALID_DOMAIN_REGEX.test(val)) return "";
    return val;
  }
  function isDomainInList(urlStr, list, baseHref) {
    if (!urlStr || !Array.isArray(list) || list.length === 0) return false;
    const host = getHostname(urlStr, baseHref).replace(/^www\./, "");
    if (!host) return false;
    const base = getBaseDomain(host);
    for (const item of list) {
      const rule = normalizeDomainEntry(item);
      if (!rule) continue;
      const ruleBase = getBaseDomain(rule);
      if (host === rule || base === rule || host === ruleBase || base === ruleBase || host.endsWith("." + rule) || host.endsWith("." + ruleBase)) {
        return true;
      }
    }
    return false;
  }
  function isSameSafeEcosystem(hostA, hostB) {
    if (!hostA || !hostB) return false;
    return SAFE_ECOSYSTEM_GROUPS.some((rx) => rx.test(hostA) && rx.test(hostB));
  }
  function getTemporaryAllowState(tempAllowMap, urlStr, now = Date.now()) {
    if (!tempAllowMap || typeof tempAllowMap !== "object" || !urlStr) {
      return { active: false, domain: "", remainingMs: 0 };
    }
    const host = getHostname(urlStr).replace(/^www\./, "");
    if (!host) return { active: false, domain: "", remainingMs: 0 };
    const base = getBaseDomain(host);
    const candidates = [host, base];
    for (const key of candidates) {
      const exp = Number(tempAllowMap[key]);
      if (Number.isFinite(exp) && exp > now) {
        return { active: true, domain: key, remainingMs: exp - now };
      }
    }
    return { active: false, domain: "", remainingMs: 0 };
  }
  function pruneExpiredTempAllows(tempAllowMap, now = Date.now()) {
    const next = {};
    if (!tempAllowMap || typeof tempAllowMap !== "object") return next;
    for (const [dom, exp] of Object.entries(tempAllowMap)) {
      if (Number.isFinite(Number(exp)) && Number(exp) > now) {
        next[dom] = Number(exp);
      }
    }
    return next;
  }

  // src/ext/shared/dnr-builder.js
  var DNR_BLOCKED_RESOURCE_TYPES = [
    "main_frame",
    "sub_frame",
    "script",
    "xmlhttprequest",
    "ping",
    "other"
  ];
  function buildConsolidatedDnrRules(deniedDomains, maxDynamicRules = TIMINGS.DNR_FALLBACK_MAX_RULES, batchSize = TIMINGS.DNR_BATCH_SIZE) {
    const safeMaxRules = Math.max(1, Math.min(3e4, Number(maxDynamicRules) || TIMINGS.DNR_FALLBACK_MAX_RULES));
    const safeBatchSize = Math.max(1, Math.min(500, Number(batchSize) || TIMINGS.DNR_BATCH_SIZE));
    const uniqueHosts = Array.from(
      new Set((Array.isArray(deniedDomains) ? deniedDomains : []).map(normalizeDomainEntry).filter(Boolean))
    );
    const maxSupportedDomains = safeMaxRules * safeBatchSize;
    const effectiveHosts = uniqueHosts.slice(0, maxSupportedDomains);
    const truncatedCount = Math.max(0, uniqueHosts.length - effectiveHosts.length);
    const rules = [];
    for (let i = 0; i < effectiveHosts.length; i += safeBatchSize) {
      const chunk = effectiveHosts.slice(i, i + safeBatchSize);
      rules.push({
        id: rules.length + 1,
        priority: 1,
        action: { type: "block" },
        condition: {
          requestDomains: chunk,
          resourceTypes: DNR_BLOCKED_RESOURCE_TYPES
        }
      });
    }
    return {
      rules,
      totalDomains: effectiveHosts.length,
      ruleCount: rules.length,
      truncatedCount,
      maxRules: safeMaxRules
    };
  }

  // src/ext/shared/gemini-audit.js
  function parseGeminiAuditResponse(rawText) {
    const fallback = { realIndex: -1, blockedIndices: [] };
    if (typeof rawText !== "string" || !rawText.trim()) return fallback;
    const cleaned = rawText.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
    const tryParseObject = (candidate) => {
      try {
        const parsed = JSON.parse(candidate);
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          const realIndex = Number.isInteger(parsed.realIndex) ? parsed.realIndex : -1;
          const blockedIndices = Array.isArray(parsed.blockedIndices) ? parsed.blockedIndices.filter((n) => typeof n === "number" && Number.isInteger(n) && n >= 0) : [];
          return { realIndex, blockedIndices };
        }
      } catch {
        return null;
      }
      return null;
    };
    const direct = tryParseObject(cleaned);
    if (direct) return direct;
    const firstBrace = cleaned.indexOf("{");
    const lastBrace = cleaned.lastIndexOf("}");
    if (firstBrace !== -1 && lastBrace > firstBrace) {
      const sliced = tryParseObject(cleaned.slice(firstBrace, lastBrace + 1));
      if (sliced) return sliced;
    }
    return fallback;
  }

  // src/ext/shared/url-classifier.js
  function isAuthFlowUrl(urlStr) {
    if (!urlStr) return false;
    try {
      const u = new URL(urlStr);
      const host = u.hostname.toLowerCase();
      return AUTH_SUBDOMAIN_REGEX.test(host) || AUTH_PROVIDER_HOST_REGEX.test(host) || AUTH_PATH_OR_PARAM_REGEX.test(u.pathname + u.search);
    } catch {
      return false;
    }
  }
  function isHardMaliciousUrl(urlStr, deniedList = [], baseHref) {
    if (!urlStr) return false;
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      const host = u.hostname.toLowerCase();
      const baseHost = getBaseDomain(host);
      if (isDomainInList(u.href, deniedList)) return true;
      return GAMBLING_KEYWORDS.test(u.href) || COMMERCE_AFFILIATE_REGEX.test(u.href) || RANDOM_SHORT_DOMAIN_REGEX.test(baseHost) || SEARCH_ARBITRAGE_PARAMS.test(u.href) || KNOWN_AD_SHORTENER_REGEX.test(host);
    } catch {
      return false;
    }
  }
  function isSuspiciousUrl(urlStr, rules = { trusted: [], denied: [], strictCrossOrigin: true, protectionMode: "balanced" }, sourceUrl = "", isRecentlyAllowedFn) {
    try {
      const u = new URL(urlStr);
      const host = u.hostname.toLowerCase();
      const baseHost = getBaseDomain(host);
      if (isDomainInList(urlStr, rules.trusted || [])) return false;
      if (typeof isRecentlyAllowedFn === "function" && isRecentlyAllowedFn(urlStr)) return false;
      if (isDomainInList(urlStr, rules.denied || [])) return true;
      if (CHALLENGE_HOST_REGEX.test(host)) return false;
      if (sourceUrl) {
        try {
          const srcHost = new URL(sourceUrl).hostname.toLowerCase();
          if (isSameSafeEcosystem(srcHost, host)) return false;
        } catch {
        }
      }
      const hasHardAdSignals = GAMBLING_KEYWORDS.test(u.href) || COMMERCE_AFFILIATE_REGEX.test(u.href) || RANDOM_SHORT_DOMAIN_REGEX.test(baseHost) || SEARCH_ARBITRAGE_PARAMS.test(u.href) || KNOWN_AD_SHORTENER_REGEX.test(host);
      if (hasHardAdSignals) return true;
      if (SAFE_MEDIA_HOST_REGEX.test(host)) return false;
      if (SUSPICIOUS_TLD.test(host)) return true;
      const isSearch = host.includes("google.") && u.pathname === "/search" || host.includes("bing.com") && u.pathname === "/search" || host.includes("duckduckgo.com") && u.pathname === "/" || host.includes("search.yahoo.com") && u.pathname.startsWith("/search");
      if (isSearch) {
        const q = u.searchParams.get("q") || "";
        if (SEARCH_ARBITRAGE_PARAMS.test(u.href) || GAMBLING_KEYWORDS.test(q)) return true;
        if (sourceUrl) {
          try {
            const srcHost = new URL(sourceUrl).hostname.toLowerCase();
            if (!SEARCH_ENGINE_HOST_REGEX.test(srcHost)) {
              return true;
            }
          } catch {
          }
        }
      }
      return false;
    } catch {
      return false;
    }
  }

  // src/ext/background/index.js
  var tabHistory = /* @__PURE__ */ new Map();
  var recentlyAllowedTargets = /* @__PURE__ */ new Map();
  var lastTabHistoryCleanup = 0;
  var aegisLogsCache = [];
  var aegisLogsLoaded = false;
  var aegisLogFlushTimer = null;
  var aegisLoggingEnabled = true;
  var aegisStatsCache = { ...DEFAULT_STATS };
  var aegisStatsLoaded = false;
  var aegisStatsFlushTimer = null;
  var tempAllowCache = {};
  var tempAllowLoaded = false;
  async function ensureLogsLoaded() {
    if (aegisLogsLoaded) return aegisLogsCache;
    try {
      const res = await chrome.storage.local.get(["aegisLogs", "globalSettings"]);
      aegisLogsCache = Array.isArray(res.aegisLogs) ? res.aegisLogs.slice(0, TIMINGS.MAX_LOGS) : [];
      const g = res.globalSettings && typeof res.globalSettings === "object" ? res.globalSettings : {};
      aegisLoggingEnabled = g.loggingEnabled !== false;
      setDebugEnabled(Boolean(g.debugInternalErrors));
      aegisLogsLoaded = true;
    } catch {
      aegisLogsLoaded = true;
    }
    return aegisLogsCache;
  }
  function scheduleLogFlush() {
    clearTimeout(aegisLogFlushTimer);
    aegisLogFlushTimer = setTimeout(() => {
      safeTry("background.flushLogs", () => {
        chrome.storage.local.set({ aegisLogs: aegisLogsCache.slice(0, TIMINGS.MAX_LOGS) });
      });
    }, TIMINGS.LOG_FLUSH_DEBOUNCE_MS);
  }
  async function ensureStatsLoaded() {
    if (aegisStatsLoaded) return aegisStatsCache;
    try {
      const res = await chrome.storage.local.get(["aegisStats"]);
      const s = res.aegisStats && typeof res.aegisStats === "object" ? res.aegisStats : {};
      aegisStatsCache = {
        blocked: Number(s.blocked) || 0,
        bypassed: Number(s.bypassed) || 0,
        allowed: Number(s.allowed) || 0
      };
      aegisStatsLoaded = true;
    } catch {
      aegisStatsLoaded = true;
    }
    return aegisStatsCache;
  }
  async function incrementLocalStat(kind) {
    await ensureStatsLoaded();
    if (kind === "BLOCK") aegisStatsCache.blocked += 1;
    else if (kind === "BYPASS") aegisStatsCache.bypassed += 1;
    else if (kind === "ALLOW") aegisStatsCache.allowed += 1;
    else return;
    clearTimeout(aegisStatsFlushTimer);
    aegisStatsFlushTimer = setTimeout(() => {
      safeTry("background.flushStats", () => {
        chrome.storage.local.set({ aegisStats: { ...aegisStatsCache } });
      });
    }, 300);
  }
  async function ensureTempAllowLoaded() {
    if (tempAllowLoaded) {
      tempAllowCache = pruneExpiredTempAllows(tempAllowCache);
      return tempAllowCache;
    }
    try {
      const storageArea = chrome.storage.session || chrome.storage.local;
      const res = await storageArea.get(["tempAllowMap"]);
      tempAllowCache = pruneExpiredTempAllows(res.tempAllowMap || {});
      tempAllowLoaded = true;
    } catch {
      tempAllowLoaded = true;
    }
    return tempAllowCache;
  }
  async function saveTempAllowMap(nextMap) {
    tempAllowCache = pruneExpiredTempAllows(nextMap);
    tempAllowLoaded = true;
    try {
      if (chrome.storage.session) {
        await chrome.storage.session.set({ tempAllowMap: tempAllowCache });
      }
      await chrome.storage.local.set({ tempAllowMap: tempAllowCache });
    } catch (err) {
      logInternalError("background.saveTempAllowMap", err);
    }
  }
  async function appendAegisLog(entry) {
    await ensureLogsLoaded();
    const level = String(entry.level || "WARN").toUpperCase();
    if (level === "BLOCK" || level === "BYPASS" || level === "ALLOW") {
      incrementLocalStat(level);
    }
    if (!aegisLoggingEnabled && level !== "DEBUG") return;
    const item = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      ts: Date.now(),
      level,
      source: String(entry.source || "background"),
      code: String(entry.code || "EVENT"),
      fromUrl: String(entry.fromUrl || "").slice(0, 220),
      toUrl: entry.toUrl ? String(entry.toUrl).slice(0, 220) : "",
      detail: String(entry.detail || "").slice(0, 320)
    };
    aegisLogsCache.unshift(item);
    if (aegisLogsCache.length > TIMINGS.MAX_LOGS) {
      aegisLogsCache = aegisLogsCache.slice(0, TIMINGS.MAX_LOGS);
    }
    scheduleLogFlush();
  }
  setDebugSink(({ scope, message }) => {
    appendAegisLog({
      level: "DEBUG",
      source: "background",
      code: `ERR_${scope.toUpperCase().replace(/[^A-Z0-9_]/g, "_")}`,
      fromUrl: "chrome://service-worker",
      detail: message
    });
  });
  async function cleanupStaleTabHistory(verifyOpenTabs = true) {
    const now = Date.now();
    lastTabHistoryCleanup = now;
    let activeTabIds = null;
    if (verifyOpenTabs && chrome.tabs && typeof chrome.tabs.query === "function") {
      try {
        const openTabs = await chrome.tabs.query({});
        activeTabIds = new Set(
          openTabs.map((t) => t && t.id).filter((id) => typeof id === "number")
        );
      } catch (err) {
        logInternalError("background.cleanupTabsQuery", err);
        activeTabIds = null;
      }
    }
    for (const [tabId, entry] of tabHistory.entries()) {
      const isClosedTab = activeTabIds !== null && !activeTabIds.has(tabId);
      const isExpired = Boolean(
        entry && entry.lastTimestamp > 0 && now - entry.lastTimestamp > TIMINGS.TAB_HISTORY_TTL_MS
      );
      if (isClosedTab || isExpired) {
        tabHistory.delete(tabId);
      }
    }
  }
  setInterval(() => {
    cleanupStaleTabHistory(true);
  }, TIMINGS.TAB_HISTORY_CLEANUP_INTERVAL_MS);
  function allowManualTarget(urlStr, durationMs = 25e3) {
    if (!urlStr) return;
    const exp = Date.now() + durationMs;
    recentlyAllowedTargets.set(urlStr, exp);
    safeTry("background.allowManualTarget", () => {
      const host = getHostname(urlStr);
      const base = getBaseDomain(host);
      if (host) recentlyAllowedTargets.set(`host:${host}`, exp);
      if (base) recentlyAllowedTargets.set(`host:${base}`, exp);
    });
  }
  function isTargetRecentlyAllowed(urlStr) {
    if (!urlStr) return false;
    const now = Date.now();
    for (const [k, exp] of recentlyAllowedTargets.entries()) {
      if (now > exp) recentlyAllowedTargets.delete(k);
    }
    const directExp = recentlyAllowedTargets.get(urlStr);
    if (directExp && now <= directExp) return true;
    const host = getHostname(urlStr);
    const base = getBaseDomain(host);
    const hostExp = recentlyAllowedTargets.get(`host:${host}`);
    const baseExp = recentlyAllowedTargets.get(`host:${base}`);
    return Boolean(hostExp && now <= hostExp || baseExp && now <= baseExp);
  }
  async function getDomainRules() {
    const data = await chrome.storage.local.get([
      "trustedDomains",
      "deniedDomains",
      "strictCrossOrigin",
      "globalSettings"
    ]);
    const g = data.globalSettings && typeof data.globalSettings === "object" ? data.globalSettings : {};
    const winSec = Number(g.redirectWindowSec);
    const protectionMode = g.protectionMode === "strict" || g.protectionMode === "balanced" ? g.protectionMode : data.strictCrossOrigin === false ? "balanced" : "balanced";
    const strictCrossOrigin = protectionMode === "strict" || g.protectionMode === void 0 && data.strictCrossOrigin === true;
    aegisLoggingEnabled = g.loggingEnabled !== false;
    setDebugEnabled(Boolean(g.debugInternalErrors));
    const tempAllowMap = await ensureTempAllowLoaded();
    return {
      trusted: Array.isArray(data.trustedDomains) ? data.trustedDomains : [],
      denied: Array.isArray(data.deniedDomains) ? data.deniedDomains : [],
      protectionMode,
      strictCrossOrigin,
      tempAllowMap,
      smartUgcSense: g.smartUgcSense !== false,
      shortlinkBypassEnabled: g.shortlinkBypassEnabled !== false,
      shortlinkAutoClick: g.shortlinkAutoClick !== false,
      loggingEnabled: g.loggingEnabled !== false,
      redirectWindowMs: Number.isFinite(winSec) && winSec >= 1 ? winSec * 1e3 : 3500,
      dnrEnabled: g.dnrEnabled !== false
    };
  }
  function getSafeReturnUrl(tabId, currentMaliciousUrl, rules) {
    const entry = tabHistory.get(tabId);
    if (!entry || !entry.stack || entry.stack.length === 0) return null;
    for (let i = entry.stack.length - 1; i >= 0; i--) {
      const candidate = entry.stack[i];
      if (candidate && candidate !== currentMaliciousUrl && !isDomainInList(candidate, rules.denied)) {
        return candidate;
      }
    }
    return null;
  }
  function ensureTabEntry(tabId) {
    const now = Date.now();
    if (tabHistory.size > 40 && now - lastTabHistoryCleanup > TIMINGS.TAB_HISTORY_CLEANUP_INTERVAL_MS) {
      cleanupStaleTabHistory(true);
    }
    if (!tabHistory.has(tabId)) {
      tabHistory.set(tabId, {
        stack: [],
        lastTimestamp: now,
        lastRevertTime: 0,
        revertCount: 0,
        lockedUntil: 0,
        manualAllowedUrl: "",
        manualAllowedUntil: 0,
        authGraceUntil: 0,
        firstPageGraceUntil: 0,
        shortlinkCtaGraceUntil: 0,
        shortlinkCtaSourceHost: "",
        pendingPrompts: []
      });
    }
    return tabHistory.get(tabId);
  }
  function isManuallyAllowed(entry, targetUrl) {
    if (isTargetRecentlyAllowed(targetUrl)) return true;
    if (!entry) return false;
    const now = Date.now();
    if (entry.authGraceUntil && now < entry.authGraceUntil) return true;
    if (!entry.manualAllowedUrl) return false;
    if (now > entry.manualAllowedUntil) {
      entry.manualAllowedUrl = "";
      return false;
    }
    const allowedHost = getHostname(entry.manualAllowedUrl);
    const targetHost = getHostname(targetUrl);
    return entry.manualAllowedUrl === targetUrl || Boolean(allowedHost) && allowedHost === targetHost;
  }
  function forceRevertTab(tabId, fallbackUrl, blockedUrl, reasonMsg, silentBlacklist = false, deniedList = []) {
    const now = Date.now();
    const entry = ensureTabEntry(tabId);
    if (now - entry.lastRevertTime < TIMINGS.REVERT_COOLDOWN_MS) return;
    if (now - entry.lastRevertTime < 1e4) {
      entry.revertCount += 1;
    } else {
      entry.revertCount = 1;
    }
    entry.lastRevertTime = now;
    if (entry.revertCount > 2) {
      entry.lockedUntil = now + TIMINGS.LOOP_LOCK_MS;
    }
    const isDenied = silentBlacklist || isDomainInList(blockedUrl, deniedList);
    if (!isDenied && blockedUrl && blockedUrl.startsWith("http")) {
      const exists = entry.pendingPrompts.some((p) => p.blockedUrl === blockedUrl);
      if (!exists) {
        entry.pendingPrompts.push({
          blockedUrl,
          message: entry.revertCount > 2 ? "Loop diputus (jeda 15d)" : reasonMsg,
          kind: "redirect"
        });
        if (entry.pendingPrompts.length > 10) entry.pendingPrompts.shift();
      }
    } else if (isDenied && Array.isArray(entry.pendingPrompts) && entry.pendingPrompts.length > 0) {
      entry.pendingPrompts = entry.pendingPrompts.filter((p) => !isDomainInList(p.blockedUrl, deniedList));
    }
    tabHistory.set(tabId, entry);
    if (fallbackUrl) {
      chrome.tabs.update(tabId, { url: fallbackUrl });
    }
  }
  chrome.webNavigation.onCommitted.addListener(async (details) => {
    if (details.frameId !== 0) return;
    const url = details.url;
    if (!url || !url.startsWith("http")) return;
    const rules = await getDomainRules();
    const entry = ensureTabEntry(details.tabId);
    const now = Date.now();
    const qualifiers = details.transitionQualifiers || [];
    const isForwardBack = qualifiers.includes("forward_back");
    const isBlacklisted = isDomainInList(url, rules.denied);
    if (isBlacklisted) {
      const safeUrl = getSafeReturnUrl(details.tabId, url, rules);
      appendAegisLog({
        level: "BLOCK",
        source: "background",
        code: "BLACKLIST_SILENT_REVERT",
        fromUrl: safeUrl || entry.stack[entry.stack.length - 1] || url,
        toUrl: url,
        detail: `Domain Blacklist diblokir senyap (transition=${details.transitionType}, qualifiers=${qualifiers.join(",") || "none"})`
      });
      if (safeUrl) {
        forceRevertTab(details.tabId, safeUrl, url, "Domain Blacklist diblokir senyap", true, rules.denied);
      }
      return;
    }
    const prevUrl = entry.stack[entry.stack.length - 1] || "";
    const tempState = getTemporaryAllowState(rules.tempAllowMap, prevUrl || url, now).active || getTemporaryAllowState(rules.tempAllowMap, url, now).active;
    if (tempState) {
      if (entry.stack[entry.stack.length - 1] !== url) {
        entry.stack.push(url);
        if (entry.stack.length > 15) entry.stack.shift();
      }
      entry.lastTimestamp = now;
      tabHistory.set(details.tabId, entry);
      return;
    }
    if (isForwardBack) {
      const idxInStack = entry.stack.lastIndexOf(url);
      if (idxInStack !== -1) {
        entry.stack = entry.stack.slice(0, idxInStack + 1);
      } else {
        entry.stack.push(url);
        if (entry.stack.length > 15) entry.stack.shift();
      }
      entry.lockedUntil = now + 6e3;
      entry.lastRevertTime = now;
      entry.revertCount = 0;
      entry.lastTimestamp = now;
      tabHistory.set(details.tabId, entry);
      return;
    }
    if (isAuthFlowUrl(url) && !isSuspiciousUrl(url, rules, prevUrl, isTargetRecentlyAllowed)) {
      entry.authGraceUntil = now + TIMINGS.AUTH_GRACE_MS;
    }
    if (isManuallyAllowed(entry, url)) {
      if (entry.stack[entry.stack.length - 1] !== url) {
        entry.stack.push(url);
        if (entry.stack.length > 15) entry.stack.shift();
      }
      entry.lastTimestamp = now;
      tabHistory.set(details.tabId, entry);
      return;
    }
    if (now < entry.lockedUntil) return;
    const isExternalOrFirstPageTransition = entry.stack.length === 0 || details.transitionType === "auto_toplevel" || details.transitionType === "typed" || details.transitionType === "auto_bookmark" || details.transitionType === "generated" || details.transitionType === "start_page" || details.transitionType === "keyword" || qualifiers.includes("from_address_bar") || qualifiers.includes("from_api");
    if (isExternalOrFirstPageTransition) {
      entry.stack = [url];
      entry.revertCount = 0;
      entry.lastTimestamp = now;
      entry.firstPageGraceUntil = now + TIMINGS.FIRST_PAGE_GRACE_MS;
      allowManualTarget(url, 15e3);
      tabHistory.set(details.tabId, entry);
      appendAegisLog({
        level: "ALLOW",
        source: "background",
        code: "ALLOW_FIRST_PAGE",
        fromUrl: url,
        detail: `Halaman awal/eksternal diizinkan (transition=${details.transitionType}, qualifiers=${qualifiers.join(",") || "none"})`
      });
      return;
    }
    if (prevUrl && prevUrl !== url) {
      safeTry("background.onCommittedCrossCheck", () => {
        const prevHost = getHostname(prevUrl);
        const currHost = getHostname(url);
        const prevBase = getBaseDomain(prevHost);
        const currBase = getBaseDomain(currHost);
        const isFromSearchEngine = SEARCH_ENGINE_HOST_REGEX.test(prevHost);
        const isFromMessengerOrSocial = MESSENGER_OR_SOCIAL_ENTRY_REGEX.test(prevHost);
        const isWithinFirstPageCanonicalRedirect = entry.firstPageGraceUntil && now < entry.firstPageGraceUntil && (prevBase === currBase || qualifiers.includes("server_redirect"));
        if (isFromSearchEngine || isFromMessengerOrSocial || isWithinFirstPageCanonicalRedirect) {
          entry.stack.push(url);
          if (entry.stack.length > 15) entry.stack.shift();
          entry.lastTimestamp = now;
          entry.firstPageGraceUntil = now + 4500;
          allowManualTarget(url, 15e3);
          tabHistory.set(details.tabId, entry);
          return;
        }
        if (prevBase !== currBase && !isSameSafeEcosystem(prevHost, currHost)) {
          const isHardMalicious = isHardMaliciousUrl(url, rules.denied);
          const isWithinShortlinkCtaGrace = Boolean(
            entry.shortlinkCtaGraceUntil && now < entry.shortlinkCtaGraceUntil
          );
          if (isWithinShortlinkCtaGrace && !isHardMalicious) {
            entry.stack.push(url);
            if (entry.stack.length > 15) entry.stack.shift();
            entry.lastTimestamp = now;
            entry.shortlinkCtaGraceUntil = 0;
            allowManualTarget(url, 18e3);
            tabHistory.set(details.tabId, entry);
            appendAegisLog({
              level: "ALLOW",
              source: "background",
              code: "ALLOW_SHORTLINK_302",
              fromUrl: prevUrl,
              toUrl: url,
              detail: `HTTP 302 CTA shortlink diizinkan (transition=${details.transitionType}, qualifiers=${qualifiers.join(",") || "none"})`
            });
            return;
          }
          if (SAFE_MEDIA_HOST_REGEX.test(currHost) && !isHardMalicious) {
            entry.stack.push(url);
            if (entry.stack.length > 15) entry.stack.shift();
            entry.lastTimestamp = now;
            tabHistory.set(details.tabId, entry);
            return;
          }
          const isSuspicious = isSuspiciousUrl(url, rules, prevUrl, isTargetRecentlyAllowed);
          const isIntentionalUserNav = (details.transitionType === "link" || details.transitionType === "form_submit") && !qualifiers.includes("server_redirect");
          const isAuthJump = isAuthFlowUrl(url) || isAuthFlowUrl(prevUrl);
          const elapsedMs = now - entry.lastTimestamp;
          const isRapidAutoRedirect = rules.strictCrossOrigin && !isIntentionalUserNav && !isAuthJump && (elapsedMs < rules.redirectWindowMs || qualifiers.includes("client_redirect") || qualifiers.includes("server_redirect"));
          if (isSuspicious || isRapidAutoRedirect) {
            const safeUrl = getSafeReturnUrl(details.tabId, url, rules) || prevUrl;
            appendAegisLog({
              level: "BLOCK",
              source: "background",
              code: isSuspicious ? "BLOCK_SUSPICIOUS_COMMIT" : "BLOCK_RAPID_REDIRECT_REVERT",
              fromUrl: prevUrl,
              toUrl: url,
              detail: `Revert -> ${safeUrl} | mode=${rules.protectionMode} | reason=${isSuspicious ? "suspicious_url" : "strict_cross_origin_redirect"} | transition=${details.transitionType} | qualifiers=${qualifiers.join(",") || "none"} | elapsed=${elapsedMs}ms`
            });
            forceRevertTab(
              details.tabId,
              safeUrl,
              url,
              isSuspicious ? "Redirect iklan/affiliate ditahan" : "Auto-redirect lintas domain ditahan",
              false,
              rules.denied
            );
            return;
          }
        }
      });
    }
    if (!isSuspiciousUrl(url, rules, prevUrl, isTargetRecentlyAllowed) || entry.stack.length === 0) {
      if (entry.stack[entry.stack.length - 1] !== url) {
        entry.stack.push(url);
        if (entry.stack.length > 15) entry.stack.shift();
        if (now - entry.lastRevertTime > 4e3) entry.revertCount = 0;
      }
      entry.lastTimestamp = now;
      tabHistory.set(details.tabId, entry);
    }
  });
  chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
    if (details.frameId !== 0) return;
    const targetUrl = details.url;
    if (!targetUrl || !targetUrl.startsWith("http")) return;
    const rules = await getDomainRules();
    const entry = ensureTabEntry(details.tabId);
    const now = Date.now();
    const isTargetBlacklisted = isDomainInList(targetUrl, rules.denied);
    if (isAuthFlowUrl(targetUrl) && !isSuspiciousUrl(targetUrl, rules, "", isTargetRecentlyAllowed)) {
      entry.authGraceUntil = now + TIMINGS.AUTH_GRACE_MS;
    }
    if (!isTargetBlacklisted && isManuallyAllowed(entry, targetUrl)) return;
    if (entry.stack.length === 0) return;
    const currentUrl = entry.stack[entry.stack.length - 1];
    if (!currentUrl || currentUrl === targetUrl) return;
    if (!isTargetBlacklisted && (getTemporaryAllowState(rules.tempAllowMap, currentUrl, now).active || getTemporaryAllowState(rules.tempAllowMap, targetUrl, now).active)) {
      return;
    }
    if (!isTargetBlacklisted && entry.firstPageGraceUntil && now < entry.firstPageGraceUntil) return;
    if (now < entry.lockedUntil || now - entry.lastRevertTime < TIMINGS.REVERT_COOLDOWN_MS) return;
    safeTry("background.onBeforeNavigate", () => {
      const prevHost = getHostname(currentUrl);
      const targetHost = getHostname(targetUrl);
      const prevBase = getBaseDomain(prevHost);
      const targetBase = getBaseDomain(targetHost);
      const isCurrentSearchOrMessenger = SEARCH_ENGINE_HOST_REGEX.test(prevHost) || MESSENGER_OR_SOCIAL_ENTRY_REGEX.test(prevHost);
      if (prevBase !== targetBase && !isSameSafeEcosystem(prevHost, targetHost)) {
        if (isCurrentSearchOrMessenger && !isTargetBlacklisted) {
          allowManualTarget(targetUrl, 15e3);
          return;
        }
        const isHardMaliciousTarget = isHardMaliciousUrl(targetUrl, rules.denied);
        if (entry.shortlinkCtaGraceUntil && now < entry.shortlinkCtaGraceUntil && !isHardMaliciousTarget) {
          allowManualTarget(targetUrl, 18e3);
          return;
        }
        if (SAFE_MEDIA_HOST_REGEX.test(targetHost) && !isHardMaliciousTarget) return;
        if (isTargetBlacklisted || isSuspiciousUrl(targetUrl, rules, currentUrl, isTargetRecentlyAllowed)) {
          const safeUrl = getSafeReturnUrl(details.tabId, targetUrl, rules) || currentUrl;
          appendAegisLog({
            level: "BLOCK",
            source: "background",
            code: isTargetBlacklisted ? "BLOCK_BEFORE_NAV_BLACKLIST" : "BLOCK_BEFORE_NAV_SUSPICIOUS",
            fromUrl: currentUrl,
            toUrl: targetUrl,
            detail: `onBeforeNavigate ditahan -> kembali ke ${safeUrl} | blacklisted=${isTargetBlacklisted} | hardMalicious=${isHardMaliciousTarget}`
          });
          forceRevertTab(
            details.tabId,
            safeUrl,
            targetUrl,
            "Redirect iklan/affiliate ditahan",
            isTargetBlacklisted,
            rules.denied
          );
        }
      }
    });
  });
  chrome.tabs.onRemoved.addListener((tabId) => {
    tabHistory.delete(tabId);
  });
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request || typeof request.type !== "string") return;
    if (request.type === "AUTH_FLOW_STARTED" && sender.tab && sender.tab.id) {
      const entry = ensureTabEntry(sender.tab.id);
      entry.authGraceUntil = Date.now() + TIMINGS.AUTH_GRACE_MS;
      entry.lockedUntil = Date.now() + 1e4;
      tabHistory.set(sender.tab.id, entry);
      return;
    }
    if (request.type === "ALLOW_USER_CONTENT_NAVIGATION" && request.url) {
      allowManualTarget(request.url, 25e3);
      if (sender.tab && sender.tab.id) {
        const entry = ensureTabEntry(sender.tab.id);
        entry.manualAllowedUrl = request.url;
        entry.manualAllowedUntil = Date.now() + 2e4;
        tabHistory.set(sender.tab.id, entry);
      }
      return;
    }
    if (request.type === "USER_CLICKED_SHORTLINK_CTA" && sender.tab && sender.tab.id) {
      const entry = ensureTabEntry(sender.tab.id);
      entry.shortlinkCtaGraceUntil = Date.now() + TIMINGS.SHORTLINK_CTA_GRACE_MS;
      entry.shortlinkCtaSourceHost = getHostname(request.sourceUrl || sender.tab.url || "");
      tabHistory.set(sender.tab.id, entry);
      appendAegisLog({
        level: "ALLOW",
        source: "background",
        code: "GRANT_SHORTLINK_CTA_GRACE",
        fromUrl: request.sourceUrl || sender.tab.url || "",
        toUrl: request.href || "",
        detail: "Grace window 9d diaktifkan untuk tombol CTA shortlink (izinkan HTTP 302 tujuan bersih)"
      });
      return;
    }
    if (request.type === "ALLOW_SHORTLINK_BYPASS_NAV" && request.url) {
      getDomainRules().then((rules) => {
        if (isHardMaliciousUrl(request.url, rules.denied)) {
          appendAegisLog({
            level: "BLOCK",
            source: "background",
            code: "REJECT_UNSAFE_BYPASS_NAV",
            fromUrl: request.sourceUrl || sender.tab && sender.tab.url || "",
            toUrl: request.url,
            detail: "Permintaan ALLOW_SHORTLINK_BYPASS_NAV ditolak karena target terdeteksi Blacklist/berbahaya"
          });
          sendResponse({ ok: false, reason: "unsafe_target" });
          return;
        }
        allowManualTarget(request.url, 25e3);
        if (sender.tab && sender.tab.id) {
          const entry = ensureTabEntry(sender.tab.id);
          entry.manualAllowedUrl = request.url;
          entry.manualAllowedUntil = Date.now() + 25e3;
          entry.shortlinkCtaGraceUntil = Date.now() + TIMINGS.SHORTLINK_CTA_GRACE_MS;
          tabHistory.set(sender.tab.id, entry);
        }
        appendAegisLog({
          level: "BYPASS",
          source: "background",
          code: "ALLOW_SHORTLINK_BYPASS",
          fromUrl: request.sourceUrl || sender.tab && sender.tab.url || "",
          toUrl: request.url,
          detail: `Bypass Shortlink Debloated diizinkan (${request.method || "DIRECT"})`
        });
        sendResponse({ ok: true });
      });
      return true;
    }
    if (request.type === "SET_TEMP_ALLOW" && request.domain) {
      const clean = normalizeDomainEntry(request.domain);
      const minutes = Math.max(1, Math.min(240, Number(request.minutes) || 15));
      ensureTempAllowLoaded().then(async (map) => {
        if (!clean) {
          sendResponse({ ok: false });
          return;
        }
        const expiresAt = Date.now() + minutes * 60 * 1e3;
        const nextMap = { ...map, [clean]: expiresAt };
        await saveTempAllowMap(nextMap);
        appendAegisLog({
          level: "ALLOW",
          source: "background",
          code: "TEMP_ALLOW_ENABLED",
          fromUrl: `https://${clean}`,
          detail: `Safe Mode / Temporary Allow diaktifkan untuk ${clean} selama ${minutes} menit`
        });
        sendResponse({ ok: true, domain: clean, expiresAt, tempAllowMap: nextMap });
      });
      return true;
    }
    if (request.type === "CLEAR_TEMP_ALLOW") {
      ensureTempAllowLoaded().then(async (map) => {
        const nextMap = { ...map };
        if (request.domain) {
          const clean = normalizeDomainEntry(request.domain);
          const base = getBaseDomain(clean);
          delete nextMap[clean];
          delete nextMap[base];
        } else {
          Object.keys(nextMap).forEach((k) => delete nextMap[k]);
        }
        await saveTempAllowMap(nextMap);
        sendResponse({ ok: true, tempAllowMap: nextMap });
      });
      return true;
    }
    if (request.type === "GET_TEMP_ALLOW_STATUS") {
      ensureTempAllowLoaded().then((map) => {
        const state = request.url ? getTemporaryAllowState(map, request.url) : { active: false, domain: "", remainingMs: 0 };
        sendResponse({ tempAllowMap: map, state });
      });
      return true;
    }
    if (request.type === "GET_AEGIS_STATS") {
      ensureStatsLoaded().then((stats) => sendResponse({ stats }));
      return true;
    }
    if (request.type === "RESET_AEGIS_STATS") {
      aegisStatsCache = { ...DEFAULT_STATS };
      aegisStatsLoaded = true;
      chrome.storage.local.set({ aegisStats: { ...DEFAULT_STATS } }, () => sendResponse({ ok: true, stats: aegisStatsCache }));
      return true;
    }
    if (request.type === "APPEND_AEGIS_LOG" && request.entry) {
      appendAegisLog({
        level: request.entry.level,
        source: request.entry.source || "content",
        code: request.entry.code,
        fromUrl: request.entry.fromUrl || sender.tab && sender.tab.url || "",
        toUrl: request.entry.toUrl || "",
        detail: request.entry.detail || ""
      });
      return;
    }
    if (request.type === "GET_AEGIS_LOGS") {
      ensureLogsLoaded().then((logs) => sendResponse({ logs }));
      return true;
    }
    if (request.type === "CLEAR_AEGIS_LOGS") {
      aegisLogsCache = [];
      aegisLogsLoaded = true;
      chrome.storage.local.set({ aegisLogs: [] }, () => sendResponse({ ok: true }));
      return true;
    }
    if (request.type === "CHECK_SHOULD_BLOCK_ENTRY" && sender.tab && sender.tab.id) {
      const tabId = sender.tab.id;
      const url = request.url || sender.tab.url || "";
      getDomainRules().then((rules) => {
        const entry = tabHistory.get(tabId);
        const isBlacklisted = isDomainInList(url, rules.denied);
        if (!isBlacklisted) {
          if (getTemporaryAllowState(rules.tempAllowMap, url).active || isManuallyAllowed(entry, url) || !entry || entry.stack.length <= 1 || entry.firstPageGraceUntil && Date.now() < entry.firstPageGraceUntil) {
            sendResponse({ shouldRevert: false, isBlacklisted: false });
            return;
          }
        }
        const safeUrl = getSafeReturnUrl(tabId, url, rules);
        if (!safeUrl) {
          sendResponse({ shouldRevert: false, isBlacklisted });
          return;
        }
        sendResponse({
          shouldRevert: true,
          isBlacklisted,
          reason: isBlacklisted ? "Domain Blacklist diblokir senyap" : "Redirect iklan/affiliate ditahan"
        });
      });
      return true;
    }
    if (request.type === "GET_PENDING_PROMPTS" && sender.tab && sender.tab.id) {
      getDomainRules().then((rules) => {
        const entry = tabHistory.get(sender.tab.id);
        const rawItems = entry && Array.isArray(entry.pendingPrompts) ? [...entry.pendingPrompts] : [];
        const filteredItems = rawItems.filter(
          (item) => item && item.blockedUrl && !isDomainInList(item.blockedUrl, rules.denied) && !isDomainInList(item.blockedUrl, rules.trusted)
        );
        if (entry) {
          entry.pendingPrompts = [];
          tabHistory.set(sender.tab.id, entry);
        }
        sendResponse({ prompts: filteredItems });
      });
      return true;
    }
    if (request.type === "FORCE_GO_BACK" && sender.tab && sender.tab.id) {
      getDomainRules().then((rules) => {
        const entry = tabHistory.get(sender.tab.id);
        const currentTabUrl = sender.tab.url || "";
        const isBlacklisted = isDomainInList(currentTabUrl, rules.denied);
        if (!isBlacklisted && (isManuallyAllowed(entry, currentTabUrl) || getTemporaryAllowState(rules.tempAllowMap, currentTabUrl).active)) {
          return;
        }
        const safeUrl = getSafeReturnUrl(sender.tab.id, currentTabUrl, rules);
        if (safeUrl) {
          forceRevertTab(
            sender.tab.id,
            safeUrl,
            currentTabUrl,
            request.reason || "Redirect ditahan",
            isBlacklisted,
            rules.denied
          );
        }
      });
      return;
    }
    if (request.type === "OPEN_GROUP_TAB" && request.url && sender.tab) {
      allowManualTarget(request.url, 3e4);
      const createOpts = {
        url: request.url,
        active: false,
        openerTabId: sender.tab.id
      };
      if (typeof sender.tab.index === "number") createOpts.index = sender.tab.index + 1;
      if (typeof sender.tab.windowId === "number") createOpts.windowId = sender.tab.windowId;
      chrome.tabs.create(createOpts, async (newTab) => {
        if (newTab && typeof newTab.id === "number") {
          const newEntry = ensureTabEntry(newTab.id);
          newEntry.manualAllowedUrl = request.url;
          newEntry.manualAllowedUntil = Date.now() + 3e4;
          newEntry.lockedUntil = Date.now() + 15e3;
          newEntry.stack = [request.url];
          tabHistory.set(newTab.id, newEntry);
        }
        if (!newTab || typeof newTab.id !== "number" || !chrome.tabs.group) return;
        try {
          const latestSender = await chrome.tabs.get(sender.tab.id).catch(() => sender.tab);
          const noneId = chrome.tabGroups && typeof chrome.tabGroups.TAB_GROUP_ID_NONE === "number" ? chrome.tabGroups.TAB_GROUP_ID_NONE : -1;
          const existingGroupId = typeof latestSender.groupId === "number" ? latestSender.groupId : noneId;
          if (existingGroupId !== noneId && existingGroupId >= 0) {
            await chrome.tabs.group({ tabIds: [newTab.id], groupId: existingGroupId });
          } else {
            const groupOpts = { tabIds: [sender.tab.id, newTab.id] };
            if (typeof latestSender.windowId === "number") {
              groupOpts.createProperties = { windowId: latestSender.windowId };
            }
            await chrome.tabs.group(groupOpts);
          }
        } catch (err) {
          logInternalError("background.openGroupTab", err);
        }
      });
      return;
    }
    if (request.type === "OPEN_FOREGROUND_TAB" && request.url) {
      allowManualTarget(request.url, 3e4);
      chrome.tabs.create({ url: request.url, active: true }, (newTab) => {
        if (newTab && typeof newTab.id === "number") {
          const newEntry = ensureTabEntry(newTab.id);
          newEntry.manualAllowedUrl = request.url;
          newEntry.manualAllowedUntil = Date.now() + 3e4;
          newEntry.lockedUntil = Date.now() + 15e3;
          newEntry.stack = [request.url];
          tabHistory.set(newTab.id, newEntry);
        }
      });
      return;
    }
    if (request.type === "NAVIGATE_CURRENT_TAB" && request.url && sender.tab && sender.tab.id) {
      allowManualTarget(request.url, 3e4);
      const entry = ensureTabEntry(sender.tab.id);
      entry.manualAllowedUrl = request.url;
      entry.manualAllowedUntil = Date.now() + 25e3;
      entry.lockedUntil = Date.now() + 12e3;
      entry.lastRevertTime = Date.now();
      chrome.tabs.update(sender.tab.id, { url: request.url });
      return;
    }
    if (request.type === "ANALYZE_CANDIDATES") {
      analyzeWithGemini(request.payload).then((result) => sendResponse({ success: true, data: result })).catch((err) => {
        logInternalError("background.analyzeWithGemini", err);
        sendResponse({ success: false, error: err.message });
      });
      return true;
    }
  });
  async function resolveGeminiApiKey() {
    if (chrome.storage.session) {
      try {
        const sess = await chrome.storage.session.get(["geminiApiKey"]);
        if (sess && typeof sess.geminiApiKey === "string" && sess.geminiApiKey.trim()) {
          return sess.geminiApiKey.trim();
        }
      } catch (err) {
        logInternalError("background.readSessionApiKey", err);
      }
    }
    const local = await chrome.storage.local.get(["geminiApiKey"]);
    return typeof local.geminiApiKey === "string" ? local.geminiApiKey.trim() : "";
  }
  async function analyzeWithGemini(payload) {
    const geminiApiKey = await resolveGeminiApiKey();
    if (!geminiApiKey) {
      return { realIndex: -1, blockedIndices: [], reason: "API Key kosong" };
    }
    const prompt = `Analisis kandidat tombol/link ringkas berikut untuk membedakan TOMBOL TUJUAN ASLI (download/lanjut shortlink) vs JEBAKAN IKLAN/JUDOL/AFFILIATE.
Judul: ${String(payload.title || "").slice(0, 80)}
URL: ${String(payload.pageUrl || "").slice(0, 140)}
Kandidat (i=index, t=text, h=href, c=class/id):
${JSON.stringify(payload.candidates || [])}
Balas HANYA JSON valid: {"realIndex": number, "blockedIndices": number[]}`;
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": geminiApiKey
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json"
          }
        })
      }
    );
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
    return parseGeminiAuditResponse(rawText);
  }
  async function syncBlacklistToDnr(deniedList = []) {
    if (!chrome.declarativeNetRequest || !chrome.declarativeNetRequest.updateDynamicRules) return;
    try {
      const { globalSettings } = await chrome.storage.local.get(["globalSettings"]);
      const dnrActive = !globalSettings || globalSettings.dnrEnabled !== false;
      const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
      const removeRuleIds = existingRules.map((r) => r.id);
      const maxDynamicRules = Number(chrome.declarativeNetRequest.MAX_NUMBER_OF_DYNAMIC_RULES) || TIMINGS.DNR_FALLBACK_MAX_RULES;
      if (!dnrActive) {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] });
        await chrome.storage.local.set({
          dnrStats: { totalDomains: 0, ruleCount: 0, truncatedCount: 0, maxRules: maxDynamicRules }
        });
        return;
      }
      const built = buildConsolidatedDnrRules(deniedList, maxDynamicRules, TIMINGS.DNR_BATCH_SIZE);
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds,
        addRules: built.rules
      });
      await chrome.storage.local.set({
        dnrStats: {
          totalDomains: built.totalDomains,
          ruleCount: built.ruleCount,
          truncatedCount: built.truncatedCount,
          maxRules: built.maxRules
        }
      });
    } catch (err) {
      logInternalError("background.syncBlacklistToDnr", err);
    }
  }
  var dnrSyncDebounceTimer = null;
  function scheduleSyncBlacklistToDnr(delayMs = TIMINGS.DNR_DEBOUNCE_MS) {
    clearTimeout(dnrSyncDebounceTimer);
    dnrSyncDebounceTimer = setTimeout(async () => {
      try {
        const { deniedDomains } = await chrome.storage.local.get(["deniedDomains"]);
        await syncBlacklistToDnr(deniedDomains || []);
      } catch (err) {
        logInternalError("background.scheduleDnr", err);
      }
    }, delayMs);
  }
  chrome.runtime.onInstalled.addListener(async () => {
    const existing = await chrome.storage.local.get([
      "deniedDomains",
      "trustedDomains",
      "strictCrossOrigin",
      "autoSkipCountdown",
      "globalSettings",
      "hudPositions",
      "aegisStats"
    ]);
    const defaultsToSet = {};
    if (typeof existing.strictCrossOrigin !== "boolean") defaultsToSet.strictCrossOrigin = false;
    if (typeof existing.autoSkipCountdown !== "boolean") defaultsToSet.autoSkipCountdown = true;
    if (!Array.isArray(existing.trustedDomains)) {
      defaultsToSet.trustedDomains = [...DEFAULT_TRUSTED_DOMAINS];
    }
    if (!Array.isArray(existing.deniedDomains)) defaultsToSet.deniedDomains = [];
    if (!existing.globalSettings || typeof existing.globalSettings !== "object") {
      defaultsToSet.globalSettings = { ...DEFAULT_GLOBAL_SETTINGS };
    } else {
      defaultsToSet.globalSettings = {
        ...DEFAULT_GLOBAL_SETTINGS,
        ...existing.globalSettings
      };
    }
    if (!existing.hudPositions || typeof existing.hudPositions !== "object") {
      defaultsToSet.hudPositions = { ...DEFAULT_HUD_POSITIONS };
    }
    if (!existing.aegisStats || typeof existing.aegisStats !== "object") {
      defaultsToSet.aegisStats = { ...DEFAULT_STATS };
    }
    if (Object.keys(defaultsToSet).length > 0) {
      await chrome.storage.local.set(defaultsToSet);
    }
    await syncBlacklistToDnr(existing.deniedDomains || []);
    await cleanupStaleTabHistory(true);
  });
  chrome.runtime.onStartup.addListener(async () => {
    const { deniedDomains } = await chrome.storage.local.get(["deniedDomains"]);
    await syncBlacklistToDnr(deniedDomains || []);
    await cleanupStaleTabHistory(true);
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.globalSettings && changes.globalSettings.newValue) {
      aegisLoggingEnabled = changes.globalSettings.newValue.loggingEnabled !== false;
      setDebugEnabled(Boolean(changes.globalSettings.newValue.debugInternalErrors));
    }
    if (areaName === "local" && (changes.deniedDomains || changes.globalSettings)) {
      scheduleSyncBlacklistToDnr(TIMINGS.DNR_DEBOUNCE_MS);
    }
    if ((areaName === "session" || areaName === "local") && changes.tempAllowMap) {
      tempAllowCache = pruneExpiredTempAllows(changes.tempAllowMap.newValue || {});
      tempAllowLoaded = true;
    }
  });
})();
