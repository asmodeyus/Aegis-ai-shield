// AEGIS-AI Shield v3.0.0 — Bundled Modular Popup Controller (esbuild)
(() => {
  // src/ext/shared/constants.js
  var AEGIS_VERSION = "3.0.0";
  var DEFAULT_TRUSTED_DOMAINS = [
    "semprot.com",
    "kaskus.co.id",
    "reddit.com"
  ];
  var TIMINGS = Object.freeze({
    DNR_DEBOUNCE_MS: 350,
    DNR_BATCH_SIZE: 150,
    DNR_FALLBACK_MAX_RULES: 5e3,
    TAB_HISTORY_TTL_MS: 2 * 60 * 60 * 1e3,
    TAB_HISTORY_CLEANUP_INTERVAL_MS: 15 * 60 * 1e3,
    LOG_FLUSH_DEBOUNCE_MS: 220,
    MAX_LOGS: 120,
    OBSERVER_DEBOUNCE_MS: 200,
    AUTO_SKIP_INTERVAL_MS: 1e3,
    BYPASS_TOAST_MS: 800,
    BYPASS_TOAST_MAX_WAIT_MS: 1100,
    SHORTLINK_CTA_GRACE_MS: 9e3,
    AUTH_GRACE_MS: 3e4,
    FIRST_PAGE_GRACE_MS: 6e3,
    REVERT_COOLDOWN_MS: 2200,
    LOOP_LOCK_MS: 15e3,
    USER_GESTURE_WINDOW_MS: 1800,
    AUTH_GESTURE_WINDOW_MS: 6e3,
    HISTORY_FLOOD_WINDOW_MS: 1500,
    HISTORY_FLOOD_MAX_CALLS: 6
  });
  var BRIDGE_EVENTS = Object.freeze({
    HANDSHAKE_INIT: "__AEGIS_HANDSHAKE_INIT__",
    REQUEST_RULES: "__AEGIS_REQUEST_RULES__",
    SYNC_RULES: "__AEGIS_SYNC_RULES__",
    CAPTCHA_SIGNAL: "__AEGIS_CAPTCHA_SIGNAL__",
    SHORTLINK_CTA_CLICK: "__AEGIS_SHORTLINK_CTA_CLICK__",
    AUTH_GESTURE: "__AEGIS_AUTH_GESTURE__",
    BLOCKED_EVENT: "__AEGIS_BLOCKED_EVENT__",
    VIDEO_DETECTED: "__AEGIS_VIDEO_DETECTED__",
    AUTO_SKIPPED: "__AEGIS_AUTO_SKIPPED__",
    LOG_EVENT: "__AEGIS_LOG_EVENT__"
  });
  var DEFAULT_GLOBAL_SETTINGS = Object.freeze({
    protectionMode: "balanced",
    // "balanced" | "strict"
    popupTheme: "dark",
    // "dark" | "light"
    sessionOnlyApiKey: false,
    debugInternalErrors: false,
    hudEnabled: true,
    hudDurationSec: 4.5,
    hudPosition: "top-center",
    hudOpacity: 0.95,
    hudScale: 1,
    hudShowTrust: true,
    hudShowGroup: true,
    hudShowOpen: true,
    hudShowBlock: true,
    hudShowUrlDetail: true,
    videoDockEnabled: true,
    videoDockDimSec: 2.5,
    videoDockExpandDir: "auto",
    videoPillScale: 1,
    videoPillOpacity: 0.95,
    videoPillShowPlayPause: true,
    videoPillShowList: true,
    videoPillShowDownload: true,
    videoPillShowPip: true,
    videoPillShowFullscreen: true,
    pipSize: "medium",
    pipOpacity: 0.95,
    adSkipSpeed: "16",
    smartUgcSense: true,
    shortlinkBypassEnabled: true,
    shortlinkAutoClick: true,
    loggingEnabled: true,
    removeTransparentOverlay: true,
    antiHistoryTrap: true,
    dnrEnabled: true,
    redirectWindowSec: 3.5
  });
  var DEFAULT_HUD_POSITIONS = Object.freeze({
    topHud: null,
    videoDock: null,
    miniPip: null
  });
  var DEFAULT_STATS = Object.freeze({
    blocked: 0,
    bypassed: 0,
    allowed: 0
  });

  // src/ext/shared/debug.js
  var SENSITIVE_QUERY_KEYS = /^(token|t|key|api_?key|auth|sig|signature|session|sid|code|access_token|id_token|refresh_token|email|pass|password|pwd|secret|hash|cookie|jwt)$/i;
  function sanitizeUrlForReport(rawUrl) {
    if (!rawUrl || typeof rawUrl !== "string") return "-";
    const redactedKeys = rawUrl.replace(/AIza[0-9A-Za-z\-_]{20,}/g, "[REDACTED_API_KEY]");
    try {
      const u = new URL(redactedKeys);
      const nextParams = new URLSearchParams();
      for (const [k, v] of u.searchParams.entries()) {
        if (SENSITIVE_QUERY_KEYS.test(k) || v.length > 48) {
          nextParams.set(k, "[REDACTED]");
        } else {
          nextParams.set(k, v);
        }
      }
      const qs = nextParams.toString();
      return `${u.origin}${u.pathname}${qs ? "?" + qs : ""}`;
    } catch {
      return redactedKeys.slice(0, 180);
    }
  }
  function buildSanitizedFalsePositiveReport({
    version = "3.0.0",
    activeUrl = "",
    protectionMode = "balanced",
    tempAllowActive = false,
    logs = [],
    stats = {}
  }) {
    const recent = (Array.isArray(logs) ? logs : []).slice(0, 20);
    const lines = [
      `=== AEGIS-AI SHIELD v${version} FALSE POSITIVE REPORT (SANITIZED) ===`,
      `Mode Proteksi : ${protectionMode} | Temporary Allow: ${tempAllowActive ? "AKTIF" : "NONAKTIF"}`,
      `Halaman Aktif : ${sanitizeUrlForReport(activeUrl)}`,
      `Statistik Sesi: Blokir=${stats.blocked || 0}, Bypass=${stats.bypassed || 0}, Lolos=${stats.allowed || 0}`,
      "Privasi       : Query sensitif, token & API key otomatis disensor. Laporan ini tidak dikirim otomatis.",
      "------------------------------------------------------------------"
    ];
    if (recent.length === 0) {
      lines.push("(Tidak ada entri log terbaru.)");
      return lines.join("\n");
    }
    for (const entry of recent) {
      const dt = new Date(entry.ts || Date.now());
      const pad = (n) => String(n).padStart(2, "0");
      const tsStr = `${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`;
      const safeFrom = sanitizeUrlForReport(entry.fromUrl || "");
      const safeTo = entry.toUrl ? ` -> ${sanitizeUrlForReport(entry.toUrl)}` : "";
      const safeDetail = String(entry.detail || "-").replace(/AIza[0-9A-Za-z\-_]{20,}/g, "[REDACTED_API_KEY]").slice(0, 220);
      lines.push(
        `[${tsStr}] [${entry.level || "WARN"}/${entry.source || "background"}] ${entry.code || "EVENT"}
  URL    : ${safeFrom}${safeTo}
  Detail : ${safeDetail}`
      );
    }
    return lines.join("\n\n");
  }

  // src/ext/shared/domain-utils.js
  var SECOND_LEVEL_PUBLIC_SUFFIXES = /* @__PURE__ */ new Set([
    "co",
    "com",
    "net",
    "org",
    "ac",
    "go",
    "or",
    "web",
    "sch"
  ]);
  var VALID_DOMAIN_REGEX = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i;
  function getHostname(urlStr, baseHref) {
    if (!urlStr) return "";
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      return (u.hostname || "").toLowerCase();
    } catch {
      return "";
    }
  }
  function getBaseDomain(hostname) {
    const clean = String(hostname || "").trim().toLowerCase().replace(/^www\./, "");
    const parts = clean.split(".").filter(Boolean);
    if (parts.length <= 2) return clean;
    const sld = parts[parts.length - 2];
    if (SECOND_LEVEL_PUBLIC_SUFFIXES.has(sld) && parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  function normalizeDomainEntry(raw) {
    if (!raw) return "";
    let val = String(raw).trim().toLowerCase();
    if (!val) return "";
    try {
      if (val.includes("://")) {
        val = new URL(val).hostname.toLowerCase();
      } else {
        val = val.replace(/^\|\|/, "").replace(/\^.*$/, "").replace(/^\*\./, "").split("/")[0].split("?")[0].split("#")[0].split(":")[0];
      }
    } catch {
      val = val.split("/")[0].split("?")[0].split("#")[0];
    }
    val = val.replace(/^www\./, "").trim();
    if (!val || !VALID_DOMAIN_REGEX.test(val)) return "";
    return val;
  }
  function parseHostlistText(rawText) {
    if (!rawText || typeof rawText !== "string") return [];
    const results = /* @__PURE__ */ new Set();
    const lines = rawText.split(/\r?\n/);
    for (const rawLine of lines) {
      const noComment = rawLine.replace(/[#!;].*$/, "").trim();
      if (!noComment) continue;
      const tokens = noComment.split(/\s+/).filter(Boolean);
      const candidate = tokens.length >= 2 && /^(0\.0\.0\.0|127\.0\.0\.1|::1?)$/.test(tokens[0]) ? tokens[1] : tokens[0];
      const clean = normalizeDomainEntry(candidate);
      if (clean && clean !== "localhost") {
        results.add(clean);
      }
    }
    return Array.from(results);
  }
  function exportHostlistText(domains, title = "AEGIS-AI Shield v3.0.0 Hostlist") {
    const unique = Array.from(
      new Set((Array.isArray(domains) ? domains : []).map(normalizeDomainEntry).filter(Boolean))
    ).sort();
    return [
      `# ${title}`,
      `# Total: ${unique.length} domain | Format: 1 domain per baris`,
      "",
      ...unique
    ].join("\n");
  }
  function getTemporaryAllowState(tempAllowMap, urlStr, now = Date.now()) {
    if (!tempAllowMap || typeof tempAllowMap !== "object" || !urlStr) {
      return { active: false, domain: "", remainingMs: 0 };
    }
    const host = getHostname(urlStr).replace(/^www\./, "");
    if (!host) return { active: false, domain: "", remainingMs: 0 };
    const base = getBaseDomain(host);
    const candidates = [host, base];
    for (const key of candidates) {
      const exp = Number(tempAllowMap[key]);
      if (Number.isFinite(exp) && exp > now) {
        return { active: true, domain: key, remainingMs: exp - now };
      }
    }
    return { active: false, domain: "", remainingMs: 0 };
  }

  // src/ext/shared/dnr-builder.js
  var DNR_BLOCKED_RESOURCE_TYPES = [
    "main_frame",
    "sub_frame",
    "script",
    "xmlhttprequest",
    "ping",
    "other"
  ];
  function buildConsolidatedDnrRules(deniedDomains, maxDynamicRules = TIMINGS.DNR_FALLBACK_MAX_RULES, batchSize = TIMINGS.DNR_BATCH_SIZE) {
    const safeMaxRules = Math.max(1, Math.min(3e4, Number(maxDynamicRules) || TIMINGS.DNR_FALLBACK_MAX_RULES));
    const safeBatchSize = Math.max(1, Math.min(500, Number(batchSize) || TIMINGS.DNR_BATCH_SIZE));
    const uniqueHosts = Array.from(
      new Set((Array.isArray(deniedDomains) ? deniedDomains : []).map(normalizeDomainEntry).filter(Boolean))
    );
    const maxSupportedDomains = safeMaxRules * safeBatchSize;
    const effectiveHosts = uniqueHosts.slice(0, maxSupportedDomains);
    const truncatedCount = Math.max(0, uniqueHosts.length - effectiveHosts.length);
    const rules = [];
    for (let i = 0; i < effectiveHosts.length; i += safeBatchSize) {
      const chunk = effectiveHosts.slice(i, i + safeBatchSize);
      rules.push({
        id: rules.length + 1,
        priority: 1,
        action: { type: "block" },
        condition: {
          requestDomains: chunk,
          resourceTypes: DNR_BLOCKED_RESOURCE_TYPES
        }
      });
    }
    return {
      rules,
      totalDomains: effectiveHosts.length,
      ruleCount: rules.length,
      truncatedCount,
      maxRules: safeMaxRules
    };
  }

  // src/ext/popup/index.js
  var statusEl = (
    /** @type {HTMLElement} */
    document.getElementById("status")
  );
  var apiKeyEl = (
    /** @type {HTMLInputElement} */
    document.getElementById("apiKey")
  );
  var sessionOnlyKeyEl = (
    /** @type {HTMLInputElement} */
    document.getElementById("sessionOnlyKeyToggle")
  );
  var autoSkipEl = (
    /** @type {HTMLInputElement} */
    document.getElementById("autoSkipToggle")
  );
  var themeToggleBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("themeToggleBtn")
  );
  var modeBalancedBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("modeBalancedBtn")
  );
  var modeStrictBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("modeStrictBtn")
  );
  var safeModeBar = (
    /** @type {HTMLElement} */
    document.getElementById("safeModeBar")
  );
  var activeHostLabel = (
    /** @type {HTMLElement} */
    document.getElementById("activeHostLabel")
  );
  var safeModeStatusText = (
    /** @type {HTMLElement} */
    document.getElementById("safeModeStatusText")
  );
  var tempAllow15Btn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("tempAllow15Btn")
  );
  var tempAllow60Btn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("tempAllow60Btn")
  );
  var tempAllowClearBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("tempAllowClearBtn")
  );
  var statBlockedEl = (
    /** @type {HTMLElement} */
    document.getElementById("statBlocked")
  );
  var statBypassedEl = (
    /** @type {HTMLElement} */
    document.getElementById("statBypassed")
  );
  var statAllowedEl = (
    /** @type {HTMLElement} */
    document.getElementById("statAllowed")
  );
  var resetStatsBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("resetStatsBtn")
  );
  var blacklistInput = (
    /** @type {HTMLInputElement} */
    document.getElementById("blacklistInput")
  );
  var whitelistInput = (
    /** @type {HTMLInputElement} */
    document.getElementById("whitelistInput")
  );
  var blacklistContainer = (
    /** @type {HTMLElement} */
    document.getElementById("blacklistContainer")
  );
  var whitelistContainer = (
    /** @type {HTMLElement} */
    document.getElementById("whitelistContainer")
  );
  var dnrStatsVal = (
    /** @type {HTMLElement} */
    document.getElementById("dnrStatsVal")
  );
  var tabLogs = (
    /** @type {HTMLElement} */
    document.getElementById("tabLogs")
  );
  var tabBlacklist = (
    /** @type {HTMLElement} */
    document.getElementById("tabBlacklist")
  );
  var tabWhitelist = (
    /** @type {HTMLElement} */
    document.getElementById("tabWhitelist")
  );
  var logOutputArea = (
    /** @type {HTMLTextAreaElement} */
    document.getElementById("logOutputArea")
  );
  var copyLogBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("copyLogBtn")
  );
  var copyFpReportBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("copyFpReportBtn")
  );
  var refreshLogBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("refreshLogBtn")
  );
  var clearLogBtn = (
    /** @type {HTMLButtonElement} */
    document.getElementById("clearLogBtn")
  );
  var aiCacheCountEl = (
    /** @type {HTMLElement} */
    document.getElementById("aiCacheCount")
  );
  var restoreDrawer = (
    /** @type {HTMLElement} */
    document.getElementById("restoreDrawer")
  );
  var backupJsonArea = (
    /** @type {HTMLTextAreaElement} */
    document.getElementById("backupJsonArea")
  );
  var importBlacklistDrawer = (
    /** @type {HTMLElement} */
    document.getElementById("importBlacklistDrawer")
  );
  var blacklistTxtArea = (
    /** @type {HTMLTextAreaElement} */
    document.getElementById("blacklistTxtArea")
  );
  var importWhitelistDrawer = (
    /** @type {HTMLElement} */
    document.getElementById("importWhitelistDrawer")
  );
  var whitelistTxtArea = (
    /** @type {HTMLTextAreaElement} */
    document.getElementById("whitelistTxtArea")
  );
  var posStatusVideoDock = (
    /** @type {HTMLElement} */
    document.getElementById("posStatusVideoDock")
  );
  var posStatusTopHud = (
    /** @type {HTMLElement} */
    document.getElementById("posStatusTopHud")
  );
  var posStatusMiniPip = (
    /** @type {HTMLElement} */
    document.getElementById("posStatusMiniPip")
  );
  var gInputs = {
    hudEnabled: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudEnabledToggle")
    ),
    hudDurationRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudDurationRange")
    ),
    hudDurationVal: (
      /** @type {HTMLElement} */
      document.getElementById("hudDurationVal")
    ),
    hudPosition: (
      /** @type {HTMLSelectElement} */
      document.getElementById("hudPositionSelect")
    ),
    hudOpacityRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudOpacityRange")
    ),
    hudOpacityVal: (
      /** @type {HTMLElement} */
      document.getElementById("hudOpacityVal")
    ),
    hudScaleRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudScaleRange")
    ),
    hudScaleVal: (
      /** @type {HTMLElement} */
      document.getElementById("hudScaleVal")
    ),
    hudShowTrust: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudShowTrust")
    ),
    hudShowGroup: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudShowGroup")
    ),
    hudShowOpen: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudShowOpen")
    ),
    hudShowBlock: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudShowBlock")
    ),
    hudShowUrlDetail: (
      /** @type {HTMLInputElement} */
      document.getElementById("hudShowUrlDetail")
    ),
    videoDockEnabled: (
      /** @type {HTMLInputElement} */
      document.getElementById("videoDockEnabledToggle")
    ),
    videoDockDimRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("videoDockDimRange")
    ),
    videoDockDimVal: (
      /** @type {HTMLElement} */
      document.getElementById("videoDockDimVal")
    ),
    videoDockDir: (
      /** @type {HTMLSelectElement} */
      document.getElementById("videoDockDirSelect")
    ),
    videoPillScaleRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("videoPillScaleRange")
    ),
    videoPillScaleVal: (
      /** @type {HTMLElement} */
      document.getElementById("videoPillScaleVal")
    ),
    videoPillOpacityRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("videoPillOpacityRange")
    ),
    videoPillOpacityVal: (
      /** @type {HTMLElement} */
      document.getElementById("videoPillOpacityVal")
    ),
    vpShowPlayPause: (
      /** @type {HTMLInputElement} */
      document.getElementById("vpShowPlayPause")
    ),
    vpShowList: (
      /** @type {HTMLInputElement} */
      document.getElementById("vpShowList")
    ),
    vpShowDownload: (
      /** @type {HTMLInputElement} */
      document.getElementById("vpShowDownload")
    ),
    vpShowPip: (
      /** @type {HTMLInputElement} */
      document.getElementById("vpShowPip")
    ),
    vpShowFullscreen: (
      /** @type {HTMLInputElement} */
      document.getElementById("vpShowFullscreen")
    ),
    pipSize: (
      /** @type {HTMLSelectElement} */
      document.getElementById("pipSizeSelect")
    ),
    pipOpacityRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("pipOpacityRange")
    ),
    pipOpacityVal: (
      /** @type {HTMLElement} */
      document.getElementById("pipOpacityVal")
    ),
    adSkipSpeed: (
      /** @type {HTMLSelectElement} */
      document.getElementById("adSkipSpeedSelect")
    ),
    shortlinkBypassEnabled: (
      /** @type {HTMLInputElement} */
      document.getElementById("shortlinkBypassEnabledToggle")
    ),
    shortlinkAutoClick: (
      /** @type {HTMLInputElement} */
      document.getElementById("shortlinkAutoClickToggle")
    ),
    loggingEnabled: (
      /** @type {HTMLInputElement} */
      document.getElementById("loggingEnabledToggle")
    ),
    debugInternalErrors: (
      /** @type {HTMLInputElement} */
      document.getElementById("debugInternalErrorsToggle")
    ),
    smartUgcSense: (
      /** @type {HTMLInputElement} */
      document.getElementById("smartUgcSenseToggle")
    ),
    removeOverlay: (
      /** @type {HTMLInputElement} */
      document.getElementById("removeOverlayToggle")
    ),
    antiHistory: (
      /** @type {HTMLInputElement} */
      document.getElementById("antiHistoryToggle")
    ),
    dnrEnabled: (
      /** @type {HTMLInputElement} */
      document.getElementById("dnrEnabledToggle")
    ),
    redirectWindowRange: (
      /** @type {HTMLInputElement} */
      document.getElementById("redirectWindowRange")
    ),
    redirectWindowVal: (
      /** @type {HTMLElement} */
      document.getElementById("redirectWindowVal")
    )
  };
  var cachedAegisLogs = [];
  var activeLogFilter = "ALL";
  var currentProtectionMode = "balanced";
  var currentTheme = "dark";
  var activeTabUrl = "";
  var activeTabHost = "";
  var cachedStats = { ...DEFAULT_STATS };
  var cachedTempAllowMap = {};
  var statusTimer = null;
  function showStatus(msg, color = "var(--sky)") {
    statusEl.textContent = msg;
    statusEl.style.color = color;
    clearTimeout(statusTimer);
    statusTimer = setTimeout(() => {
      statusEl.textContent = "";
    }, 3e3);
  }
  function applyTheme(theme) {
    currentTheme = theme === "light" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", currentTheme);
    themeToggleBtn.textContent = currentTheme === "light" ? "🌙 Gelap" : "☀️ Terang";
  }
  function applyProtectionModeUI(mode) {
    currentProtectionMode = mode === "strict" ? "strict" : "balanced";
    modeBalancedBtn.classList.toggle("active", currentProtectionMode === "balanced");
    modeStrictBtn.classList.toggle("active", currentProtectionMode === "strict");
  }
  function updateStatsUI(stats) {
    cachedStats = {
      blocked: Number(stats?.blocked) || 0,
      bypassed: Number(stats?.bypassed) || 0,
      allowed: Number(stats?.allowed) || 0
    };
    statBlockedEl.textContent = String(cachedStats.blocked);
    statBypassedEl.textContent = String(cachedStats.bypassed);
    statAllowedEl.textContent = String(cachedStats.allowed);
  }
  function updateSafeModeUI() {
    if (!activeTabHost) {
      activeHostLabel.textContent = "Tab internal browser";
      safeModeStatusText.textContent = "Buka situs http/https untuk kontrol per-situs";
      safeModeBar.classList.remove("active");
      tempAllow15Btn.style.display = "none";
      tempAllow60Btn.style.display = "none";
      tempAllowClearBtn.style.display = "none";
      return;
    }
    activeHostLabel.textContent = activeTabHost;
    const st = getTemporaryAllowState(cachedTempAllowMap, activeTabUrl);
    if (st.active) {
      const mins = Math.max(1, Math.ceil(st.remainingMs / 6e4));
      safeModeBar.classList.add("active");
      safeModeStatusText.textContent = `⏸ Safe Mode aktif (~${mins} menit tersisa · Blacklist tetap blokir)`;
      tempAllow15Btn.style.display = "none";
      tempAllow60Btn.style.display = "none";
      tempAllowClearBtn.style.display = "inline-block";
    } else {
      safeModeBar.classList.remove("active");
      safeModeStatusText.textContent = currentProtectionMode === "strict" ? "🔒 Mode Strict aktif pada situs ini" : "⚖️ Mode Balanced aktif pada situs ini";
      tempAllow15Btn.style.display = "inline-block";
      tempAllow60Btn.style.display = "inline-block";
      tempAllowClearBtn.style.display = "none";
    }
  }
  function updateRangeLabels() {
    const hudDur = Number(gInputs.hudDurationRange.value);
    gInputs.hudDurationVal.textContent = hudDur === 0 ? "Manual (Tetap)" : `${hudDur.toFixed(1)} detik`;
    const hudOp = Number(gInputs.hudOpacityRange.value);
    gInputs.hudOpacityVal.textContent = `${Math.round(hudOp * 100)}% (${hudOp.toFixed(2)})`;
    const hudSc = Number(gInputs.hudScaleRange.value);
    gInputs.hudScaleVal.textContent = `${Math.round(hudSc * 100)}% (${hudSc.toFixed(2)}×)`;
    const dimSec = Number(gInputs.videoDockDimRange.value);
    gInputs.videoDockDimVal.textContent = dimSec === 0 ? "Selalu Terbuka" : `${dimSec.toFixed(1)} detik`;
    const vpSc = Number(gInputs.videoPillScaleRange.value);
    gInputs.videoPillScaleVal.textContent = `${Math.round(vpSc * 100)}% (${vpSc.toFixed(2)}×)`;
    const vpOp = Number(gInputs.videoPillOpacityRange.value);
    gInputs.videoPillOpacityVal.textContent = `${Math.round(vpOp * 100)}% (${vpOp.toFixed(2)})`;
    const pipOp = Number(gInputs.pipOpacityRange.value);
    gInputs.pipOpacityVal.textContent = `${Math.round(pipOp * 100)}% (${pipOp.toFixed(2)})`;
    const rw = Number(gInputs.redirectWindowRange.value);
    gInputs.redirectWindowVal.textContent = `${rw.toFixed(1)} detik`;
  }
  function applyGlobalSettingsToUI(raw) {
    const g = { ...DEFAULT_GLOBAL_SETTINGS, ...raw || {} };
    applyProtectionModeUI(g.protectionMode);
    applyTheme(g.popupTheme);
    sessionOnlyKeyEl.checked = Boolean(g.sessionOnlyApiKey);
    gInputs.hudEnabled.checked = g.hudEnabled !== false;
    gInputs.hudDurationRange.value = String(g.hudDurationSec ?? 4.5);
    gInputs.hudPosition.value = g.hudPosition || "top-center";
    gInputs.hudOpacityRange.value = String(g.hudOpacity ?? 0.95);
    gInputs.hudScaleRange.value = String(g.hudScale ?? 1);
    gInputs.hudShowTrust.checked = g.hudShowTrust !== false;
    gInputs.hudShowGroup.checked = g.hudShowGroup !== false;
    gInputs.hudShowOpen.checked = g.hudShowOpen !== false;
    gInputs.hudShowBlock.checked = g.hudShowBlock !== false;
    gInputs.hudShowUrlDetail.checked = g.hudShowUrlDetail !== false;
    gInputs.videoDockEnabled.checked = g.videoDockEnabled !== false;
    gInputs.videoDockDimRange.value = String(g.videoDockDimSec ?? 2.5);
    gInputs.videoDockDir.value = g.videoDockExpandDir || "auto";
    gInputs.videoPillScaleRange.value = String(g.videoPillScale ?? 1);
    gInputs.videoPillOpacityRange.value = String(g.videoPillOpacity ?? 0.95);
    gInputs.vpShowPlayPause.checked = g.videoPillShowPlayPause !== false;
    gInputs.vpShowList.checked = g.videoPillShowList !== false;
    gInputs.vpShowDownload.checked = g.videoPillShowDownload !== false;
    gInputs.vpShowPip.checked = g.videoPillShowPip !== false;
    gInputs.vpShowFullscreen.checked = g.videoPillShowFullscreen !== false;
    gInputs.pipSize.value = g.pipSize || "medium";
    gInputs.pipOpacityRange.value = String(g.pipOpacity ?? 0.95);
    gInputs.adSkipSpeed.value = String(g.adSkipSpeed || "16");
    gInputs.shortlinkBypassEnabled.checked = g.shortlinkBypassEnabled !== false;
    gInputs.shortlinkAutoClick.checked = g.shortlinkAutoClick !== false;
    gInputs.loggingEnabled.checked = g.loggingEnabled !== false;
    gInputs.debugInternalErrors.checked = Boolean(g.debugInternalErrors);
    gInputs.smartUgcSense.checked = g.smartUgcSense !== false;
    gInputs.removeOverlay.checked = g.removeTransparentOverlay !== false;
    gInputs.antiHistory.checked = g.antiHistoryTrap !== false;
    gInputs.dnrEnabled.checked = g.dnrEnabled !== false;
    gInputs.redirectWindowRange.value = String(g.redirectWindowSec ?? 3.5);
    updateRangeLabels();
    updateSafeModeUI();
  }
  function readGlobalSettingsFromUI() {
    return {
      protectionMode: currentProtectionMode,
      popupTheme: currentTheme,
      sessionOnlyApiKey: sessionOnlyKeyEl.checked,
      debugInternalErrors: gInputs.debugInternalErrors.checked,
      hudEnabled: gInputs.hudEnabled.checked,
      hudDurationSec: Number(gInputs.hudDurationRange.value),
      hudPosition: gInputs.hudPosition.value,
      hudOpacity: Number(gInputs.hudOpacityRange.value),
      hudScale: Number(gInputs.hudScaleRange.value),
      hudShowTrust: gInputs.hudShowTrust.checked,
      hudShowGroup: gInputs.hudShowGroup.checked,
      hudShowOpen: gInputs.hudShowOpen.checked,
      hudShowBlock: gInputs.hudShowBlock.checked,
      hudShowUrlDetail: gInputs.hudShowUrlDetail.checked,
      videoDockEnabled: gInputs.videoDockEnabled.checked,
      videoDockDimSec: Number(gInputs.videoDockDimRange.value),
      videoDockExpandDir: gInputs.videoDockDir.value,
      videoPillScale: Number(gInputs.videoPillScaleRange.value),
      videoPillOpacity: Number(gInputs.videoPillOpacityRange.value),
      videoPillShowPlayPause: gInputs.vpShowPlayPause.checked,
      videoPillShowList: gInputs.vpShowList.checked,
      videoPillShowDownload: gInputs.vpShowDownload.checked,
      videoPillShowPip: gInputs.vpShowPip.checked,
      videoPillShowFullscreen: gInputs.vpShowFullscreen.checked,
      pipSize: gInputs.pipSize.value,
      pipOpacity: Number(gInputs.pipOpacityRange.value),
      adSkipSpeed: gInputs.adSkipSpeed.value,
      shortlinkBypassEnabled: gInputs.shortlinkBypassEnabled.checked,
      shortlinkAutoClick: gInputs.shortlinkAutoClick.checked,
      loggingEnabled: gInputs.loggingEnabled.checked,
      smartUgcSense: gInputs.smartUgcSense.checked,
      removeTransparentOverlay: gInputs.removeOverlay.checked,
      antiHistoryTrap: gInputs.antiHistory.checked,
      dnrEnabled: gInputs.dnrEnabled.checked,
      redirectWindowSec: Number(gInputs.redirectWindowRange.value)
    };
  }
  function formatPosCoord(pos, fallbackLabel) {
    if (!pos || typeof pos !== "object") return fallbackLabel;
    if (typeof pos.xRatio === "number" && typeof pos.yRatio === "number") {
      const xPct = Math.round(pos.xRatio * 100);
      const yPct = Math.round(pos.yRatio * 100);
      const side = pos.anchorX === "right" ? "Kanan" : "Kiri";
      return `${side} (${xPct}%, ${yPct}%)`;
    }
    if (typeof pos.left === "number" && typeof pos.top === "number") {
      return `${Math.round(pos.left)}px, ${Math.round(pos.top)}px`;
    }
    return fallbackLabel;
  }
  function renderHudPositions(posObj) {
    const p = { ...DEFAULT_HUD_POSITIONS, ...posObj || {} };
    posStatusVideoDock.textContent = formatPosCoord(p.videoDock, "Auto-Anchor");
    posStatusTopHud.textContent = formatPosCoord(p.topHud, "Preset Default");
    posStatusMiniPip.textContent = formatPosCoord(p.miniPip, "Kanan Bawah");
  }
  function renderList(container, items, storageKey, emptyText) {
    container.innerHTML = "";
    if (!items || items.length === 0) {
      const empty = document.createElement("div");
      empty.className = "empty-msg";
      empty.textContent = emptyText;
      container.appendChild(empty);
      return;
    }
    items.forEach((domain) => {
      const row = document.createElement("div");
      row.className = "domain-item";
      const span = document.createElement("span");
      span.className = "domain-name";
      span.textContent = domain;
      const del = document.createElement("button");
      del.className = "del-btn";
      del.textContent = "✕";
      del.title = `Hapus ${domain}`;
      del.onclick = () => removeDomain(storageKey, domain);
      row.appendChild(span);
      row.appendChild(del);
      container.appendChild(row);
    });
  }
  function updateDnrStatsDisplay(deniedList, storedDnrStats) {
    if (storedDnrStats && typeof storedDnrStats.ruleCount === "number") {
      const trunc = storedDnrStats.truncatedCount > 0 ? ` · ${storedDnrStats.truncatedCount} terpotong` : "";
      dnrStatsVal.textContent = `${storedDnrStats.totalDomains} domain · ${storedDnrStats.ruleCount}/${storedDnrStats.maxRules} rule${trunc}`;
      return;
    }
    const built = buildConsolidatedDnrRules(deniedList, TIMINGS.DNR_FALLBACK_MAX_RULES, TIMINGS.DNR_BATCH_SIZE);
    dnrStatsVal.textContent = `${built.totalDomains} domain · ${built.ruleCount}/${built.maxRules} rule`;
  }
  function formatLogTimestamp(ts) {
    const d = new Date(ts || Date.now());
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }
  function formatLogsForCopyPaste(logs, filterLevel) {
    const list = Array.isArray(logs) ? logs : [];
    const filtered = filterLevel === "ALL" ? list : list.filter((item) => String(item.level || "").toUpperCase() === filterLevel);
    if (filtered.length === 0) {
      return `=== AEGIS-AI SHIELD v${AEGIS_VERSION} DIAGNOSTIC LOG ===
Filter: ${filterLevel} | Total: 0 entri

(Belum ada entri log. Buka situs shortlink atau link yang bermasalah lalu klik Refresh.)`;
    }
    const header = [
      `=== AEGIS-AI SHIELD v${AEGIS_VERSION} DIAGNOSTIC LOG ===`,
      `Filter: ${filterLevel} | Menampilkan ${filtered.length} dari ${list.length} entri`,
      `Mode: ${currentProtectionMode} | Dibuat: ${(/* @__PURE__ */ new Date()).toLocaleString("id-ID")}`,
      "------------------------------------------------------------"
    ].join("\n");
    const body = filtered.map((item) => {
      const ts = formatLogTimestamp(item.ts);
      const lvl = String(item.level || "WARN").toUpperCase();
      const src = item.source || "background";
      const code = item.code || "EVENT";
      const fromLine = item.fromUrl ? `
  From   : ${item.fromUrl}` : "";
      const toLine = item.toUrl ? `
  To     : ${item.toUrl}` : "";
      const detailLine = item.detail ? `
  Detail : ${item.detail}` : "";
      return `[${ts}] [${lvl}/${src}] ${code}${fromLine}${toLine}${detailLine}`;
    }).join("\n\n");
    return `${header}
${body}`;
  }
  function renderAegisLogs() {
    const count = Array.isArray(cachedAegisLogs) ? cachedAegisLogs.length : 0;
    tabLogs.textContent = `📋 Log (${count})`;
    logOutputArea.value = formatLogsForCopyPaste(cachedAegisLogs, activeLogFilter);
  }
  function loadAegisLogs(silent = true) {
    chrome.runtime.sendMessage({ type: "GET_AEGIS_LOGS" }, (res) => {
      if (chrome.runtime.lastError) {
        chrome.storage.local.get(["aegisLogs"], (data) => {
          cachedAegisLogs = Array.isArray(data.aegisLogs) ? data.aegisLogs : [];
          renderAegisLogs();
        });
        return;
      }
      cachedAegisLogs = res && Array.isArray(res.logs) ? res.logs : [];
      renderAegisLogs();
      if (!silent) showStatus(`🔄 ${cachedAegisLogs.length} entri log dimuat`, "var(--amber)");
    });
  }
  async function loadActiveTabInfo() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      activeTabUrl = tab && tab.url && tab.url.startsWith("http") ? tab.url : "";
      activeTabHost = activeTabUrl ? getHostname(activeTabUrl) : "";
    } catch {
      activeTabUrl = "";
      activeTabHost = "";
    }
    updateSafeModeUI();
  }
  async function loadState() {
    await loadActiveTabInfo();
    const data = await chrome.storage.local.get([
      "geminiApiKey",
      "strictCrossOrigin",
      "autoSkipCountdown",
      "deniedDomains",
      "trustedDomains",
      "globalSettings",
      "hudPositions",
      "aiAuditCache",
      "aegisLogs",
      "aegisStats",
      "dnrStats",
      "tempAllowMap"
    ]);
    let sessionKey = "";
    if (chrome.storage.session) {
      try {
        const sess = await chrome.storage.session.get(["geminiApiKey", "tempAllowMap"]);
        if (sess.geminiApiKey) sessionKey = String(sess.geminiApiKey);
        if (sess.tempAllowMap && typeof sess.tempAllowMap === "object") {
          cachedTempAllowMap = sess.tempAllowMap;
        }
      } catch {
      }
    }
    if (!Object.keys(cachedTempAllowMap).length && data.tempAllowMap) {
      cachedTempAllowMap = data.tempAllowMap;
    }
    const g = { ...DEFAULT_GLOBAL_SETTINGS, ...data.globalSettings || {} };
    if (!data.globalSettings?.protectionMode && data.strictCrossOrigin === true) {
      g.protectionMode = "strict";
    }
    apiKeyEl.value = g.sessionOnlyApiKey ? sessionKey : sessionKey || data.geminiApiKey || "";
    autoSkipEl.checked = data.autoSkipCountdown !== false;
    const denied = Array.isArray(data.deniedDomains) ? data.deniedDomains : [];
    const trusted = Array.isArray(data.trustedDomains) ? data.trustedDomains : [...DEFAULT_TRUSTED_DOMAINS];
    const cacheCount = data.aiAuditCache && typeof data.aiAuditCache === "object" ? Object.keys(data.aiAuditCache).length : 0;
    aiCacheCountEl.textContent = String(cacheCount);
    tabBlacklist.textContent = `🚫 Block (${denied.length})`;
    tabWhitelist.textContent = `✅ Trust (${trusted.length})`;
    updateStatsUI(data.aegisStats || DEFAULT_STATS);
    updateDnrStatsDisplay(denied, data.dnrStats);
    renderList(blacklistContainer, denied, "deniedDomains", "Belum ada domain yang diblokir permanen.");
    renderList(whitelistContainer, trusted, "trustedDomains", "Belum ada domain yang dipercaya.");
    applyGlobalSettingsToUI(g);
    renderHudPositions(data.hudPositions);
    cachedAegisLogs = Array.isArray(data.aegisLogs) ? data.aegisLogs : [];
    renderAegisLogs();
  }
  function addDomain(storageKey, rawValue, oppositeKey) {
    const clean = normalizeDomainEntry(rawValue);
    if (!clean) {
      showStatus("⚠️ Format domain tidak valid!", "#f87171");
      return;
    }
    chrome.storage.local.get([storageKey, oppositeKey], (data) => {
      const list = Array.isArray(data[storageKey]) ? data[storageKey] : [];
      const opp = Array.isArray(data[oppositeKey]) ? data[oppositeKey] : [];
      const nextList = Array.from(/* @__PURE__ */ new Set([clean, ...list]));
      const nextOpp = opp.filter((d) => d !== clean);
      chrome.storage.local.set({ [storageKey]: nextList, [oppositeKey]: nextOpp }, () => {
        showStatus(
          storageKey === "deniedDomains" ? `🚫 ${clean} diblokir via DNR!` : `✅ ${clean} masuk Whitelist!`,
          storageKey === "deniedDomains" ? "#f87171" : "var(--accent)"
        );
        loadState();
      });
    });
  }
  function removeDomain(storageKey, domain) {
    chrome.storage.local.get([storageKey], (data) => {
      const list = Array.isArray(data[storageKey]) ? data[storageKey] : [];
      const next = list.filter((d) => d !== domain);
      chrome.storage.local.set({ [storageKey]: next }, () => {
        showStatus(`🗑️ ${domain} dihapus`, "var(--amber)");
        loadState();
      });
    });
  }
  function importHostlistInto(storageKey, oppositeKey, rawText) {
    const parsed = parseHostlistText(rawText);
    if (parsed.length === 0) {
      showStatus("⚠️ Tidak ada domain valid di teks Hostlist", "#f87171");
      return;
    }
    chrome.storage.local.get([storageKey, oppositeKey], (data) => {
      const existing = Array.isArray(data[storageKey]) ? data[storageKey] : [];
      const opp = Array.isArray(data[oppositeKey]) ? data[oppositeKey] : [];
      const merged = Array.from(/* @__PURE__ */ new Set([...parsed, ...existing]));
      const parsedSet = new Set(parsed);
      const nextOpp = opp.filter((d) => !parsedSet.has(d));
      chrome.storage.local.set({ [storageKey]: merged, [oppositeKey]: nextOpp }, () => {
        showStatus(`✅ ${parsed.length} domain berhasil diimport!`, "var(--accent)");
        loadState();
      });
    });
  }
  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tab = btn.getAttribute("data-tab");
      document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`panel-${tab}`)?.classList.add("active");
      if (tab === "logs") loadAegisLogs(true);
    });
  });
  themeToggleBtn.addEventListener("click", () => {
    const nextTheme = currentTheme === "dark" ? "light" : "dark";
    applyTheme(nextTheme);
    chrome.storage.local.get(["globalSettings"], (data) => {
      const merged = { ...DEFAULT_GLOBAL_SETTINGS, ...data.globalSettings || {}, popupTheme: nextTheme };
      chrome.storage.local.set({ globalSettings: merged });
    });
  });
  [modeBalancedBtn, modeStrictBtn].forEach((btn) => {
    btn.addEventListener("click", () => {
      const mode = btn.getAttribute("data-mode") === "strict" ? "strict" : "balanced";
      applyProtectionModeUI(mode);
      updateSafeModeUI();
    });
  });
  function setTempAllow(minutes) {
    if (!activeTabHost) return;
    chrome.runtime.sendMessage({ type: "SET_TEMP_ALLOW", domain: activeTabHost, minutes }, (res) => {
      if (res && res.ok) {
        cachedTempAllowMap = res.tempAllowMap || cachedTempAllowMap;
        updateSafeModeUI();
        showStatus(`⏸ Safe Mode aktif ${minutes}m untuk ${activeTabHost}`, "var(--amber)");
      }
    });
  }
  tempAllow15Btn.addEventListener("click", () => setTempAllow(15));
  tempAllow60Btn.addEventListener("click", () => setTempAllow(60));
  tempAllowClearBtn.addEventListener("click", () => {
    if (!activeTabHost) return;
    chrome.runtime.sendMessage({ type: "CLEAR_TEMP_ALLOW", domain: activeTabHost }, (res) => {
      if (res && res.ok) {
        cachedTempAllowMap = res.tempAllowMap || {};
        updateSafeModeUI();
        showStatus(`🛡️ Proteksi diaktifkan kembali untuk ${activeTabHost}`, "var(--accent)");
      }
    });
  });
  resetStatsBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "RESET_AEGIS_STATS" }, (res) => {
      updateStatsUI(res?.stats || DEFAULT_STATS);
      showStatus("↺ Statistik lokal direset", "var(--sky)");
    });
  });
  document.getElementById("saveBtn")?.addEventListener("click", async () => {
    const key = apiKeyEl.value.trim();
    const sessionOnly = sessionOnlyKeyEl.checked;
    const globalSettings = readGlobalSettingsFromUI();
    if (sessionOnly && chrome.storage.session) {
      await chrome.storage.session.set({ geminiApiKey: key });
      await chrome.storage.local.set({
        geminiApiKey: "",
        strictCrossOrigin: currentProtectionMode === "strict",
        autoSkipCountdown: autoSkipEl.checked,
        globalSettings
      });
      showStatus("🔒 Konfigurasi & API Key (Sesi Saja) tersimpan!", "var(--accent)");
    } else {
      if (chrome.storage.session) {
        await chrome.storage.session.remove(["geminiApiKey"]).catch(() => {
        });
      }
      await chrome.storage.local.set({
        geminiApiKey: key,
        strictCrossOrigin: currentProtectionMode === "strict",
        autoSkipCountdown: autoSkipEl.checked,
        globalSettings
      });
      showStatus("✅ Konfigurasi v3.0.0 berhasil disimpan!", "var(--accent)");
    }
  });
  [
    gInputs.hudDurationRange,
    gInputs.hudOpacityRange,
    gInputs.hudScaleRange,
    gInputs.videoDockDimRange,
    gInputs.videoPillScaleRange,
    gInputs.videoPillOpacityRange,
    gInputs.pipOpacityRange,
    gInputs.redirectWindowRange
  ].forEach((el) => el.addEventListener("input", updateRangeLabels));
  document.getElementById("saveGlobalBtn")?.addEventListener("click", () => {
    const globalSettings = readGlobalSettingsFromUI();
    chrome.storage.local.set(
      {
        globalSettings,
        strictCrossOrigin: globalSettings.protectionMode === "strict"
      },
      () => {
        showStatus("✅ Semua Setting v3.0.0 tersimpan & diterapkan!", "var(--accent)");
      }
    );
  });
  document.getElementById("resetGlobalBtn")?.addEventListener("click", () => {
    chrome.storage.local.set(
      {
        globalSettings: { ...DEFAULT_GLOBAL_SETTINGS },
        hudPositions: { ...DEFAULT_HUD_POSITIONS },
        strictCrossOrigin: false
      },
      () => {
        applyGlobalSettingsToUI(DEFAULT_GLOBAL_SETTINGS);
        renderHudPositions(DEFAULT_HUD_POSITIONS);
        showStatus("↺ Setting & posisi dikembalikan ke default v3.0.0!", "var(--amber)");
      }
    );
  });
  document.querySelectorAll("[data-reset-hud]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const key = btn.getAttribute("data-reset-hud");
      if (!key) return;
      chrome.storage.local.get(["hudPositions"], (data) => {
        const nextPos = { ...DEFAULT_HUD_POSITIONS, ...data.hudPositions || {}, [key]: null };
        chrome.storage.local.set({ hudPositions: nextPos }, () => {
          renderHudPositions(nextPos);
          showStatus("↺ Posisi HUD direset ke default!", "var(--amber)");
        });
      });
    });
  });
  document.getElementById("resetAllHudPosBtn")?.addEventListener("click", () => {
    chrome.storage.local.set({ hudPositions: { ...DEFAULT_HUD_POSITIONS } }, () => {
      renderHudPositions(DEFAULT_HUD_POSITIONS);
      showStatus("↺ Semua posisi geser HUD berhasil direset!", "var(--amber)");
    });
  });
  document.querySelectorAll(".log-filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      activeLogFilter = btn.getAttribute("data-log-filter") || "ALL";
      document.querySelectorAll(".log-filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      renderAegisLogs();
    });
  });
  copyLogBtn.addEventListener("click", async () => {
    const txt = logOutputArea.value || "";
    try {
      await navigator.clipboard.writeText(txt);
      showStatus("📋 Log diagnostik disalin ke clipboard!", "var(--accent)");
    } catch {
      logOutputArea.select();
      document.execCommand("copy");
      showStatus("📋 Log diagnostik disalin!", "var(--accent)");
    }
  });
  copyFpReportBtn.addEventListener("click", async () => {
    const st = getTemporaryAllowState(cachedTempAllowMap, activeTabUrl);
    const report = buildSanitizedFalsePositiveReport({
      version: AEGIS_VERSION,
      activeUrl: activeTabUrl || "-",
      protectionMode: currentProtectionMode,
      tempAllowActive: st.active,
      logs: cachedAegisLogs,
      stats: cachedStats
    });
    try {
      await navigator.clipboard.writeText(report);
      showStatus("🛡️ Laporan False Positive (tersensor) disalin!", "var(--accent)");
    } catch {
      logOutputArea.value = report;
      logOutputArea.select();
      document.execCommand("copy");
      showStatus("🛡️ Laporan FP tersensor disalin!", "var(--accent)");
    }
  });
  refreshLogBtn.addEventListener("click", () => loadAegisLogs(false));
  clearLogBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "CLEAR_AEGIS_LOGS" }, () => {
      cachedAegisLogs = [];
      renderAegisLogs();
      showStatus("🧹 Log diagnostik dikosongkan!", "var(--amber)");
    });
  });
  document.getElementById("copyBackupBtn")?.addEventListener("click", () => {
    chrome.storage.local.get(
      ["strictCrossOrigin", "autoSkipCountdown", "deniedDomains", "trustedDomains", "globalSettings", "hudPositions"],
      async (data) => {
        const payload = {
          app: "AEGIS-AI Shield",
          version: AEGIS_VERSION,
          exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
          strictCrossOrigin: data.strictCrossOrigin === true,
          autoSkipCountdown: data.autoSkipCountdown !== false,
          deniedDomains: Array.isArray(data.deniedDomains) ? data.deniedDomains : [],
          trustedDomains: Array.isArray(data.trustedDomains) ? data.trustedDomains : [...DEFAULT_TRUSTED_DOMAINS],
          globalSettings: { ...DEFAULT_GLOBAL_SETTINGS, ...data.globalSettings || {} },
          hudPositions: { ...DEFAULT_HUD_POSITIONS, ...data.hudPositions || {} }
        };
        const jsonStr = JSON.stringify(payload, null, 2);
        try {
          await navigator.clipboard.writeText(jsonStr);
          showStatus("📋 JSON Backup v3.0.0 disalin (API Key tidak ikut)!", "var(--accent)");
        } catch {
          restoreDrawer.classList.add("open");
          backupJsonArea.value = jsonStr;
          backupJsonArea.select();
          showStatus("📋 Salin teks JSON di kotak bawah secara manual.", "var(--sky)");
        }
      }
    );
  });
  document.getElementById("toggleRestoreBtn")?.addEventListener("click", () => {
    restoreDrawer.classList.toggle("open");
    if (restoreDrawer.classList.contains("open")) backupJsonArea.focus();
  });
  document.getElementById("closeRestoreBtn")?.addEventListener("click", () => {
    restoreDrawer.classList.remove("open");
  });
  document.getElementById("applyRestoreBtn")?.addEventListener("click", () => {
    try {
      const parsed = JSON.parse(backupJsonArea.value.trim());
      if (!parsed || typeof parsed !== "object") throw new Error("Invalid JSON");
      const denied = Array.isArray(parsed.deniedDomains) ? Array.from(new Set(parsed.deniedDomains.map(normalizeDomainEntry).filter(Boolean))) : [];
      const trusted = Array.isArray(parsed.trustedDomains) ? Array.from(new Set(parsed.trustedDomains.map(normalizeDomainEntry).filter(Boolean))) : [...DEFAULT_TRUSTED_DOMAINS];
      const globalSettings = {
        ...DEFAULT_GLOBAL_SETTINGS,
        ...parsed.globalSettings && typeof parsed.globalSettings === "object" ? parsed.globalSettings : {}
      };
      const hudPositions = {
        ...DEFAULT_HUD_POSITIONS,
        ...parsed.hudPositions && typeof parsed.hudPositions === "object" ? parsed.hudPositions : {}
      };
      chrome.storage.local.set(
        {
          strictCrossOrigin: globalSettings.protectionMode === "strict" || parsed.strictCrossOrigin === true,
          autoSkipCountdown: parsed.autoSkipCountdown !== false,
          deniedDomains: denied,
          trustedDomains: trusted,
          globalSettings,
          hudPositions
        },
        () => {
          restoreDrawer.classList.remove("open");
          backupJsonArea.value = "";
          showStatus(`✅ Restore selesai (${denied.length} block, ${trusted.length} trust)!`, "var(--accent)");
          loadState();
        }
      );
    } catch {
      showStatus("❌ Format JSON cadangan tidak valid!", "#f87171");
    }
  });
  document.getElementById("clearAiCacheBtn")?.addEventListener("click", () => {
    chrome.storage.local.set({ aiAuditCache: {} }, () => {
      aiCacheCountEl.textContent = "0";
      showStatus("🧹 Cache keputusan AI dibersihkan!", "var(--amber)");
    });
  });
  document.getElementById("addBlacklistBtn")?.addEventListener("click", () => {
    addDomain("deniedDomains", blacklistInput.value, "trustedDomains");
    blacklistInput.value = "";
  });
  document.getElementById("addWhitelistBtn")?.addEventListener("click", () => {
    addDomain("trustedDomains", whitelistInput.value, "deniedDomains");
    whitelistInput.value = "";
  });
  document.getElementById("blockCurrentSiteBtn")?.addEventListener("click", () => {
    if (!activeTabUrl) {
      showStatus("⚠️ Tab ini bukan situs web http/https.", "#f87171");
      return;
    }
    addDomain("deniedDomains", activeTabUrl, "trustedDomains");
  });
  document.getElementById("trustCurrentSiteBtn")?.addEventListener("click", () => {
    if (!activeTabUrl) {
      showStatus("⚠️ Tab ini bukan situs web http/https.", "#f87171");
      return;
    }
    addDomain("trustedDomains", activeTabUrl, "deniedDomains");
  });
  document.getElementById("exportBlacklistTxtBtn")?.addEventListener("click", () => {
    chrome.storage.local.get(["deniedDomains"], async (data) => {
      const txt = exportHostlistText(data.deniedDomains || [], "AEGIS-AI Shield v3.0.0 Blacklist");
      try {
        await navigator.clipboard.writeText(txt);
        showStatus("📤 Hostlist Blacklist (.txt) disalin!", "var(--accent)");
      } catch {
        importBlacklistDrawer.classList.add("open");
        blacklistTxtArea.value = txt;
        blacklistTxtArea.select();
        showStatus("📤 Salin daftar Hostlist dari kotak bawah.", "var(--sky)");
      }
    });
  });
  document.getElementById("toggleImportBlacklistBtn")?.addEventListener("click", () => {
    importBlacklistDrawer.classList.toggle("open");
    if (importBlacklistDrawer.classList.contains("open")) blacklistTxtArea.focus();
  });
  document.getElementById("closeImportBlacklistBtn")?.addEventListener("click", () => {
    importBlacklistDrawer.classList.remove("open");
  });
  document.getElementById("applyImportBlacklistBtn")?.addEventListener("click", () => {
    importHostlistInto("deniedDomains", "trustedDomains", blacklistTxtArea.value);
    blacklistTxtArea.value = "";
    importBlacklistDrawer.classList.remove("open");
  });
  document.getElementById("exportWhitelistTxtBtn")?.addEventListener("click", () => {
    chrome.storage.local.get(["trustedDomains"], async (data) => {
      const txt = exportHostlistText(data.trustedDomains || [], "AEGIS-AI Shield v3.0.0 Whitelist");
      try {
        await navigator.clipboard.writeText(txt);
        showStatus("📤 Hostlist Whitelist (.txt) disalin!", "var(--accent)");
      } catch {
        importWhitelistDrawer.classList.add("open");
        whitelistTxtArea.value = txt;
        whitelistTxtArea.select();
        showStatus("📤 Salin daftar Whitelist dari kotak bawah.", "var(--sky)");
      }
    });
  });
  document.getElementById("toggleImportWhitelistBtn")?.addEventListener("click", () => {
    importWhitelistDrawer.classList.toggle("open");
    if (importWhitelistDrawer.classList.contains("open")) whitelistTxtArea.focus();
  });
  document.getElementById("closeImportWhitelistBtn")?.addEventListener("click", () => {
    importWhitelistDrawer.classList.remove("open");
  });
  document.getElementById("applyImportWhitelistBtn")?.addEventListener("click", () => {
    importHostlistInto("trustedDomains", "deniedDomains", whitelistTxtArea.value);
    whitelistTxtArea.value = "";
    importWhitelistDrawer.classList.remove("open");
  });
  chrome.storage.onChanged.addListener((changes) => {
    if (changes.hudPositions && changes.hudPositions.newValue) {
      renderHudPositions(changes.hudPositions.newValue);
    }
    if (changes.aegisLogs && changes.aegisLogs.newValue) {
      cachedAegisLogs = Array.isArray(changes.aegisLogs.newValue) ? changes.aegisLogs.newValue : [];
      renderAegisLogs();
    }
    if (changes.aegisStats && changes.aegisStats.newValue) {
      updateStatsUI(changes.aegisStats.newValue);
    }
    if (changes.dnrStats && changes.dnrStats.newValue) {
      updateDnrStatsDisplay([], changes.dnrStats.newValue);
    }
    if (changes.tempAllowMap && changes.tempAllowMap.newValue) {
      cachedTempAllowMap = changes.tempAllowMap.newValue;
      updateSafeModeUI();
    }
  });
  loadState();
})();
