// AEGIS-AI Shield v3.0.0 — Bundled Modular Content Script (esbuild)
(() => {
  // src/ext/shared/constants.js
  var TIMINGS = Object.freeze({
    DNR_DEBOUNCE_MS: 350,
    DNR_BATCH_SIZE: 150,
    DNR_FALLBACK_MAX_RULES: 5e3,
    TAB_HISTORY_TTL_MS: 2 * 60 * 60 * 1e3,
    TAB_HISTORY_CLEANUP_INTERVAL_MS: 15 * 60 * 1e3,
    LOG_FLUSH_DEBOUNCE_MS: 220,
    MAX_LOGS: 120,
    OBSERVER_DEBOUNCE_MS: 200,
    AUTO_SKIP_INTERVAL_MS: 1e3,
    BYPASS_TOAST_MS: 800,
    BYPASS_TOAST_MAX_WAIT_MS: 1100,
    SHORTLINK_CTA_GRACE_MS: 9e3,
    AUTH_GRACE_MS: 3e4,
    FIRST_PAGE_GRACE_MS: 6e3,
    REVERT_COOLDOWN_MS: 2200,
    LOOP_LOCK_MS: 15e3,
    USER_GESTURE_WINDOW_MS: 1800,
    AUTH_GESTURE_WINDOW_MS: 6e3,
    HISTORY_FLOOD_WINDOW_MS: 1500,
    HISTORY_FLOOD_MAX_CALLS: 6
  });
  var BRIDGE_EVENTS = Object.freeze({
    HANDSHAKE_INIT: "__AEGIS_HANDSHAKE_INIT__",
    REQUEST_RULES: "__AEGIS_REQUEST_RULES__",
    SYNC_RULES: "__AEGIS_SYNC_RULES__",
    CAPTCHA_SIGNAL: "__AEGIS_CAPTCHA_SIGNAL__",
    SHORTLINK_CTA_CLICK: "__AEGIS_SHORTLINK_CTA_CLICK__",
    AUTH_GESTURE: "__AEGIS_AUTH_GESTURE__",
    BLOCKED_EVENT: "__AEGIS_BLOCKED_EVENT__",
    VIDEO_DETECTED: "__AEGIS_VIDEO_DETECTED__",
    AUTO_SKIPPED: "__AEGIS_AUTO_SKIPPED__",
    LOG_EVENT: "__AEGIS_LOG_EVENT__"
  });
  var DEFAULT_GLOBAL_SETTINGS = Object.freeze({
    protectionMode: "balanced",
    // "balanced" | "strict"
    popupTheme: "dark",
    // "dark" | "light"
    sessionOnlyApiKey: false,
    debugInternalErrors: false,
    hudEnabled: true,
    hudDurationSec: 4.5,
    hudPosition: "top-center",
    hudOpacity: 0.95,
    hudScale: 1,
    hudShowTrust: true,
    hudShowGroup: true,
    hudShowOpen: true,
    hudShowBlock: true,
    hudShowUrlDetail: true,
    videoDockEnabled: true,
    videoDockDimSec: 2.5,
    videoDockExpandDir: "auto",
    videoPillScale: 1,
    videoPillOpacity: 0.95,
    videoPillShowPlayPause: true,
    videoPillShowList: true,
    videoPillShowDownload: true,
    videoPillShowPip: true,
    videoPillShowFullscreen: true,
    pipSize: "medium",
    pipOpacity: 0.95,
    adSkipSpeed: "16",
    smartUgcSense: true,
    shortlinkBypassEnabled: true,
    shortlinkAutoClick: true,
    loggingEnabled: true,
    removeTransparentOverlay: true,
    antiHistoryTrap: true,
    dnrEnabled: true,
    redirectWindowSec: 3.5
  });
  var DEFAULT_HUD_POSITIONS = Object.freeze({
    topHud: null,
    videoDock: null,
    miniPip: null
  });
  var DEFAULT_STATS = Object.freeze({
    blocked: 0,
    bypassed: 0,
    allowed: 0
  });
  var SUSPICIOUS_TLD = /\.(cfd|xyz|top|cyou|icu|buzz|click|link|monster|quest|rest|sbs|shop|site|tokyo|vip|wang|win|work|wtf|zone|live|asia|online|store|fun|pro|club|cam|cc|me|pw|tk|ml|ga|cf|gq)$/i;
  var GAMBLING_KEYWORDS = /(slot|gacor|maxwin|zeus|pragmatic|togel|judol|casino|betting|scatter|rtp|deposit|wd|bonus100|situsresmi|linkalternatif|sbobet|poker|judi|bandar|slot88|gacor88|pascol4d|dewadora|toto4d)/i;
  var COMMERCE_AFFILIATE_REGEX = /(shopee\.|shope\.ee|tokopedia\.|lazada\.|blibli\.|bukalapak\.|tiktok\.com\/t\/|invol\.co|accesstrade|admitad|ecotrack|go2cloud|onclickalgo|popads|popcash|propellerads|adsterra|hilltopads|exoclick|juicyads|trafficjunky|monetag|richads|wpadmngr|clickadu)/i;
  var RANDOM_SHORT_DOMAIN_REGEX = /^[a-z0-9]{2,4}[0-9][a-z0-9]{1,4}\.(com|net|org|co|id|io|info|biz)$/i;
  var SEARCH_ARBITRAGE_PARAMS = /(utm_source=.*ad|utm_medium=affiliate|af_siteid=|af_sub|clickid=|click_id=|subid=|sub_id=|aff_id=|zoneid=|bannerid=|popunder|redirect|gclid=|fbclid=.*ad)/i;
  var SAFE_MEDIA_HOST_REGEX = /(^|\.)(ibb\.co|ibb\.co\.com|imgur\.com|postimg\.cc|pixhost\.to|imgbox\.com|imagebam\.com|prnt\.sc|prntscr\.com|gyazo\.com|flickr\.com|staticflickr\.com|wikimedia\.org|tenor\.com|giphy\.com|redgifs\.com|catbox\.moe|bunkr\.(si|ru|is|la|sk|ax|ac|black|red|media|site)|cyberdrop\.(me|to|cc)|pixeldrain\.com|gofile\.io|mega\.nz|mediafire\.com|drive\.google\.com|docs\.google\.com|dropbox\.com)$/i;
  var KNOWN_AD_SHORTENER_REGEX = /(^|\.)(optional\.me|see\.optional\.me|rebrand\.ly|bit\.ly|t\.ly|tinyurl\.com|is\.gd|v\.gd|cutt\.ly|shorturl\.at|ouo\.io|shrinkme\.io|exe\.io|bc\.vc|adf\.ly|linkvertise\.com)$/i;
  var AUTH_PATH_OR_PARAM_REGEX = /(\/(login|signin|sign-in|log-in|auth|oauth|oauth2|sso|saml|openid|oidc|authorize|callback|session|account|accounts|passport|idp|cas|connect\/authorize|v2\/auth|cdn-cgi\/challenge-platform)(\/|$)|[?&](client_id|redirect_uri|response_type|state|scope|openid|code_challenge|samlrequest|return_to|continue|_xfRedirect|__cf_chl_tk|__cf_chl_rt_tk|__cf_chl_f_tk)=)/i;
  var AUTH_SUBDOMAIN_REGEX = /^(accounts|auth|login|signin|sso|id|oauth|passport|idp|iam|auth0|okta)\./i;
  var AUTH_PROVIDER_HOST_REGEX = /(^|\.)(auth0\.com|okta\.com|onelogin\.com|cloudflareaccess\.com|login\.microsoftonline\.com|accounts\.google\.com|appleid\.apple\.com|github\.com)$/i;
  var CHALLENGE_HOST_REGEX = /(challenges\.cloudflare\.com|cloudflarecaptcha\.com|hcaptcha\.com|recaptcha\.net|gstatic\.com\/recaptcha|arkoselabs\.com|funcaptcha\.com|captcha-delivery\.com|datadome\.co|perimeterx\.net|dnstest\.dev)/i;
  var SAFE_ECOSYSTEM_GROUPS = [
    /(^|\.)(yandex\.(com|ru|kz|by|uz|ua|tr|net)|ya\.ru|yastatic\.net)$/i,
    /(^|\.)(google\.(com|co\.id|com\.sg|com\.my)|googleapis\.com|gstatic\.com|youtube\.com|youtu\.be)$/i,
    /(^|\.)(microsoft\.com|live\.com|bing\.com|msn\.com|microsoftonline\.com|login\.windows\.net)$/i,
    /(^|\.)(apple\.com|icloud\.com)$/i,
    /(^|\.)(github\.com|githubusercontent\.com)$/i,
    /(^|\.)(facebook\.com|fb\.com|instagram\.com)$/i,
    /(^|\.)(discord\.com|discordapp\.com)$/i
  ];
  var NON_VIDEO_ASSET_REGEX = /\.(jpg|jpeg|png|gif|webp|svg|ico|bmp|avif|css|js|json|woff2?|ttf|eot|vtt|srt)(\?|#|$)/i;
  var VIDEO_EXT_REGEX = /\.(mp4|m3u8|mkv|webm|mov|avi|flv|ts|mpd)(\?|#|$)/i;
  var VIDEO_STREAM_HINT_REGEX = /(\/pass_md5\/|\/hls\/|\/stream\/|\/get_video|mime=video|videoplayback|master\.txt|index\.txt|doodcdn|cloudcdn|vidcdn|\/token\/|\/delivery\/)/i;
  var DISGUISED_AD_CLASS_REGEX = /\b(itr|sambannerunit|samitem|samcodeunit|samad|ad-banner|adbanner|banner-ads|sponsored-slot|promo-banner|slot-banner|judol-banner|ad-rotator|popunder-trigger|aff-banner)\b/i;
  var AD_SLOT_CLASS_ID_REGEX = /\b(sambannerunit|samcodeunit|samitem|samad|ad-container|ads-wrapper|banner-iklan|slot-iklan|iklan-banner|sponsor-banner|floating-ad|sticky-ad)\b/i;

  // src/ext/shared/debug.js
  var debugEnabled = false;
  var debugSink = null;
  function setDebugEnabled(enabled) {
    debugEnabled = Boolean(enabled);
  }
  function setDebugSink(sinkFn) {
    debugSink = typeof sinkFn === "function" ? sinkFn : null;
  }
  function logInternalError(scope, err) {
    if (!debugEnabled || !debugSink) return;
    try {
      const message = err instanceof Error ? `${err.name}: ${err.message}` : String(err || "Unknown internal error");
      debugSink({
        scope: String(scope || "internal"),
        message: message.slice(0, 260)
      });
    } catch {
    }
  }
  function safeTry(scope, fn, fallback) {
    try {
      return fn();
    } catch (err) {
      logInternalError(scope, err);
      return (
        /** @type {T} */
        fallback
      );
    }
  }

  // src/ext/shared/domain-utils.js
  var SECOND_LEVEL_PUBLIC_SUFFIXES = /* @__PURE__ */ new Set([
    "co",
    "com",
    "net",
    "org",
    "ac",
    "go",
    "or",
    "web",
    "sch"
  ]);
  var VALID_DOMAIN_REGEX = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)+$/i;
  function getHostname(urlStr, baseHref) {
    if (!urlStr) return "";
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      return (u.hostname || "").toLowerCase();
    } catch {
      return "";
    }
  }
  function getBaseDomain(hostname) {
    const clean = String(hostname || "").trim().toLowerCase().replace(/^www\./, "");
    const parts = clean.split(".").filter(Boolean);
    if (parts.length <= 2) return clean;
    const sld = parts[parts.length - 2];
    if (SECOND_LEVEL_PUBLIC_SUFFIXES.has(sld) && parts.length >= 3) {
      return parts.slice(-3).join(".");
    }
    return parts.slice(-2).join(".");
  }
  function normalizeDomainEntry(raw) {
    if (!raw) return "";
    let val = String(raw).trim().toLowerCase();
    if (!val) return "";
    try {
      if (val.includes("://")) {
        val = new URL(val).hostname.toLowerCase();
      } else {
        val = val.replace(/^\|\|/, "").replace(/\^.*$/, "").replace(/^\*\./, "").split("/")[0].split("?")[0].split("#")[0].split(":")[0];
      }
    } catch {
      val = val.split("/")[0].split("?")[0].split("#")[0];
    }
    val = val.replace(/^www\./, "").trim();
    if (!val || !VALID_DOMAIN_REGEX.test(val)) return "";
    return val;
  }
  function isDomainInList(urlStr, list, baseHref) {
    if (!urlStr || !Array.isArray(list) || list.length === 0) return false;
    const host = getHostname(urlStr, baseHref).replace(/^www\./, "");
    if (!host) return false;
    const base = getBaseDomain(host);
    for (const item of list) {
      const rule = normalizeDomainEntry(item);
      if (!rule) continue;
      const ruleBase = getBaseDomain(rule);
      if (host === rule || base === rule || host === ruleBase || base === ruleBase || host.endsWith("." + rule) || host.endsWith("." + ruleBase)) {
        return true;
      }
    }
    return false;
  }
  function isSameSafeEcosystem(hostA, hostB) {
    if (!hostA || !hostB) return false;
    return SAFE_ECOSYSTEM_GROUPS.some((rx) => rx.test(hostA) && rx.test(hostB));
  }
  function getTemporaryAllowState(tempAllowMap, urlStr, now = Date.now()) {
    if (!tempAllowMap || typeof tempAllowMap !== "object" || !urlStr) {
      return { active: false, domain: "", remainingMs: 0 };
    }
    const host = getHostname(urlStr).replace(/^www\./, "");
    if (!host) return { active: false, domain: "", remainingMs: 0 };
    const base = getBaseDomain(host);
    const candidates = [host, base];
    for (const key of candidates) {
      const exp = Number(tempAllowMap[key]);
      if (Number.isFinite(exp) && exp > now) {
        return { active: true, domain: key, remainingMs: exp - now };
      }
    }
    return { active: false, domain: "", remainingMs: 0 };
  }
  function pruneExpiredTempAllows(tempAllowMap, now = Date.now()) {
    const next = {};
    if (!tempAllowMap || typeof tempAllowMap !== "object") return next;
    for (const [dom, exp] of Object.entries(tempAllowMap)) {
      if (Number.isFinite(Number(exp)) && Number(exp) > now) {
        next[dom] = Number(exp);
      }
    }
    return next;
  }

  // src/ext/shared/shortlink-decoder.js
  var SHORTLINK_QUERY_KEYS = [
    "url",
    "u",
    "go",
    "to",
    "target",
    "dest",
    "destination",
    "link",
    "r",
    "redir",
    "redirect",
    "o",
    "site",
    "next",
    "out",
    "a",
    "b",
    "data",
    "safelink",
    "id"
  ];
  function safeShortlinkBase64Decode(raw) {
    try {
      let normalized = String(raw || "").trim().replace(/-/g, "+").replace(/_/g, "/");
      if (!normalized || normalized.length < 8) return "";
      if (!/^[A-Za-z0-9+/=]+$/.test(normalized)) return "";
      while (normalized.length % 4 !== 0) normalized += "=";
      return atob(normalized);
    } catch {
      return "";
    }
  }
  function extractHttpUrlFromDecodedStr(raw) {
    if (!raw || typeof raw !== "string") return "";
    const trimmed = raw.trim();
    if (/^https?:\/\/[^\s"'<>]+$/i.test(trimmed)) return trimmed;
    try {
      const parsed = JSON.parse(trimmed);
      if (parsed && typeof parsed === "object") {
        for (const key of ["linkr", "url", "link", "target", "go", "dest", "redirect"]) {
          const val = parsed[key];
          if (typeof val === "string" && /^https?:\/\/[^\s"'<>]+/i.test(val.trim())) {
            return val.trim();
          }
        }
      }
    } catch {
    }
    const m = trimmed.match(/https?:\/\/[^\s"'<>\\]+/i);
    return m ? m[0] : "";
  }
  function decodeShortlinkCandidateValue(rawValue) {
    if (!rawValue || typeof rawValue !== "string") return null;
    let val = rawValue.trim();
    if (val.length < 8 || val.length > 2400) return null;
    try {
      const dec = decodeURIComponent(val);
      if (dec) val = dec.trim();
    } catch {
    }
    if (/^https?:\/\//i.test(val)) {
      return { url: val, method: "QUERY_PLAIN" };
    }
    const revPlain = val.split("").reverse().join("");
    if (/^https?:\/\//i.test(revPlain)) {
      return { url: revPlain, method: "QUERY_REVERSED" };
    }
    const b1 = safeShortlinkBase64Decode(val);
    if (b1) {
      const u1 = extractHttpUrlFromDecodedStr(b1);
      if (u1) return { url: u1, method: "QUERY_BASE64" };
      const b2 = safeShortlinkBase64Decode(b1);
      if (b2) {
        const u2 = extractHttpUrlFromDecodedStr(b2);
        if (u2) return { url: u2, method: "QUERY_DOUBLE_BASE64" };
      }
    }
    const revB1 = safeShortlinkBase64Decode(revPlain);
    if (revB1) {
      const ru1 = extractHttpUrlFromDecodedStr(revB1);
      if (ru1) return { url: ru1, method: "QUERY_REVERSED_BASE64" };
    }
    return null;
  }
  function isShortlinkBypassTargetSafe(candidateUrl, pageUrl, deniedList = []) {
    if (!candidateUrl) return false;
    try {
      const target = new URL(candidateUrl);
      if (target.protocol !== "http:" && target.protocol !== "https:") return false;
      const cur = new URL(pageUrl);
      if (target.href === cur.href) return false;
      const targetHost = target.hostname.toLowerCase();
      const curHost = cur.hostname.toLowerCase();
      if (getBaseDomain(targetHost) === getBaseDomain(curHost)) return false;
      if (isDomainInList(target.href, deniedList)) return false;
      if (GAMBLING_KEYWORDS.test(target.href) || COMMERCE_AFFILIATE_REGEX.test(target.href) || SEARCH_ARBITRAGE_PARAMS.test(target.href)) {
        return false;
      }
      return true;
    } catch {
      return false;
    }
  }
  function extractDirectShortlinkFromInputs({
    pageUrl,
    hiddenValues = [],
    metaRefreshContent = "",
    deniedList = []
  }) {
    try {
      const u = new URL(pageUrl);
      for (const key of SHORTLINK_QUERY_KEYS) {
        const val = u.searchParams.get(key);
        if (!val) continue;
        const decoded = decodeShortlinkCandidateValue(val);
        if (decoded && isShortlinkBypassTargetSafe(decoded.url, pageUrl, deniedList)) {
          return { found: true, url: decoded.url, method: decoded.method };
        }
      }
      if (u.hash && u.hash.length > 10) {
        const hashRaw = u.hash.replace(/^#!?\/?/, "");
        const decodedHash = decodeShortlinkCandidateValue(hashRaw);
        if (decodedHash && isShortlinkBypassTargetSafe(decodedHash.url, pageUrl, deniedList)) {
          return { found: true, url: decodedHash.url, method: "HASH_DECODED" };
        }
      }
      for (const rawVal of hiddenValues) {
        if (!rawVal) continue;
        const decoded = decodeShortlinkCandidateValue(rawVal);
        if (decoded && isShortlinkBypassTargetSafe(decoded.url, pageUrl, deniedList)) {
          return { found: true, url: decoded.url, method: "HIDDEN_INPUT_SAFELINK" };
        }
      }
      if (metaRefreshContent) {
        const m = metaRefreshContent.match(/url\s*=\s*['"]?(https?:\/\/[^'";\s]+)/i);
        if (m && m[1] && isShortlinkBypassTargetSafe(m[1], pageUrl, deniedList)) {
          return { found: true, url: m[1], method: "META_REFRESH" };
        }
      }
    } catch {
    }
    return { found: false, url: "", method: "NONE" };
  }
  function isShortlinkCtaCandidate(info) {
    const rawHref = String(info.rawHref || "").trim();
    const text = String(info.text || "").trim().toLowerCase();
    const idCls = `${info.id || ""} ${info.className || ""}`.toLowerCase();
    const cardText = String(info.cardText || "").toLowerCase();
    const hasTokenQuery = /[?&](download|dl|go|token|t|hash|key|id|redirect|link)=/i.test(rawHref);
    const hasCtaText = /(go\s*to\s*link|get\s*link|lanjut(kan)?|visit\s*link|open\s*link|download|unduh|buka\s*link|continue|proceed|skip\s*ad|menuju\s*link)/i.test(
      text
    );
    const hasCtaIdOrClass = /(babay|get-?link|go-?link|wpsafe|btn-?download|btn-?continue|redirect-?btn|skip-?btn)/i.test(idCls);
    const hasRedirectCardHint = /(redirect\s*ready|please\s*wait|link\s*ready|your\s*link\s*is\s*almost\s*ready|tunggu\s*sebentar)/i.test(
      cardText
    );
    return Boolean(
      hasTokenQuery && (hasCtaText || hasCtaIdOrClass || hasRedirectCardHint) || hasCtaText && (hasCtaIdOrClass || hasRedirectCardHint)
    );
  }

  // src/ext/shared/url-classifier.js
  function isAuthFlowUrl(urlStr) {
    if (!urlStr) return false;
    try {
      const u = new URL(urlStr);
      const host = u.hostname.toLowerCase();
      return AUTH_SUBDOMAIN_REGEX.test(host) || AUTH_PROVIDER_HOST_REGEX.test(host) || AUTH_PATH_OR_PARAM_REGEX.test(u.pathname + u.search);
    } catch {
      return false;
    }
  }
  function isHardMaliciousUrl(urlStr, deniedList = [], baseHref) {
    if (!urlStr) return false;
    try {
      const u = baseHref ? new URL(urlStr, baseHref) : new URL(urlStr);
      const host = u.hostname.toLowerCase();
      const baseHost = getBaseDomain(host);
      if (isDomainInList(u.href, deniedList)) return true;
      return GAMBLING_KEYWORDS.test(u.href) || COMMERCE_AFFILIATE_REGEX.test(u.href) || RANDOM_SHORT_DOMAIN_REGEX.test(baseHost) || SEARCH_ARBITRAGE_PARAMS.test(u.href) || KNOWN_AD_SHORTENER_REGEX.test(host);
    } catch {
      return false;
    }
  }

  // src/ext/content/state.js
  var BRIDGE_TOKEN = (() => {
    try {
      const bytes = new Uint8Array(12);
      crypto.getRandomValues(bytes);
      return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
    } catch {
      return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
    }
  })();
  var runtimeState = {
    trustedDomains: (
      /** @type {string[]} */
      []
    ),
    deniedDomains: (
      /** @type {string[]} */
      []
    ),
    strictCrossOrigin: false,
    autoSkipCountdown: true,
    globalSettings: { ...DEFAULT_GLOBAL_SETTINGS },
    hudPositions: { ...DEFAULT_HUD_POSITIONS },
    /** @type {Record<string, number>} */
    tempAllowMap: {},
    captchaDetected: false,
    shortlinkBypassActionTaken: false,
    /** @type {Array<{ blockedUrl: string, message: string, kind: string }>} */
    manualPromptQueue: [],
    /** @type {string[]} */
    detectedVideos: [],
    videoDockDimmed: true,
    videoDrawerOpen: false,
    activeMiniVideoEl: (
      /** @type {HTMLVideoElement | null} */
      null
    ),
    miniPlayerActive: false,
    portraitFullscreenActive: false
  };
  var stateChangeListeners = [];
  function onRuntimeStateChange(cb) {
    if (typeof cb === "function") stateChangeListeners.push(cb);
  }
  function notifyRuntimeStateChange() {
    for (const cb of stateChangeListeners) {
      safeTry("content.stateChangeCb", cb);
    }
  }
  function isTempAllowActiveHere() {
    return getTemporaryAllowState(runtimeState.tempAllowMap, location.href).active;
  }
  function isUrlInTrustedList(urlStr) {
    return isDomainInList(urlStr, runtimeState.trustedDomains, location.href);
  }
  function isUrlInDeniedList(urlStr) {
    return isDomainInList(urlStr, runtimeState.deniedDomains, location.href);
  }
  function logAegisEvent(level, code, toUrl = "", detail = "", source = "content") {
    if (level !== "DEBUG" && runtimeState.globalSettings.loggingEnabled === false) return;
    safeTry("content.logAegisEvent", () => {
      chrome.runtime.sendMessage({
        type: "APPEND_AEGIS_LOG",
        entry: {
          level: level || "WARN",
          source,
          code: code || "CONTENT_EVENT",
          fromUrl: location.href,
          toUrl: toUrl ? String(toUrl) : "",
          detail: detail ? String(detail) : ""
        }
      });
    });
  }
  setDebugSink(({ scope, message }) => {
    logAegisEvent("DEBUG", `ERR_${scope.toUpperCase().replace(/[^A-Z0-9_]/g, "_")}`, "", message, "content");
  });
  function initMainWorldHandshake() {
    safeTry("content.initHandshake", () => {
      window.dispatchEvent(
        new CustomEvent(BRIDGE_EVENTS.HANDSHAKE_INIT, {
          detail: { token: BRIDGE_TOKEN }
        })
      );
    });
  }
  function syncMainWorldRules() {
    initMainWorldHandshake();
    safeTry("content.syncMainWorldRules", () => {
      window.dispatchEvent(
        new CustomEvent(BRIDGE_EVENTS.SYNC_RULES, {
          detail: {
            token: BRIDGE_TOKEN,
            trusted: runtimeState.trustedDomains,
            denied: runtimeState.deniedDomains,
            protectionMode: runtimeState.globalSettings.protectionMode || "balanced",
            strictCrossOrigin: runtimeState.globalSettings.protectionMode === "strict" || runtimeState.strictCrossOrigin,
            autoSkipCountdown: runtimeState.autoSkipCountdown,
            tempAllowActive: isTempAllowActiveHere(),
            globalSettings: runtimeState.globalSettings
          }
        })
      );
    });
  }
  function signalCaptchaToMainWorld(detected = true) {
    if (detected) runtimeState.captchaDetected = true;
    safeTry("content.signalCaptcha", () => {
      window.dispatchEvent(
        new CustomEvent(BRIDGE_EVENTS.CAPTCHA_SIGNAL, {
          detail: { token: BRIDGE_TOKEN, detected: Boolean(detected) }
        })
      );
    });
  }
  function signalShortlinkCtaToMainWorld() {
    safeTry("content.signalShortlinkCta", () => {
      window.dispatchEvent(
        new CustomEvent(BRIDGE_EVENTS.SHORTLINK_CTA_CLICK, {
          detail: { token: BRIDGE_TOKEN }
        })
      );
    });
  }
  function addDomainToBlacklist(urlStr, callback) {
    const dom = normalizeDomainEntry(urlStr);
    if (!dom) return;
    if (!runtimeState.deniedDomains.includes(dom)) {
      runtimeState.deniedDomains = [...runtimeState.deniedDomains, dom];
    }
    runtimeState.trustedDomains = runtimeState.trustedDomains.filter((d) => d !== dom);
    safeTry("content.addBlacklist", () => {
      chrome.storage.local.set(
        {
          deniedDomains: runtimeState.deniedDomains,
          trustedDomains: runtimeState.trustedDomains
        },
        () => {
          syncMainWorldRules();
          if (typeof callback === "function") callback(dom);
        }
      );
    });
  }
  function addDomainToWhitelist(urlStr, callback) {
    const dom = normalizeDomainEntry(urlStr);
    if (!dom) return;
    if (!runtimeState.trustedDomains.includes(dom)) {
      runtimeState.trustedDomains = [...runtimeState.trustedDomains, dom];
    }
    runtimeState.deniedDomains = runtimeState.deniedDomains.filter((d) => d !== dom);
    safeTry("content.addWhitelist", () => {
      chrome.storage.local.set(
        {
          trustedDomains: runtimeState.trustedDomains,
          deniedDomains: runtimeState.deniedDomains
        },
        () => {
          syncMainWorldRules();
          if (typeof callback === "function") callback(dom);
        }
      );
    });
  }
  function purgeBlacklistedOrTrustedPrompts() {
    runtimeState.manualPromptQueue = runtimeState.manualPromptQueue.filter(
      (item) => item && item.blockedUrl && !isUrlInDeniedList(item.blockedUrl) && !isUrlInTrustedList(item.blockedUrl)
    );
  }
  function initStorageSync() {
    initMainWorldHandshake();
    const readyPromise = new Promise((resolve) => {
      safeTry(
        "content.loadInitialStorage",
        () => {
          chrome.storage.local.get(
            [
              "trustedDomains",
              "deniedDomains",
              "strictCrossOrigin",
              "autoSkipCountdown",
              "globalSettings",
              "hudPositions",
              "tempAllowMap"
            ],
            (res) => {
              runtimeState.trustedDomains = Array.isArray(res.trustedDomains) ? res.trustedDomains : [];
              runtimeState.deniedDomains = Array.isArray(res.deniedDomains) ? res.deniedDomains : [];
              runtimeState.strictCrossOrigin = Boolean(res.strictCrossOrigin);
              runtimeState.autoSkipCountdown = res.autoSkipCountdown !== false;
              runtimeState.globalSettings = {
                ...DEFAULT_GLOBAL_SETTINGS,
                ...res.globalSettings && typeof res.globalSettings === "object" ? res.globalSettings : {}
              };
              runtimeState.hudPositions = {
                ...DEFAULT_HUD_POSITIONS,
                ...res.hudPositions && typeof res.hudPositions === "object" ? res.hudPositions : {}
              };
              runtimeState.tempAllowMap = pruneExpiredTempAllows(res.tempAllowMap || {});
              setDebugEnabled(Boolean(runtimeState.globalSettings.debugInternalErrors));
              purgeBlacklistedOrTrustedPrompts();
              syncMainWorldRules();
              notifyRuntimeStateChange();
              resolve();
            }
          );
        },
        void 0
      );
    });
    safeTry("content.registerStorageChanged", () => {
      chrome.storage.onChanged.addListener((changes, areaName) => {
        if (areaName !== "local" && areaName !== "session") return;
        let changed = false;
        if (changes.trustedDomains) {
          runtimeState.trustedDomains = Array.isArray(changes.trustedDomains.newValue) ? changes.trustedDomains.newValue : [];
          changed = true;
        }
        if (changes.deniedDomains) {
          runtimeState.deniedDomains = Array.isArray(changes.deniedDomains.newValue) ? changes.deniedDomains.newValue : [];
          changed = true;
        }
        if (changes.strictCrossOrigin) {
          runtimeState.strictCrossOrigin = Boolean(changes.strictCrossOrigin.newValue);
          changed = true;
        }
        if (changes.autoSkipCountdown) {
          runtimeState.autoSkipCountdown = changes.autoSkipCountdown.newValue !== false;
          changed = true;
        }
        if (changes.globalSettings) {
          runtimeState.globalSettings = {
            ...DEFAULT_GLOBAL_SETTINGS,
            ...changes.globalSettings.newValue || {}
          };
          setDebugEnabled(Boolean(runtimeState.globalSettings.debugInternalErrors));
          changed = true;
        }
        if (changes.hudPositions) {
          runtimeState.hudPositions = {
            ...DEFAULT_HUD_POSITIONS,
            ...changes.hudPositions.newValue || {}
          };
          changed = true;
        }
        if (changes.tempAllowMap) {
          runtimeState.tempAllowMap = pruneExpiredTempAllows(changes.tempAllowMap.newValue || {});
          changed = true;
        }
        if (changed) {
          purgeBlacklistedOrTrustedPrompts();
          syncMainWorldRules();
          notifyRuntimeStateChange();
        }
      });
    });
    window.addEventListener(BRIDGE_EVENTS.REQUEST_RULES, () => {
      syncMainWorldRules();
    });
    return readyPromise;
  }

  // src/ext/content/position-manager.js
  function clampHudPosition(left, top, elWidth, elHeight, margin = 4, minTopOverride = null) {
    const vw = Math.max(window.innerWidth || 360, 200);
    const vh = Math.max(window.innerHeight || 640, 200);
    const w = Math.max(24, Number(elWidth) || 60);
    const h = Math.max(24, Number(elHeight) || 36);
    const minLeft = margin;
    const maxLeft = Math.max(minLeft, vw - w - margin);
    const minTop = typeof minTopOverride === "number" ? minTopOverride : margin;
    const maxTop = Math.max(minTop, vh - h - margin);
    return {
      left: Math.round(Math.max(minLeft, Math.min(maxLeft, Number(left) || 0))),
      top: Math.round(Math.max(minTop, Math.min(maxTop, Number(top) || 0)))
    };
  }
  function createSavedHudCoord(left, top, elWidth, elHeight, margin = 4, minTopOverride = null) {
    const vw = Math.max(window.innerWidth || 360, 200);
    const vh = Math.max(window.innerHeight || 640, 200);
    const w = Math.max(24, Number(elWidth) || 60);
    const clamped = clampHudPosition(left, top, w, elHeight, margin, minTopOverride);
    const centerX = clamped.left + w / 2;
    const anchorSide = centerX < vw / 2 ? "left" : "right";
    const rightOffset = Math.max(margin, Math.round(vw - (clamped.left + w)));
    return {
      left: clamped.left,
      top: clamped.top,
      rightOffset,
      anchorSide,
      leftRatio: Number((clamped.left / vw).toFixed(4)),
      topRatio: Number((clamped.top / vh).toFixed(4)),
      savedAt: Date.now()
    };
  }
  function resolveSavedHudCoord(saved, elWidth, elHeight, margin = 4, minTopOverride = null) {
    if (!saved || typeof saved !== "object") return null;
    const vw = Math.max(window.innerWidth || 360, 200);
    const vh = Math.max(window.innerHeight || 640, 200);
    const w = Math.max(24, Number(elWidth) || 60);
    const h = Math.max(24, Number(elHeight) || 36);
    let left = typeof saved.left === "number" ? saved.left : 0;
    let top = typeof saved.top === "number" ? saved.top : 0;
    if (saved.anchorSide === "right" && typeof saved.rightOffset === "number") {
      left = vw - w - saved.rightOffset;
    } else if (typeof saved.leftRatio === "number" && (left > vw - w || left < 0)) {
      left = saved.leftRatio * vw;
    }
    if (typeof saved.topRatio === "number" && (top > vh - h || top < 0)) {
      top = saved.topRatio * vh;
    }
    const clamped = clampHudPosition(left, top, w, h, margin, minTopOverride);
    return {
      left: clamped.left,
      top: clamped.top,
      right: Math.max(margin, Math.round(vw - (clamped.left + w))),
      anchorSide: saved.anchorSide || (clamped.left + w / 2 < vw / 2 ? "left" : "right")
    };
  }
  function getEffectiveVideoDockDir() {
    const pref = runtimeState.globalSettings.videoDockExpandDir || "auto";
    if (pref === "ltr" || pref === "rtl") return pref;
    const saved = runtimeState.hudPositions.videoDock;
    if (saved && saved.anchorSide === "left") return "ltr";
    if (saved && saved.anchorSide === "right") return "rtl";
    return "rtl";
  }
  function saveHudPosition(key, coordObj) {
    runtimeState.hudPositions = {
      ...runtimeState.hudPositions,
      [key]: coordObj
    };
    safeTry("position.saveHudPosition", () => {
      chrome.storage.local.set({ hudPositions: { ...runtimeState.hudPositions } });
    });
  }
  function getMiniPlayerSafeTop() {
    return 26;
  }

  // src/ext/content/hud-manager.js
  var TOP_HUD_ID = "aegis-top-manual-hud";
  var TOAST_ID = "aegis-bypass-toast-host";
  var topHudHideTimer = null;
  function escapeHtml(str) {
    return String(str || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function enqueueManualPrompt(item) {
    if (!item || !item.blockedUrl) return;
    if (isUrlInDeniedList(item.blockedUrl) || isUrlInTrustedList(item.blockedUrl)) return;
    const exists = runtimeState.manualPromptQueue.some((p) => p.blockedUrl === item.blockedUrl);
    if (!exists) {
      runtimeState.manualPromptQueue.push({
        blockedUrl: item.blockedUrl,
        message: item.message || "Redirect/popup ditahan",
        kind: item.kind || "redirect"
      });
      if (runtimeState.manualPromptQueue.length > 10) {
        runtimeState.manualPromptQueue.shift();
      }
    }
    renderTopManualHUD();
  }
  function updateTopManualHudSavedPosition() {
    const host = document.getElementById(TOP_HUD_ID);
    if (!host) return;
    const saved = runtimeState.hudPositions.topHud;
    if (!saved) return;
    const rect = host.getBoundingClientRect();
    const resolved = resolveSavedHudCoord(saved, rect.width || 360, rect.height || 130, 8);
    if (resolved) {
      host.style.left = `${resolved.left}px`;
      host.style.top = `${resolved.top}px`;
      host.style.right = "auto";
      host.style.bottom = "auto";
      host.style.transform = `scale(${Number(runtimeState.globalSettings.hudScale) || 1})`;
    }
  }
  function renderTopManualHUD() {
    if (window !== window.top) return;
    purgeBlacklistedOrTrustedPrompts();
    const existing = document.getElementById(TOP_HUD_ID);
    if (runtimeState.globalSettings.hudEnabled === false || runtimeState.manualPromptQueue.length === 0) {
      if (existing) existing.remove();
      clearTimeout(topHudHideTimer);
      return;
    }
    const current = runtimeState.manualPromptQueue[0];
    const hostName = getHostname(current.blockedUrl).replace(/^www\./, "") || current.blockedUrl;
    const g = runtimeState.globalSettings;
    const hudScale = Math.max(0.75, Math.min(1.3, Number(g.hudScale) || 1));
    const hudOpacity = Math.max(0.5, Math.min(1, Number(g.hudOpacity) || 0.95));
    const hudDurationSec = Math.max(0, Math.min(15, Number(g.hudDurationSec ?? 4.5)));
    let hostEl = existing;
    if (!hostEl) {
      hostEl = document.createElement("div");
      hostEl.id = TOP_HUD_ID;
      hostEl.style.cssText = "position:fixed;z-index:2147483647;pointer-events:auto;max-width:calc(100vw - 16px);";
      (document.documentElement || document.body).appendChild(hostEl);
    }
    const saved = runtimeState.hudPositions.topHud;
    hostEl.style.opacity = String(hudOpacity);
    if (saved) {
      const resolved = resolveSavedHudCoord(saved, 360, 130, 8);
      hostEl.style.left = `${resolved ? resolved.left : 12}px`;
      hostEl.style.top = `${resolved ? resolved.top : 12}px`;
      hostEl.style.right = "auto";
      hostEl.style.bottom = "auto";
      hostEl.style.transformOrigin = "top left";
      hostEl.style.transform = `scale(${hudScale})`;
    } else {
      const preset = g.hudPosition || "top-center";
      hostEl.style.left = preset === "top-left" ? "12px" : preset === "top-right" ? "auto" : "50%";
      hostEl.style.right = preset === "top-right" ? "12px" : "auto";
      hostEl.style.top = preset === "bottom-center" ? "auto" : "12px";
      hostEl.style.bottom = preset === "bottom-center" ? "16px" : "auto";
      hostEl.style.transformOrigin = preset === "top-left" ? "top left" : preset === "top-right" ? "top right" : preset === "bottom-center" ? "bottom center" : "top center";
      hostEl.style.transform = preset === "top-left" || preset === "top-right" ? `scale(${hudScale})` : `translateX(-50%) scale(${hudScale})`;
    }
    const shadow = hostEl.shadowRoot || hostEl.attachShadow({ mode: "open" });
    const queueBadge = runtimeState.manualPromptQueue.length > 1 ? `<span class="q-badge">1/${runtimeState.manualPromptQueue.length}</span>` : "";
    const timerBadge = `<span class="t-badge">⏱ ${hudDurationSec === 0 ? "∞" : hudDurationSec.toFixed(1) + "d"}</span>`;
    shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }
      .card { width: 356px; max-width: calc(100vw - 16px); background: rgba(15,23,42,0.96); color: #f8fafc; border: 1px solid rgba(52,211,153,0.45); border-radius: 14px; padding: 11px 12px; box-shadow: 0 14px 36px rgba(0,0,0,0.55); backdrop-filter: blur(10px); }
      .head { display: flex; align-items: center; justify-content: space-between; gap: 6px; margin-bottom: 8px; cursor: grab; user-select: none; touch-action: none; }
      .head:active { cursor: grabbing; }
      .title-wrap { display: flex; align-items: center; gap: 6px; min-width: 0; }
      .grip { color: #34d399; font-weight: 800; font-size: 13px; }
      .msg { font-size: 11.5px; font-weight: 700; color: #f1f5f9; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .q-badge { font-size: 10px; font-weight: 700; color: #38bdf8; flex-shrink: 0; }
      .t-badge { font-size: 9.5px; font-family: ui-monospace, monospace; font-weight: 700; color: #6ee7b7; background: rgba(16,185,129,0.16); border: 1px solid rgba(16,185,129,0.35); border-radius: 4px; padding: 1px 5px; flex-shrink: 0; }
      .close-btn { width: 20px; height: 20px; border-radius: 999px; border: none; background: #1e293b; color: #94a3b8; font-size: 11px; font-weight: 700; cursor: pointer; flex-shrink: 0; }
      .close-btn:hover { background: #7f1d1d; color: #fecaca; }
      .url-box { display: flex; align-items: center; justify-content: space-between; gap: 8px; background: #020617; border: 1px solid #1e293b; border-radius: 8px; padding: 6px 8px; margin-bottom: 8px; }
      .host { font-family: ui-monospace, monospace; font-size: 11px; font-weight: 600; color: #e2e8f0; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .detail-toggle { background: none; border: none; color: #38bdf8; font-size: 10px; font-weight: 700; cursor: pointer; flex-shrink: 0; }
      .full-url { display: none; font-family: ui-monospace, monospace; font-size: 9.5px; color: #94a3b8; background: #020617; border: 1px solid #1e293b; border-radius: 6px; padding: 6px; margin-bottom: 8px; word-break: break-all; max-height: 70px; overflow-y: auto; }
      .full-url.open { display: block; }
      .actions { display: grid; grid-template-columns: repeat(auto-fit, minmax(70px, 1fr)); gap: 5px; }
      .btn { border: none; border-radius: 8px; padding: 6px 6px; font-size: 10.5px; font-weight: 700; cursor: pointer; white-space: nowrap; }
      .btn-trust { background: #10b981; color: #022c22; }
      .btn-group { background: #334155; color: #f8fafc; }
      .btn-open { background: #0284c7; color: #fff; }
      .btn-block { background: rgba(127,29,29,0.85); color: #fca5a5; border: 1px solid rgba(239,68,68,0.45); }
    </style>
    <div class="card">
      <div class="head" id="dragHead" title="Geser untuk memindahkan HUD">
        <div class="title-wrap">
          <span class="grip">⠿</span>
          <span class="msg">${escapeHtml(current.message)}</span>
          ${queueBadge}
          ${timerBadge}
        </div>
        <button class="close-btn" id="dismissBtn" title="Tutup">✕</button>
      </div>
      <div class="url-box">
        <span class="host">${escapeHtml(hostName)}</span>
        ${g.hudShowUrlDetail !== false ? `<button class="detail-toggle" id="toggleUrlBtn">Detail URL ▼</button>` : ""}
      </div>
      <div class="full-url" id="fullUrlBox">${escapeHtml(current.blockedUrl)}</div>
      <div class="actions">
        ${g.hudShowTrust !== false ? `<button class="btn btn-trust" id="btnTrust">✓ Trust</button>` : ""}
        ${g.hudShowGroup !== false ? `<button class="btn btn-group" id="btnGroup">⊞ Tab Grup</button>` : ""}
        ${g.hudShowOpen !== false ? `<button class="btn btn-open" id="btnOpen">↗ Buka</button>` : ""}
        ${g.hudShowBlock !== false ? `<button class="btn btn-block" id="btnBlock">🚫 Blokir</button>` : ""}
      </div>
    </div>
  `;
    const advanceQueue = () => {
      runtimeState.manualPromptQueue.shift();
      renderTopManualHUD();
    };
    const dismissBtn = shadow.getElementById("dismissBtn");
    if (dismissBtn) dismissBtn.addEventListener("click", advanceQueue);
    const toggleUrlBtn = shadow.getElementById("toggleUrlBtn");
    const fullUrlBox = shadow.getElementById("fullUrlBox");
    if (toggleUrlBtn && fullUrlBox) {
      toggleUrlBtn.addEventListener("click", () => {
        const open = fullUrlBox.classList.toggle("open");
        toggleUrlBtn.textContent = open ? "Sembunyikan ▲" : "Detail URL ▼";
      });
    }
    const btnTrust = shadow.getElementById("btnTrust");
    if (btnTrust) {
      btnTrust.addEventListener("click", () => {
        addDomainToWhitelist(current.blockedUrl, () => {
          chrome.runtime.sendMessage({ type: "NAVIGATE_CURRENT_TAB", url: current.blockedUrl });
        });
        advanceQueue();
      });
    }
    const btnGroup = shadow.getElementById("btnGroup");
    if (btnGroup) {
      btnGroup.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "OPEN_GROUP_TAB", url: current.blockedUrl });
        advanceQueue();
      });
    }
    const btnOpen = shadow.getElementById("btnOpen");
    if (btnOpen) {
      btnOpen.addEventListener("click", () => {
        chrome.runtime.sendMessage({ type: "NAVIGATE_CURRENT_TAB", url: current.blockedUrl });
        advanceQueue();
      });
    }
    const btnBlock = shadow.getElementById("btnBlock");
    if (btnBlock) {
      btnBlock.addEventListener("click", () => {
        addDomainToBlacklist(current.blockedUrl, () => {
          purgeBlacklistedOrTrustedPrompts();
          renderTopManualHUD();
        });
      });
    }
    const dragHead = shadow.getElementById("dragHead");
    if (dragHead) {
      let dragging = false;
      let startX = 0;
      let startY = 0;
      let initLeft = 0;
      let initTop = 0;
      dragHead.addEventListener("pointerdown", (e) => {
        if (
          /** @type {HTMLElement} */
          e.target.closest("button")
        ) return;
        dragging = true;
        const rect = hostEl.getBoundingClientRect();
        startX = e.clientX;
        startY = e.clientY;
        initLeft = rect.left;
        initTop = rect.top;
        hostEl.style.left = `${initLeft}px`;
        hostEl.style.top = `${initTop}px`;
        hostEl.style.right = "auto";
        hostEl.style.bottom = "auto";
        hostEl.style.transformOrigin = "top left";
        hostEl.style.transform = `scale(${hudScale})`;
        safeTry("hud.setPointerCapture", () => dragHead.setPointerCapture(e.pointerId));
      });
      dragHead.addEventListener("pointermove", (e) => {
        if (!dragging) return;
        const rect = hostEl.getBoundingClientRect();
        const clamped = clampHudPosition(
          initLeft + (e.clientX - startX),
          initTop + (e.clientY - startY),
          rect.width,
          rect.height,
          8
        );
        hostEl.style.left = `${clamped.left}px`;
        hostEl.style.top = `${clamped.top}px`;
      });
      const endDrag = (e) => {
        if (!dragging) return;
        dragging = false;
        safeTry("hud.releasePointerCapture", () => {
          if (dragHead.hasPointerCapture(e.pointerId)) dragHead.releasePointerCapture(e.pointerId);
        });
        const rect = hostEl.getBoundingClientRect();
        const savedCoord = createSavedHudCoord(rect.left, rect.top, rect.width, rect.height, 8);
        saveHudPosition("topHud", savedCoord);
      };
      dragHead.addEventListener("pointerup", endDrag);
      dragHead.addEventListener("pointercancel", endDrag);
    }
    clearTimeout(topHudHideTimer);
    if (hudDurationSec > 0) {
      topHudHideTimer = setTimeout(() => {
        runtimeState.manualPromptQueue = [];
        const el = document.getElementById(TOP_HUD_ID);
        if (el) el.remove();
      }, hudDurationSec * 1e3);
    }
  }
  function showShortlinkBypassToast(targetUrl, method) {
    if (window !== window.top) return;
    safeTry("hud.showBypassToast", () => {
      const prev = document.getElementById(TOAST_ID);
      if (prev) prev.remove();
      const hostEl = document.createElement("div");
      hostEl.id = TOAST_ID;
      hostEl.style.cssText = "position:fixed;bottom:18px;right:18px;z-index:2147483647;pointer-events:none;";
      const targetHost = getHostname(targetUrl) || targetUrl.slice(0, 48);
      const shadow = hostEl.attachShadow({ mode: "closed" });
      shadow.innerHTML = `
      <style>
        .toast {
          display: flex; align-items: center; gap: 10px;
          background: rgba(15, 23, 42, 0.96);
          border: 1px solid rgba(52, 211, 153, 0.55);
          border-radius: 12px;
          padding: 10px 14px;
          box-shadow: 0 12px 30px rgba(0, 0, 0, 0.5);
          backdrop-filter: blur(8px);
          font-family: system-ui, -apple-system, sans-serif;
          max-width: 340px;
        }
        .icon { width: 28px; height: 28px; border-radius: 8px; background: rgba(16,185,129,0.2); border: 1px solid rgba(52,211,153,0.4); display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
        .body { min-width: 0; }
        .title { font-size: 12px; font-weight: 800; color: #6ee7b7; line-height: 1.25; }
        .sub { font-size: 10.5px; font-family: ui-monospace, monospace; color: #cbd5e1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-top: 2px; }
      </style>
      <div class="toast">
        <div class="icon">⚡</div>
        <div class="body">
          <div class="title">⚡ AEGIS Bypass: Melompati Safelink...</div>
          <div class="sub">→ ${escapeHtml(targetHost)} (${escapeHtml(method || "DIRECT")})</div>
        </div>
      </div>
    `;
      (document.documentElement || document.body).appendChild(hostEl);
      setTimeout(() => {
        safeTry("hud.removeToast", () => hostEl.remove());
      }, TIMINGS.BYPASS_TOAST_MAX_WAIT_MS + 400);
    });
  }

  // src/ext/shared/captcha-guard.js
  var CAPTCHA_DOM_SELECTORS = [
    "iframe[src*='recaptcha']",
    "iframe[src*='hcaptcha']",
    "iframe[src*='challenges.cloudflare.com']",
    "iframe[src*='turnstile']",
    "iframe[src*='arkoselabs']",
    "iframe[src*='funcaptcha']",
    "iframe[src*='captcha-delivery.com']",
    "script[src*='/cdn-cgi/challenge-platform/']",
    ".g-recaptcha",
    ".h-captcha",
    ".cf-turnstile",
    "#cf-turnstile",
    "#px-captcha",
    "[data-sitekey]",
    "[data-hcaptcha-widget-id]",
    "[name='cf-turnstile-response']"
  ].join(", ");
  function isCaptchaChallengeUrl(urlStr) {
    if (!urlStr || typeof urlStr !== "string") return false;
    try {
      const u = new URL(urlStr);
      if (u.protocol !== "http:" && u.protocol !== "https:") return false;
      const host = u.hostname.toLowerCase();
      if (CHALLENGE_HOST_REGEX.test(host)) return true;
      const pathAndQuery = u.pathname + u.search;
      if (pathAndQuery.includes("/cdn-cgi/challenge-platform/") || pathAndQuery.includes("__cf_chl_tk=") || pathAndQuery.includes("__cf_chl_rt_tk=") || pathAndQuery.includes("__cf_chl_f_tk=")) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
  function hasVisibleCaptchaInDocument(doc) {
    if (!doc) return false;
    try {
      if (doc.location && isCaptchaChallengeUrl(doc.location.href)) return true;
      if (typeof window !== "undefined" && /** @type {any} */
      window._cf_chl_opt) return true;
      const widgets = doc.querySelectorAll(CAPTCHA_DOM_SELECTORS);
      for (const el of widgets) {
        if (el.tagName === "SCRIPT") return true;
        if (el.tagName === "INPUT" && el.getAttribute("name") === "cf-turnstile-response") {
          const val = (
            /** @type {HTMLInputElement} */
            el.value || ""
          );
          if (!val.trim()) return true;
          continue;
        }
        const rect = typeof el.getBoundingClientRect === "function" ? el.getBoundingClientRect() : null;
        if (!rect || rect.width < 10 && rect.height < 10) continue;
        const textarea = el.querySelector && el.querySelector(
          "textarea[name='g-recaptcha-response'], textarea[name='h-captcha-response'], input[name='cf-turnstile-response']"
        );
        if (textarea && /** @type {HTMLTextAreaElement} */
        textarea.value && /** @type {HTMLTextAreaElement} */
        textarea.value.trim().length > 10) {
          continue;
        }
        return true;
      }
    } catch {
      return false;
    }
    return false;
  }

  // src/ext/content/shortlink-bypass.js
  var earlyBypassExecuted = false;
  var lastAutoStepTs = 0;
  function isShortlinkBypassAllowedHere() {
    if (window !== window.top) return false;
    if (runtimeState.globalSettings.shortlinkBypassEnabled === false) return false;
    if (isTempAllowActiveHere()) return false;
    if (runtimeState.captchaDetected || isCaptchaChallengeUrl(location.href)) return false;
    const host = (location.hostname || "").toLowerCase();
    if (!host || isSameSafeEcosystem(host, host) || isUrlInTrustedList(location.href)) return false;
    return true;
  }
  function checkAndBroadcastCaptchaStatus() {
    if (hasVisibleCaptchaInDocument(document)) {
      if (!runtimeState.captchaDetected) {
        signalCaptchaToMainWorld(true);
        logAegisEvent(
          "ALLOW",
          "BYPASS_WAIT_CAPTCHA",
          location.href,
          "CAPTCHA/Turnstile terdeteksi -> auto-click & percepatan timer dihentikan dengan aman"
        );
      }
      return true;
    }
    return false;
  }
  function signalShortlinkCtaClick(hrefUrl) {
    signalShortlinkCtaToMainWorld();
    safeTry("shortlink.signalCtaClick", () => {
      chrome.runtime.sendMessage({
        type: "USER_CLICKED_SHORTLINK_CTA",
        sourceUrl: location.href,
        href: hrefUrl ? String(hrefUrl) : ""
      });
    });
  }
  function extractDirectShortlinkUrlFromPage() {
    const hiddenValues = [];
    safeTry("shortlink.readHiddenInputs", () => {
      document.querySelectorAll(
        "input[name='newwpsafelink'], input[name='go'], input[name='linkr'], input[name='url'], input[name='data'], input[type='hidden'][value]"
      ).forEach((inp) => {
        const val = (
          /** @type {HTMLInputElement} */
          inp.value || inp.getAttribute("value") || ""
        );
        if (val && val.length >= 8 && val.length <= 2400) hiddenValues.push(val);
      });
    });
    const metaEl = document.querySelector("meta[http-equiv='refresh' i][content]");
    const metaRefreshContent = metaEl ? metaEl.getAttribute("content") || "" : "";
    return extractDirectShortlinkFromInputs({
      pageUrl: location.href,
      hiddenValues,
      metaRefreshContent,
      deniedList: runtimeState.deniedDomains
    });
  }
  function tryEarlyDirectShortlinkBypass() {
    if (earlyBypassExecuted || !isShortlinkBypassAllowedHere()) return false;
    if (checkAndBroadcastCaptchaStatus()) return false;
    const extracted = extractDirectShortlinkUrlFromPage();
    if (!extracted.found || !extracted.url) return false;
    earlyBypassExecuted = true;
    runtimeState.shortlinkBypassActionTaken = true;
    showShortlinkBypassToast(extracted.url, extracted.method);
    logAegisEvent(
      "BYPASS",
      `BYPASS_${extracted.method}`,
      extracted.url,
      `Bypass Shortlink Debloated melompati safelink langsung (${extracted.method})`
    );
    const startTs = Date.now();
    let redirected = false;
    const performReplace = () => {
      if (redirected) return;
      redirected = true;
      safeTry("shortlink.locationReplace", () => {
        location.replace(extracted.url);
      });
    };
    const safetyTimer = setTimeout(performReplace, TIMINGS.BYPASS_TOAST_MAX_WAIT_MS);
    safeTry(
      "shortlink.allowBypassNavMsg",
      () => {
        chrome.runtime.sendMessage(
          {
            type: "ALLOW_SHORTLINK_BYPASS_NAV",
            url: extracted.url,
            sourceUrl: location.href,
            method: extracted.method
          },
          (res) => {
            if (res && res.ok === false) {
              clearTimeout(safetyTimer);
              redirected = true;
              return;
            }
            const remaining = Math.max(0, TIMINGS.BYPASS_TOAST_MS - (Date.now() - startTs));
            setTimeout(() => {
              clearTimeout(safetyTimer);
              performReplace();
            }, remaining);
          }
        );
      },
      void 0
    );
    return true;
  }
  function runShortlinkDebloatedBypassStep() {
    if (!isShortlinkBypassAllowedHere()) return false;
    if (runtimeState.globalSettings.shortlinkAutoClick === false) return false;
    if (checkAndBroadcastCaptchaStatus()) return false;
    const now = Date.now();
    if (now - lastAutoStepTs < 1200) return false;
    let actionTaken = false;
    safeTry("shortlink.autoStep", () => {
      const goForm = (
        /** @type {HTMLFormElement | null} */
        document.querySelector("form#go-link, form[action*='/links/go']")
      );
      if (goForm && goForm.dataset.aegisSubmitted !== "1") {
        const submitBtn = (
          /** @type {HTMLButtonElement | null} */
          goForm.querySelector("button[type='submit'], input[type='submit'], a.get-link")
        );
        const isDisabled = submitBtn && (submitBtn.disabled || submitBtn.classList.contains("disabled") || submitBtn.getAttribute("aria-disabled") === "true");
        if (!isDisabled) {
          goForm.dataset.aegisSubmitted = "1";
          lastAutoStepTs = now;
          runtimeState.shortlinkBypassActionTaken = true;
          actionTaken = true;
          signalShortlinkCtaClick(goForm.action || location.href);
          logAegisEvent(
            "BYPASS",
            "BYPASS_ADLINKFLY_FORM",
            goForm.action || location.href,
            "Auto-submit form AdLinkFly (form#go-link)"
          );
          if (submitBtn) submitBtn.click();
          else goForm.submit();
          return;
        }
      }
      const ctaCandidates = document.querySelectorAll(
        "a#babay, a.get-link, a#wpsafe-link, a.btn-download, a[href*='download='], a[href*='&t='], button.get-link"
      );
      const bodySnippet = document.body ? (document.body.innerText || "").slice(0, 500) : "";
      for (const node of ctaCandidates) {
        const el = (
          /** @type {HTMLElement} */
          node
        );
        if (el.dataset.aegisAutoClicked === "1") continue;
        if (el.offsetParent === null) continue;
        const isDisabled = (
          /** @type {HTMLButtonElement} */
          el.disabled || el.classList.contains("disabled") || el.getAttribute("aria-disabled") === "true"
        );
        if (isDisabled) continue;
        const rawHref = el.getAttribute("href") || "";
        if (isShortlinkCtaCandidate({
          rawHref,
          text: el.innerText || el.textContent || "",
          id: el.id || "",
          className: typeof el.className === "string" ? el.className : "",
          cardText: bodySnippet
        })) {
          el.dataset.aegisAutoClicked = "1";
          lastAutoStepTs = now;
          runtimeState.shortlinkBypassActionTaken = true;
          actionTaken = true;
          signalShortlinkCtaClick(rawHref || location.href);
          logAegisEvent(
            "BYPASS",
            "BYPASS_AUTO_CLICK_CTA",
            rawHref || location.href,
            `Auto-klik tombol CTA shortlink (${(el.innerText || el.id || "CTA").trim().slice(0, 40)})`
          );
          el.click();
          return;
        }
      }
    });
    return actionTaken;
  }

  // src/ext/content/click-guard.js
  function hasDisguisedAdCssClass(el) {
    let cur = el;
    for (let depth = 0; cur && depth < 4; depth++) {
      const sig = `${cur.id || ""} ${typeof cur.className === "string" ? cur.className : ""}`;
      if (DISGUISED_AD_CLASS_REGEX.test(sig)) return true;
      cur = cur.parentElement;
    }
    return false;
  }
  function isRealAdSlotContainer(el) {
    let cur = el;
    for (let depth = 0; cur && depth < 6; depth++) {
      const sig = `${cur.id || ""} ${typeof cur.className === "string" ? cur.className : ""}`;
      if (AD_SLOT_CLASS_ID_REGEX.test(sig)) return true;
      cur = cur.parentElement;
    }
    return false;
  }
  function isInsideUserPostContent(el) {
    if (!el || !el.closest) return false;
    return Boolean(
      el.closest(
        ".bbWrapper, .message-body, .message-content, article, .post-content, .entry-content, .comment-body, .thread-content, [data-testid='post-container']"
      )
    );
  }
  function classifyContentLinkOrImage(anchorEl, rawHref) {
    if (!rawHref) return { action: "allow", resolvedUrl: "", reason: "empty_href" };
    let resolved;
    try {
      resolved = new URL(rawHref, location.href);
    } catch {
      return { action: "allow", resolvedUrl: rawHref, reason: "invalid_url" };
    }
    if (!resolved.protocol.startsWith("http")) {
      return { action: "allow", resolvedUrl: resolved.href, reason: "non_http" };
    }
    const destUrl = resolved.href;
    const curHost = location.hostname.toLowerCase();
    const destHost = resolved.hostname.toLowerCase();
    if (isUrlInDeniedList(destUrl)) {
      return { action: "silent_block", resolvedUrl: destUrl, reason: "Domain Blacklist diblokir senyap" };
    }
    if (isTempAllowActiveHere() || isUrlInTrustedList(destUrl) || getBaseDomain(destHost) === getBaseDomain(curHost) || isSameSafeEcosystem(curHost, destHost) || isAuthFlowUrl(destUrl)) {
      return { action: "allow", resolvedUrl: destUrl, reason: "trusted_or_same_domain" };
    }
    const disguisedAd = hasDisguisedAdCssClass(anchorEl);
    const inAdSlot = isRealAdSlotContainer(anchorEl);
    const hardMalicious = isHardMaliciousUrl(destUrl, runtimeState.deniedDomains);
    if (hardMalicious || disguisedAd || inAdSlot) {
      return {
        action: "hold_hud",
        resolvedUrl: destUrl,
        reason: disguisedAd ? "Elemen iklan terselubung (CSS/shortener) ditahan" : "Tautan iklan/affiliate/judol ditahan"
      };
    }
    if (runtimeState.globalSettings.smartUgcSense !== false && SAFE_MEDIA_HOST_REGEX.test(destHost)) {
      return { action: "allow", resolvedUrl: destUrl, reason: "safe_ugc_media_host" };
    }
    if (SUSPICIOUS_TLD.test(destHost)) {
      const insideUgc = isInsideUserPostContent(anchorEl);
      return {
        action: "hold_hud",
        resolvedUrl: destUrl,
        reason: insideUgc ? "Konten eksternal (.click/.top) ditahan — Pilih ↗ Buka jika aman" : "Domain TLD mencurigakan ditahan"
      };
    }
    const isStrict = runtimeState.globalSettings.protectionMode === "strict" || runtimeState.globalSettings.protectionMode !== "balanced" && runtimeState.strictCrossOrigin;
    if (isStrict) {
      return {
        action: "hold_hud",
        resolvedUrl: destUrl,
        reason: "Lintas-domain (Mode Strict) ditahan"
      };
    }
    return { action: "allow", resolvedUrl: destUrl, reason: "balanced_user_click_allowed" };
  }
  function isEmptyFullscreenTrapOverlay(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.id === "aegis-top-manual-hud" || el.id === "aegis-video-bottom-dock" || el.id === "aegis-bypass-toast-host") {
      return false;
    }
    const role = (el.getAttribute("role") || "").toLowerCase();
    if (role === "dialog" || role === "alertdialog" || el.getAttribute("aria-modal") === "true") {
      return false;
    }
    if ((el.innerText || "").trim().length > 0) return false;
    if (el.querySelector("a, button, input, select, textarea, video, iframe, canvas, form")) {
      return false;
    }
    const style = window.getComputedStyle(el);
    if (!style || style.display === "none" || style.visibility === "hidden" || style.pointerEvents === "none") {
      return false;
    }
    if (style.position !== "fixed" && style.position !== "absolute") return false;
    const rect = el.getBoundingClientRect();
    const vw = Math.max(window.innerWidth || 1, 1);
    const vh = Math.max(window.innerHeight || 1, 1);
    if (rect.width / vw < 0.72 || rect.height / vh < 0.65) return false;
    const bg = (style.backgroundColor || "").toLowerCase();
    const opacity = Number(style.opacity);
    const isTransparentLike = opacity <= 0.15 || bg === "transparent" || bg === "rgba(0, 0, 0, 0)" || el.id.toLowerCase() === "overlay";
    return isTransparentLike;
  }
  function neutralizeEmptyTrapOverlays() {
    if (runtimeState.globalSettings.removeTransparentOverlay === false || runtimeState.captchaDetected || isTempAllowActiveHere() || isUrlInTrustedList(location.href)) {
      return;
    }
    safeTry("clickGuard.neutralizeOverlays", () => {
      const candidates = document.querySelectorAll(
        "div#overlay, div[class*='overlay'], div[id*='overlay'], div[style*='position: fixed'], div[style*='position:fixed']"
      );
      candidates.forEach((node) => {
        const el = (
          /** @type {HTMLElement} */
          node
        );
        if (isEmptyFullscreenTrapOverlay(el)) {
          el.style.pointerEvents = "none";
          el.style.display = "none";
          logAegisEvent(
            "BYPASS",
            "BYPASS_TRAP_OVERLAY",
            location.href,
            `Overlay jebakan transparan (${el.id || el.className || "div"}) dinonaktifkan`
          );
        }
      });
    });
  }
  function attachClickGuardListener() {
    document.addEventListener(
      "click",
      (ev) => {
        safeTry("clickGuard.onClick", () => {
          if (!ev.isTrusted) return;
          const target = (
            /** @type {HTMLElement | null} */
            ev.target
          );
          if (!target || !target.closest) return;
          const anchor = (
            /** @type {HTMLAnchorElement | null} */
            target.closest("a[href]")
          );
          if (!anchor) return;
          const rawHref = anchor.getAttribute("href") || "";
          if (!rawHref || rawHref.startsWith("#") || rawHref.startsWith("javascript:")) return;
          const resolvedHost = getHostname(rawHref, location.href);
          if (resolvedHost && getBaseDomain(resolvedHost) === getBaseDomain(location.hostname)) {
            const cardText = anchor.closest(".card, main, section, body")?.textContent?.slice(0, 400) || "";
            if (isShortlinkCtaCandidate({
              rawHref,
              text: anchor.innerText || anchor.textContent || "",
              id: anchor.id || "",
              className: typeof anchor.className === "string" ? anchor.className : "",
              cardText
            })) {
              signalShortlinkCtaClick(rawHref);
              return;
            }
          }
          const verdict = classifyContentLinkOrImage(anchor, rawHref);
          if (verdict.action === "allow") {
            chrome.runtime.sendMessage({ type: "ALLOW_USER_CONTENT_NAVIGATION", url: verdict.resolvedUrl });
            return;
          }
          ev.preventDefault();
          ev.stopPropagation();
          if (verdict.action === "silent_block") {
            logAegisEvent("BLOCK", "CLICK_BLACKLIST_SILENT", verdict.resolvedUrl, verdict.reason);
            return;
          }
          logAegisEvent("BLOCK", "CLICK_HOLD_HUD", verdict.resolvedUrl, verdict.reason);
          enqueueManualPrompt({
            blockedUrl: verdict.resolvedUrl,
            message: verdict.reason,
            kind: anchor.target === "_blank" ? "popup" : "redirect"
          });
        });
      },
      true
    );
  }

  // src/ext/shared/gemini-audit.js
  var BENIGN_NAV_TEXT = /^(home|beranda|about|tentang|contact|kontak|privacy|terms|faq|login|register|search|cari|menu|back)$/i;
  var REAL_CTA_HINT = /(download|unduh|get\s*link|go\s*to\s*link|continue|lanjut|verify|proceed|open\s*link|watch|stream)/i;
  function pruneDomCandidatesForAudit(rawCandidates, maxItems = 18) {
    if (!Array.isArray(rawCandidates) || rawCandidates.length === 0) {
      return { pruned: [], localBlockedIndices: [], needsGeminiCall: false };
    }
    const scored = [];
    const localBlockedIndices = [];
    for (const item of rawCandidates) {
      const text = String(item.text || "").replace(/\s+/g, " ").trim().slice(0, 60);
      const href = String(item.href || "").trim().slice(0, 120);
      const cls = `${item.id || ""} ${item.cls || ""}`.replace(/\s+/g, " ").trim().slice(0, 48);
      if (!text && !href) continue;
      if (BENIGN_NAV_TEXT.test(text) && !GAMBLING_KEYWORDS.test(href)) continue;
      if (GAMBLING_KEYWORDS.test(href + " " + text) || COMMERCE_AFFILIATE_REGEX.test(href)) {
        localBlockedIndices.push(item.index);
        continue;
      }
      let score = 0;
      if (REAL_CTA_HINT.test(text)) score += 3;
      if (SUSPICIOUS_TLD.test(href)) score += 2;
      if (/[?&](download|go|token|t|id|link)=/i.test(href)) score += 2;
      if (text.length >= 3 && text.length <= 36) score += 1;
      scored.push({
        i: item.index,
        t: text,
        h: href,
        c: cls,
        score
      });
    }
    scored.sort((a, b) => b.score - a.score);
    const top = scored.slice(0, maxItems).map(({ i, t, h, c }) => ({ i, t, h, c }));
    const ctaLikeCount = scored.filter((s) => s.score >= 3).length;
    const needsGeminiCall = top.length >= 2 && ctaLikeCount >= 1;
    return {
      pruned: top,
      localBlockedIndices,
      needsGeminiCall
    };
  }

  // src/ext/content/dom-audit.js
  var auditAlreadyRan = false;
  function runAiDomAuditFallback() {
    if (auditAlreadyRan || window !== window.top) return;
    if (runtimeState.captchaDetected || isTempAllowActiveHere() || isUrlInTrustedList(location.href)) {
      return;
    }
    if (runtimeState.globalSettings.shortlinkAutoClick !== false && runtimeState.shortlinkBypassActionTaken) {
      return;
    }
    auditAlreadyRan = true;
    safeTry("domAudit.collectAndAnalyze", () => {
      const els = Array.from(document.querySelectorAll("a[href], button")).slice(0, 60);
      const rawCandidates = els.map((el, index) => {
        const htmlEl = (
          /** @type {HTMLElement} */
          el
        );
        if (htmlEl.offsetParent === null) return null;
        return {
          index,
          tag: el.tagName.toLowerCase(),
          text: (htmlEl.innerText || htmlEl.textContent || "").trim(),
          href: el.getAttribute("href") || "",
          id: el.id || "",
          cls: typeof htmlEl.className === "string" ? htmlEl.className : ""
        };
      }).filter(Boolean);
      const { pruned, localBlockedIndices, needsGeminiCall } = pruneDomCandidatesForAudit(
        /** @type {any[]} */
        rawCandidates,
        18
      );
      for (const idx of localBlockedIndices) {
        const badEl = (
          /** @type {HTMLElement | undefined} */
          els[idx]
        );
        if (badEl) {
          badEl.style.pointerEvents = "none";
          badEl.style.opacity = "0.25";
        }
      }
      if (!needsGeminiCall || pruned.length === 0) return;
      chrome.runtime.sendMessage(
        {
          type: "ANALYZE_CANDIDATES",
          payload: {
            title: document.title || "",
            pageUrl: location.href,
            candidates: pruned
          }
        },
        (res) => {
          if (!res || !res.success || !res.data) return;
          const { realIndex, blockedIndices } = res.data;
          if (Array.isArray(blockedIndices)) {
            blockedIndices.forEach((idx) => {
              const badEl = (
                /** @type {HTMLElement | undefined} */
                els[idx]
              );
              if (badEl) {
                badEl.style.pointerEvents = "none";
                badEl.style.opacity = "0.25";
              }
            });
          }
          if (typeof realIndex === "number" && realIndex >= 0 && els[realIndex]) {
            const realEl = (
              /** @type {HTMLElement} */
              els[realIndex]
            );
            realEl.style.outline = "2px solid #10b981";
            realEl.style.outlineOffset = "2px";
            logAegisEvent(
              "BYPASS",
              "AI_DOM_AUDIT_HIGHLIGHT",
              realEl.getAttribute("href") || location.href,
              `AI DOM Audit v2 menandai tombol tujuan asli (index=${realIndex}, pruned=${pruned.length})`
            );
          }
        }
      );
    });
  }

  // src/ext/content/video-dock.js
  var VIDEO_DOCK_ID = "aegis-video-bottom-dock";
  var MINI_PIP_BAR_ID = "aegis-mini-pip-drag-bar";
  var MINI_PIP_STYLE_ID = "aegis-mini-pip-style";
  var videoDimTimer = null;
  var lazyAutoSkipTimer = null;
  var lazyAutoSkipActive = false;
  function isVideoUrl(urlStr, isConfirmedMime = false) {
    if (!urlStr) return false;
    const s = String(urlStr).trim();
    if (s.startsWith("data:") || s.startsWith("blob:") || s.startsWith("javascript:")) return false;
    if (NON_VIDEO_ASSET_REGEX.test(s)) return false;
    return Boolean(isConfirmedMime || VIDEO_EXT_REGEX.test(s) || VIDEO_STREAM_HINT_REGEX.test(s));
  }
  function registerDetectedVideo(rawUrl, isConfirmedMime = false) {
    safeTry("videoDock.registerVideo", () => {
      if (!rawUrl) return;
      const abs = new URL(String(rawUrl), location.href).href;
      if (!abs.startsWith("http") || !isVideoUrl(abs, isConfirmedMime)) return;
      if (!runtimeState.detectedVideos.includes(abs)) {
        runtimeState.detectedVideos.unshift(abs);
        if (runtimeState.detectedVideos.length > 25) runtimeState.detectedVideos.pop();
        renderFloatingVideoDock();
        ensureLazyAutoSkipRunning();
      }
    });
  }
  function findPrimaryVideoElement() {
    const videos = Array.from(document.querySelectorAll("video"));
    if (videos.length === 0) return null;
    let best = videos[0];
    let bestArea = 0;
    for (const v of videos) {
      const r = v.getBoundingClientRect();
      const area = Math.max(0, r.width) * Math.max(0, r.height);
      if (area > bestArea) {
        bestArea = area;
        best = v;
      }
    }
    return best;
  }
  function scanDomForVideos() {
    safeTry("videoDock.scanDom", () => {
      const videos = document.querySelectorAll("video, video source");
      if (videos.length > 0) {
        ensureLazyAutoSkipRunning();
      }
      videos.forEach((node) => {
        const src = (
          /** @type {HTMLVideoElement} */
          node.currentSrc || node.getAttribute("src") || node.getAttribute("data-src")
        );
        if (src) registerDetectedVideo(src, false);
      });
      if (document.querySelector("video") && runtimeState.detectedVideos.length === 0) {
        runtimeState.detectedVideos.push(location.href);
        renderFloatingVideoDock();
      }
    });
  }
  function isVideoElementAnAd(v) {
    if (!v) return false;
    if (v.closest(
      ".ad-showing, .ad-interrupting, .ima-ad-container, .vast-ad, [class*='preroll'], [id*='preroll'], [class*='video-ad'], [id*='video-ad']"
    )) {
      return true;
    }
    const idCls = `${v.id || ""} ${typeof v.className === "string" ? v.className : ""}`.toLowerCase();
    const src = (v.currentSrc || v.src || "").toLowerCase();
    return /(preroll|vast|ima-ad|ad-video|doubleclick|googlesyndication)/i.test(idCls + " " + src);
  }
  function runIsolatedAutoSkip() {
    if (document.hidden || !runtimeState.autoSkipCountdown || runtimeState.captchaDetected || isTempAllowActiveHere() || isUrlInTrustedList(location.href)) {
      return;
    }
    safeTry("videoDock.autoSkip", () => {
      const videos = document.querySelectorAll("video");
      const skipBtns = document.querySelectorAll(
        ".ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .jw-skip, .vjs-skip-ad-button, [class*='skip-ad'], [class*='skipAd'], [id*='skip-ad'], [id*='skipAd']"
      );
      if (videos.length === 0 && skipBtns.length === 0) {
        stopLazyAutoSkip();
        return;
      }
      videos.forEach((v) => {
        if (isVideoElementAnAd(v) && v.duration && Number.isFinite(v.duration) && v.duration >= 4 && v.duration <= 36) {
          if (!v.ended && v.currentTime < v.duration - 0.25) {
            v.muted = true;
            const speed = String(runtimeState.globalSettings.adSkipSpeed || "16");
            if (speed === "instant") {
              v.currentTime = Math.max(0, v.duration - 0.1);
            } else {
              v.playbackRate = Number(speed) || 16;
              if (v.duration - v.currentTime > 1.5) {
                v.currentTime = Math.max(v.currentTime, v.duration - 1.2);
              }
            }
          }
        }
      });
      skipBtns.forEach((btn) => {
        const el = (
          /** @type {HTMLElement} */
          btn
        );
        if (el.dataset.aegisAutoClicked === "1") return;
        const txt = (el.innerText || el.textContent || el.getAttribute("aria-label") || "").trim();
        if (txt && txt.length > 35) return;
        el.dataset.aegisAutoClicked = "1";
        el.disabled = false;
        el.removeAttribute("disabled");
        el.click();
      });
    });
  }
  function ensureLazyAutoSkipRunning() {
    if (lazyAutoSkipActive || document.hidden) return;
    if (!document.querySelector("video")) return;
    lazyAutoSkipActive = true;
    lazyAutoSkipTimer = setInterval(runIsolatedAutoSkip, TIMINGS.AUTO_SKIP_INTERVAL_MS);
  }
  function stopLazyAutoSkip() {
    if (!lazyAutoSkipActive) return;
    lazyAutoSkipActive = false;
    clearInterval(lazyAutoSkipTimer);
    lazyAutoSkipTimer = null;
  }
  function ensureMiniPlayerStyle() {
    if (document.getElementById(MINI_PIP_STYLE_ID)) return;
    const st = document.createElement("style");
    st.id = MINI_PIP_STYLE_ID;
    st.textContent = `
    video.__aegis_mini_pip__ {
      position: fixed !important;
      z-index: 2147483645 !important;
      border-radius: 0 0 10px 10px !important;
      box-shadow: 0 14px 36px rgba(0,0,0,0.65) !important;
      border: 1px solid rgba(52,211,153,0.45) !important;
      background: #000 !important;
      object-fit: contain !important;
    }
  `;
    (document.head || document.documentElement).appendChild(st);
  }
  function getMiniPipDims() {
    const sz = runtimeState.globalSettings.pipSize || "medium";
    if (sz === "small") return { width: 220, height: 124 };
    if (sz === "large") return { width: 320, height: 180 };
    return { width: 260, height: 146 };
  }
  function disableMiniPlayer() {
    if (runtimeState.activeMiniVideoEl) {
      runtimeState.activeMiniVideoEl.classList.remove("__aegis_mini_pip__");
      runtimeState.activeMiniVideoEl.style.left = "";
      runtimeState.activeMiniVideoEl.style.top = "";
      runtimeState.activeMiniVideoEl.style.width = "";
      runtimeState.activeMiniVideoEl.style.height = "";
      runtimeState.activeMiniVideoEl.style.opacity = "";
      runtimeState.activeMiniVideoEl = null;
    }
    runtimeState.miniPlayerActive = false;
    const bar = document.getElementById(MINI_PIP_BAR_ID);
    if (bar) bar.remove();
  }
  function applySavedMiniPipPosition() {
    const v = runtimeState.activeMiniVideoEl;
    if (!v || !runtimeState.miniPlayerActive) return;
    const dims = getMiniPipDims();
    const safeTop = getMiniPlayerSafeTop();
    const saved = runtimeState.hudPositions.miniPip;
    const resolved = saved ? resolveSavedHudCoord(saved, dims.width, dims.height, 8, safeTop) : clampHudPosition(window.innerWidth - dims.width - 16, window.innerHeight - dims.height - 68, dims.width, dims.height, 8, safeTop);
    const left = resolved ? resolved.left : 16;
    const top = resolved ? resolved.top : safeTop;
    const pipOpacity = Math.max(0.5, Math.min(1, Number(runtimeState.globalSettings.pipOpacity ?? 0.95)));
    v.style.width = `${dims.width}px`;
    v.style.height = `${dims.height}px`;
    v.style.left = `${left}px`;
    v.style.top = `${top}px`;
    v.style.opacity = String(pipOpacity);
    const bar = document.getElementById(MINI_PIP_BAR_ID);
    if (bar) {
      bar.style.width = `${dims.width}px`;
      bar.style.left = `${left}px`;
      bar.style.top = `${Math.max(2, top - 24)}px`;
      bar.style.opacity = String(pipOpacity);
    }
  }
  function renderMiniPlayerDragBar(videoEl) {
    const prev = document.getElementById(MINI_PIP_BAR_ID);
    if (prev) prev.remove();
    const bar = document.createElement("div");
    bar.id = MINI_PIP_BAR_ID;
    bar.style.cssText = "position:fixed;z-index:2147483646;height:24px;display:flex;align-items:center;justify-content:space-between;padding:0 8px;background:rgba(15,23,42,0.96);border:1px solid rgba(52,211,153,0.45);border-bottom:none;border-radius:10px 10px 0 0;color:#e2e8f0;font:700 10.5px system-ui,sans-serif;cursor:grab;user-select:none;touch-action:none;";
    bar.innerHTML = `<span>⠿ Mini PiP</span><button id="aegisPipClose" style="background:#1e293b;color:#f87171;border:none;border-radius:4px;padding:1px 6px;font-weight:700;cursor:pointer;">✕</button>`;
    (document.documentElement || document.body).appendChild(bar);
    const closeBtn = bar.querySelector("#aegisPipClose");
    if (closeBtn) closeBtn.addEventListener("click", disableMiniPlayer);
    let dragging = false;
    let startX = 0;
    let startY = 0;
    let initLeft = 0;
    let initTop = 0;
    bar.addEventListener("pointerdown", (e) => {
      if (
        /** @type {HTMLElement} */
        e.target.closest("button")
      ) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = videoEl.getBoundingClientRect();
      initLeft = rect.left;
      initTop = rect.top;
      safeTry("videoDock.pipCapture", () => bar.setPointerCapture(e.pointerId));
    });
    bar.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dims = getMiniPipDims();
      const clamped = clampHudPosition(
        initLeft + (e.clientX - startX),
        initTop + (e.clientY - startY),
        dims.width,
        dims.height,
        8,
        getMiniPlayerSafeTop()
      );
      videoEl.style.left = `${clamped.left}px`;
      videoEl.style.top = `${clamped.top}px`;
      bar.style.left = `${clamped.left}px`;
      bar.style.top = `${Math.max(2, clamped.top - 24)}px`;
    });
    const endDrag = (e) => {
      if (!dragging) return;
      dragging = false;
      safeTry("videoDock.pipRelease", () => {
        if (bar.hasPointerCapture(e.pointerId)) bar.releasePointerCapture(e.pointerId);
      });
      const dims = getMiniPipDims();
      const rect = videoEl.getBoundingClientRect();
      saveHudPosition(
        "miniPip",
        createSavedHudCoord(rect.left, rect.top, dims.width, dims.height, 8, getMiniPlayerSafeTop())
      );
    };
    bar.addEventListener("pointerup", endDrag);
    bar.addEventListener("pointercancel", endDrag);
  }
  async function toggleSmartMinimizeOrPiP() {
    const v = findPrimaryVideoElement();
    if (!v) return;
    if (runtimeState.miniPlayerActive) {
      disableMiniPlayer();
      return;
    }
    ensureMiniPlayerStyle();
    runtimeState.activeMiniVideoEl = v;
    runtimeState.miniPlayerActive = true;
    v.classList.add("__aegis_mini_pip__");
    renderMiniPlayerDragBar(v);
    applySavedMiniPipPosition();
  }
  function scheduleVideoDockDim() {
    clearTimeout(videoDimTimer);
    const dimSec = Math.max(0, Math.min(10, Number(runtimeState.globalSettings.videoDockDimSec ?? 2.5)));
    if (dimSec <= 0 || runtimeState.videoDrawerOpen) return;
    videoDimTimer = setTimeout(() => {
      runtimeState.videoDockDimmed = true;
      renderFloatingVideoDock();
    }, dimSec * 1e3);
  }
  function updateFloatingVideoDockPosition() {
    const host = document.getElementById(VIDEO_DOCK_ID);
    if (!host) return;
    const g = runtimeState.globalSettings;
    const scale = Math.max(0.75, Math.min(1.35, Number(g.videoPillScale) || 1));
    const opacity = Math.max(0.5, Math.min(1, Number(g.videoPillOpacity ?? g.hudOpacity) || 0.95));
    const dir = getEffectiveVideoDockDir();
    const rect = host.getBoundingClientRect();
    const saved = runtimeState.hudPositions.videoDock;
    host.style.opacity = String(opacity);
    host.style.transform = `scale(${scale})`;
    if (saved) {
      const resolved = resolveSavedHudCoord(saved, rect.width || 68, rect.height || 40, 4);
      if (resolved) {
        const nearTop = resolved.top < 180;
        host.style.transformOrigin = `${nearTop ? "top" : "bottom"} ${dir === "ltr" ? "left" : "right"}`;
        if (dir === "rtl") {
          host.style.right = `${resolved.right}px`;
          host.style.left = "auto";
        } else {
          host.style.left = `${resolved.left}px`;
          host.style.right = "auto";
        }
        host.style.top = `${resolved.top}px`;
        host.style.bottom = "auto";
        return;
      }
    }
    host.style.transformOrigin = `bottom ${dir === "ltr" ? "left" : "right"}`;
    host.style.bottom = "14px";
    host.style.top = "auto";
    if (dir === "ltr") {
      host.style.left = "8px";
      host.style.right = "auto";
    } else {
      host.style.right = "8px";
      host.style.left = "auto";
    }
  }
  function attachVideoDockDrag(handleEl, hostEl) {
    let dragging = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let initLeft = 0;
    let initTop = 0;
    let downOnBadge = false;
    handleEl.addEventListener("pointerdown", (e) => {
      const target = (
        /** @type {HTMLElement} */
        e.target
      );
      downOnBadge = Boolean(target.closest("#dimCompactBadge"));
      if (!downOnBadge && target.closest("button")) return;
      dragging = true;
      moved = false;
      startX = e.clientX;
      startY = e.clientY;
      const rect = hostEl.getBoundingClientRect();
      initLeft = rect.left;
      initTop = rect.top;
      safeTry("videoDock.setPointerCapture", () => handleEl.setPointerCapture(e.pointerId));
    });
    handleEl.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (!moved && Math.hypot(dx, dy) >= 5) moved = true;
      if (!moved) return;
      const rect = hostEl.getBoundingClientRect();
      const clamped = clampHudPosition(initLeft + dx, initTop + dy, rect.width, rect.height, 4);
      hostEl.style.left = `${clamped.left}px`;
      hostEl.style.right = "auto";
      hostEl.style.top = `${clamped.top}px`;
      hostEl.style.bottom = "auto";
    });
    const endDrag = (e) => {
      if (!dragging) return;
      dragging = false;
      safeTry("videoDock.releasePointerCapture", () => {
        if (handleEl.hasPointerCapture(e.pointerId)) handleEl.releasePointerCapture(e.pointerId);
      });
      if (moved) {
        const rect = hostEl.getBoundingClientRect();
        const saved = createSavedHudCoord(rect.left, rect.top, rect.width, rect.height, 4);
        saveHudPosition("videoDock", saved);
        updateFloatingVideoDockPosition();
      } else if (downOnBadge) {
        runtimeState.videoDrawerOpen = false;
        runtimeState.videoDockDimmed = !runtimeState.videoDockDimmed;
        renderFloatingVideoDock();
        if (!runtimeState.videoDockDimmed) scheduleVideoDockDim();
      }
    };
    handleEl.addEventListener("pointerup", endDrag);
    handleEl.addEventListener("pointercancel", endDrag);
  }
  function renderFloatingVideoDock() {
    if (window !== window.top) return;
    const existing = document.getElementById(VIDEO_DOCK_ID);
    if (runtimeState.globalSettings.videoDockEnabled === false || runtimeState.detectedVideos.length === 0) {
      if (existing) existing.remove();
      return;
    }
    let hostEl = existing;
    if (!hostEl) {
      hostEl = document.createElement("div");
      hostEl.id = VIDEO_DOCK_ID;
      hostEl.style.cssText = "position:fixed;z-index:2147483646;pointer-events:auto;";
      (document.documentElement || document.body).appendChild(hostEl);
    }
    const g = runtimeState.globalSettings;
    const count = runtimeState.detectedVideos.length;
    const videoEl = findPrimaryVideoElement();
    const isPlaying = videoEl ? !videoEl.paused : false;
    const shadow = hostEl.shadowRoot || hostEl.attachShadow({ mode: "open" });
    const streamItemsHtml = runtimeState.detectedVideos.slice(0, 8).map((u, idx) => {
      const label = u.split("/").pop()?.split("?")[0] || u.slice(0, 40);
      return `<div class="stream-row"><span class="stream-lbl" title="${u}">${idx + 1}. ${label.slice(0, 32)}</span><button class="s-btn" data-open-stream="${idx}">↗ Buka</button></div>`;
    }).join("");
    shadow.innerHTML = `
    <style>
      * { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }
      .wrap { display: flex; flex-direction: column; align-items: flex-end; gap: 6px; }
      .drawer { width: 290px; background: rgba(15,23,42,0.96); border: 1px solid rgba(52,211,153,0.45); border-radius: 12px; padding: 8px; box-shadow: 0 12px 32px rgba(0,0,0,0.55); color: #f8fafc; }
      .drawer-title { font-size: 10.5px; font-weight: 800; color: #34d399; margin-bottom: 6px; }
      .stream-row { display: flex; align-items: center; justify-content: space-between; gap: 6px; padding: 4px 6px; border-radius: 6px; background: #020617; border: 1px solid #1e293b; margin-bottom: 4px; font-size: 10px; }
      .stream-lbl { font-family: ui-monospace, monospace; color: #cbd5e1; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
      .s-btn { background: #10b981; color: #022c22; border: none; border-radius: 5px; padding: 2px 7px; font-size: 9.5px; font-weight: 800; cursor: pointer; flex-shrink: 0; }
      .pill { display: inline-flex; align-items: center; gap: 4px; padding: 4px 6px; border-radius: 999px; background: rgba(15,23,42,0.95); border: 1px solid rgba(52,211,153,0.48); box-shadow: 0 10px 28px rgba(0,0,0,0.5); cursor: grab; user-select: none; touch-action: none; }
      .pill:active { cursor: grabbing; }
      .badge { border: none; background: rgba(16,185,129,0.2); color: #6ee7b7; border-radius: 999px; padding: 4px 9px; font-size: 11px; font-weight: 800; cursor: pointer; white-space: nowrap; }
      .pill-btn { width: 28px; height: 28px; border-radius: 999px; border: none; background: transparent; color: #e2e8f0; font-size: 12px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
      .pill-btn:hover { background: rgba(255,255,255,0.12); }
    </style>
    <div class="wrap">
      ${runtimeState.videoDrawerOpen ? `<div class="drawer"><div class="drawer-title">🎬 Stream Video Terdeteksi (${count})</div>${streamItemsHtml}</div>` : ""}
      <div class="pill" id="pillHandle" title="Geser untuk pindah · Tekan 🎬 untuk buka/lipat">
        <button class="badge" id="dimCompactBadge">🎬(${count})</button>
        ${!runtimeState.videoDockDimmed ? `
          ${g.videoPillShowPlayPause !== false ? `<button class="pill-btn" id="vpPlay" title="Putar/Jeda">${isPlaying ? "❚❚" : "▶"}</button>` : ""}
          ${g.videoPillShowList !== false ? `<button class="pill-btn" id="vpList" title="Daftar Stream">☰</button>` : ""}
          ${g.videoPillShowDownload !== false ? `<button class="pill-btn" id="vpDl" title="Buka Stream di Tab Grup">⬇</button>` : ""}
          ${g.videoPillShowPip !== false ? `<button class="pill-btn" id="vpPip" title="Mini PiP">⧉</button>` : ""}
          ${g.videoPillShowFullscreen !== false ? `<button class="pill-btn" id="vpFs" title="Layar Penuh">⛶</button>` : ""}
        ` : ""}
      </div>
    </div>
  `;
    const pillHandle = shadow.getElementById("pillHandle");
    if (pillHandle) attachVideoDockDrag(pillHandle, hostEl);
    const vpPlay = shadow.getElementById("vpPlay");
    if (vpPlay) {
      vpPlay.addEventListener("click", () => {
        const v = findPrimaryVideoElement();
        if (v) {
          if (v.paused) v.play().catch(() => {
          });
          else v.pause();
          renderFloatingVideoDock();
        }
        scheduleVideoDockDim();
      });
    }
    const vpList = shadow.getElementById("vpList");
    if (vpList) {
      vpList.addEventListener("click", () => {
        runtimeState.videoDrawerOpen = !runtimeState.videoDrawerOpen;
        renderFloatingVideoDock();
      });
    }
    const vpDl = shadow.getElementById("vpDl");
    if (vpDl) {
      vpDl.addEventListener("click", () => {
        const target = runtimeState.detectedVideos[0];
        if (target) chrome.runtime.sendMessage({ type: "OPEN_GROUP_TAB", url: target });
        scheduleVideoDockDim();
      });
    }
    const vpPip = shadow.getElementById("vpPip");
    if (vpPip) {
      vpPip.addEventListener("click", () => {
        toggleSmartMinimizeOrPiP();
        scheduleVideoDockDim();
      });
    }
    const vpFs = shadow.getElementById("vpFs");
    if (vpFs) {
      vpFs.addEventListener("click", () => {
        const v = findPrimaryVideoElement();
        if (v && v.requestFullscreen) v.requestFullscreen().catch(() => {
        });
        scheduleVideoDockDim();
      });
    }
    shadow.querySelectorAll("[data-open-stream]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const idx = Number(btn.getAttribute("data-open-stream"));
        const target = runtimeState.detectedVideos[idx];
        if (target) chrome.runtime.sendMessage({ type: "OPEN_GROUP_TAB", url: target });
      });
    });
    updateFloatingVideoDockPosition();
  }

  // src/ext/content/index.js
  (() => {
    "use strict";
    const win = (
      /** @type {any} */
      window
    );
    if (win.__AEGIS_CONTENT_V3_LOADED__) return;
    win.__AEGIS_CONTENT_V3_LOADED__ = true;
    const storageReady = initStorageSync();
    function isValidMainEvent(ev) {
      return Boolean(ev && ev.detail && ev.detail.token === BRIDGE_TOKEN);
    }
    window.addEventListener(BRIDGE_EVENTS.AUTH_GESTURE, (ev) => {
      if (!isValidMainEvent(ev)) return;
      safeTry("content.authGestureForward", () => {
        chrome.runtime.sendMessage({ type: "AUTH_FLOW_STARTED" });
      });
    });
    window.addEventListener(BRIDGE_EVENTS.BLOCKED_EVENT, (ev) => {
      if (!isValidMainEvent(ev)) return;
      const d = (
        /** @type {CustomEvent} */
        ev.detail
      );
      if (!d || !d.url || isUrlInDeniedList(d.url)) return;
      enqueueManualPrompt({
        blockedUrl: d.url,
        message: d.kind === "popup" ? "Popup/tab iklan ditahan" : "Redirect lintas domain ditahan",
        kind: d.kind || "redirect"
      });
    });
    window.addEventListener(BRIDGE_EVENTS.VIDEO_DETECTED, (ev) => {
      if (!isValidMainEvent(ev)) return;
      const d = (
        /** @type {CustomEvent} */
        ev.detail
      );
      if (d && d.url) registerDetectedVideo(d.url, Boolean(d.confirmed));
    });
    window.addEventListener(BRIDGE_EVENTS.LOG_EVENT, (ev) => {
      if (!isValidMainEvent(ev)) return;
      const d = (
        /** @type {CustomEvent} */
        ev.detail
      );
      if (d) {
        logAegisEvent(d.level, d.code, d.toUrl, d.detail, d.source || "main_world");
      }
    });
    onRuntimeStateChange(() => {
      renderTopManualHUD();
      renderFloatingVideoDock();
      applySavedMiniPipPosition();
    });
    attachClickGuardListener();
    if (window === window.top) {
      storageReady.then(() => {
        safeTry("content.getPendingPrompts", () => {
          chrome.runtime.sendMessage({ type: "GET_PENDING_PROMPTS" }, (res) => {
            if (res && Array.isArray(res.prompts)) {
              res.prompts.forEach((p) => enqueueManualPrompt(p));
            }
          });
        });
        tryEarlyDirectShortlinkBypass();
      });
    }
    let domSweepTimer = null;
    function runUnifiedDomSweep() {
      if (document.hidden) return;
      if (checkAndBroadcastCaptchaStatus()) return;
      scanDomForVideos();
      neutralizeEmptyTrapOverlays();
      if (!tryEarlyDirectShortlinkBypass()) {
        runShortlinkDebloatedBypassStep();
      }
    }
    function scheduleUnifiedDomSweep() {
      if (document.hidden) return;
      clearTimeout(domSweepTimer);
      domSweepTimer = setTimeout(() => {
        if (typeof window.requestIdleCallback === "function") {
          window.requestIdleCallback(() => runUnifiedDomSweep(), { timeout: 400 });
        } else {
          runUnifiedDomSweep();
        }
      }, TIMINGS.OBSERVER_DEBOUNCE_MS);
    }
    const unifiedObserver = new MutationObserver((mutations) => {
      if (document.hidden) return;
      let hasRelevantElement = false;
      for (const m of mutations) {
        for (const node of m.addedNodes) {
          if (node.nodeType === 1) {
            const el = (
              /** @type {HTMLElement} */
              node
            );
            if (el.id === "aegis-top-manual-hud" || el.id === "aegis-video-bottom-dock" || el.id === "aegis-bypass-toast-host" || el.id === "aegis-mini-pip-drag-bar") {
              continue;
            }
            hasRelevantElement = true;
            break;
          }
        }
        if (hasRelevantElement) break;
      }
      if (hasRelevantElement) {
        scheduleUnifiedDomSweep();
      }
    });
    function startObserverAndLifecycle() {
      if (document.documentElement) {
        unifiedObserver.observe(document.documentElement, { childList: true, subtree: true });
      }
      storageReady.then(() => {
        runUnifiedDomSweep();
        setTimeout(() => {
          if (!document.hidden && !runtimeState.captchaDetected) {
            runAiDomAuditFallback();
          }
        }, 2200);
      });
    }
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", startObserverAndLifecycle, { once: true });
    } else {
      startObserverAndLifecycle();
    }
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        stopLazyAutoSkip();
        clearTimeout(domSweepTimer);
      } else {
        ensureLazyAutoSkipRunning();
        scheduleUnifiedDomSweep();
      }
    });
    let resizeTimer = null;
    window.addEventListener("resize", () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(() => {
        updateTopManualHudSavedPosition();
        updateFloatingVideoDockPosition();
        applySavedMiniPipPosition();
      }, 120);
    });
  })();
})();
